<?php
/**
 * Builds the Council 8600 demo site inside WordPress Playground.
 *
 * Runs once from blueprint.json after the theme and the events plugin are
 * active. Everything here is sample content: names, dates and phone numbers
 * are placeholders, and nothing is sent anywhere.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

wp_set_current_user( 1 );

/* Demo-only behaviour: emails shown on screen, and the automatic admin sign-in (see demo-only.php). */
wp_mkdir_p( WPMU_PLUGIN_DIR );
copy( __DIR__ . '/demo-only.php', WPMU_PLUGIN_DIR . '/kofc8600-demo-only.php' );

/* ── Site settings ── */
update_option( 'blogname', 'Knights of Columbus Council 8600' );
update_option( 'blogdescription', 'Fairfax Station, Virginia' );
update_option( 'blog_public', 0 ); // Prototype: ask search engines not to index.
update_option( 'timezone_string', 'America/New_York' );
global $wp_rewrite;
$wp_rewrite->set_permalink_structure( '/%postname%/' );

foreach ( get_posts( array( 'post_type' => array( 'post', 'page' ), 'numberposts' => -1, 'post_status' => 'any' ) ) as $kofc_old ) {
	wp_delete_post( $kofc_old->ID, true );
}

/* ── Block markup helpers ── */
function kofc_attrs( $attrs ) {
	return $attrs ? ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
}
function kofc_p( $html, $class = '' ) {
	$cls = $class ? ' class="' . esc_attr( $class ) . '"' : '';
	return '<!-- wp:paragraph' . kofc_attrs( $class ? array( 'className' => $class ) : array() ) . " -->\n<p$cls>$html</p>\n<!-- /wp:paragraph -->\n\n";
}
function kofc_h( $text, $level = 2, $class = '', $anchor = '' ) {
	$attrs = array();
	if ( 2 !== $level ) {
		$attrs['level'] = $level;
	}
	if ( $class ) {
		$attrs['className'] = $class;
	}
	if ( $anchor ) {
		$attrs['anchor'] = $anchor;
	}
	$id = $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '';
	return '<!-- wp:heading' . kofc_attrs( $attrs ) . " -->\n<h$level class=\"wp-block-heading" . ( $class ? " $class" : '' ) . "\"$id>$text</h$level>\n<!-- /wp:heading -->\n\n";
}
function kofc_section( $text, $anchor = '' ) {
	return kofc_h( $text, 2, '', $anchor );
}
function kofc_buttons( $buttons ) {
	$inner = '';
	foreach ( $buttons as $b ) {
		list( $text, $url ) = $b;
		$style  = isset( $b[2] ) ? $b[2] : '';
		$inner .= '<!-- wp:button' . kofc_attrs( $style ? array( 'className' => "is-style-$style" ) : array() ) . " -->\n"
			. '<div class="wp-block-button' . ( $style ? " is-style-$style" : '' ) . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . "\">$text</a></div>\n<!-- /wp:button -->\n\n";
	}
	return "<!-- wp:buttons -->\n<div class=\"wp-block-buttons\">" . rtrim( $inner ) . "</div>\n<!-- /wp:buttons -->\n\n";
}
function kofc_group( $inner, $class, $lock = false ) {
	$attrs = array( 'className' => $class );
	if ( $lock ) {
		$attrs['templateLock'] = 'contentOnly';
	}
	$attrs['layout'] = array( 'type' => 'default' );
	return '<!-- wp:group' . kofc_attrs( $attrs ) . " -->\n<div class=\"wp-block-group $class\">" . trim( $inner ) . "</div>\n<!-- /wp:group -->\n\n";
}
function kofc_columns( $left, $right ) {
	return "<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\">" . trim( $left )
		. "</div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\">" . trim( $right ) . "</div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n";
}
function kofc_rows( $rows ) {
	$inner = '';
	foreach ( $rows as $r ) {
		list( $title, $sub ) = $r;
		$url  = isset( $r[2] ) ? $r[2] : '';
		$icon = isset( $r[3] ) ? " icon-{$r[3]}" : '';
		if ( $url ) {
			$html = '<a href="' . esc_url( $url ) . "\"><strong>$title</strong>" . ( $sub ? "<span>$sub</span>" : '' ) . '</a>';
		} else {
			$html = "<span class=\"row-text\"><strong>$title</strong>" . ( $sub ? "<span class=\"row-sub\">$sub</span>" : '' ) . '</span>';
		}
		$inner .= kofc_p( $html, "row$icon" );
	}
	return kofc_group( $inner, 'rows' );
}
/* Program buttons: icon squares with a short name, four across where they fit. */
function kofc_apps( $apps ) {
	$inner = '';
	foreach ( $apps as $a ) {
		$inner .= kofc_p( '<a href="' . esc_url( $a[1] ) . "\">{$a[0]}</a>", "app icon-{$a[2]}" );
	}
	return kofc_group( $inner, 'app-grid' );
}
function kofc_card( $style, $title, $text, $buttons = array(), $lock = false ) {
	return kofc_group( kofc_h( $title, 3 ) . kofc_p( $text ) . ( $buttons ? kofc_buttons( $buttons ) : '' ), "is-style-$style", $lock );
}
function kofc_html( $html ) {
	return "<!-- wp:html -->\n$html\n<!-- /wp:html -->\n\n";
}
function kofc_shortcode( $code ) {
	return "<!-- wp:shortcode -->\n$code\n<!-- /wp:shortcode -->\n\n";
}
function kofc_steps( $items ) {
	$inner = '';
	foreach ( $items as $i ) {
		$inner .= "<!-- wp:list-item -->\n<li><strong>{$i[0]}</strong>{$i[1]}</li>\n<!-- /wp:list-item -->\n\n";
	}
	return "<!-- wp:list {\"ordered\":true,\"className\":\"is-style-steps\"} -->\n<ol class=\"wp-block-list is-style-steps\">" . rtrim( $inner ) . "</ol>\n<!-- /wp:list -->\n\n";
}
function kofc_image_inner( $id, $caption = '', $size = 'large' ) {
	$src = wp_get_attachment_image_url( $id, $size );
	$alt = esc_attr( get_post_meta( $id, '_wp_attachment_image_alt', true ) );
	$cap = $caption ? "<figcaption class=\"wp-element-caption\">$caption</figcaption>" : '';
	return "<!-- wp:image {\"id\":$id,\"sizeSlug\":\"$size\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-$size\"><img src=\"$src\" alt=\"$alt\" class=\"wp-image-$id\"/>$cap</figure>\n<!-- /wp:image -->";
}
function kofc_gallery( $images ) {
	$inner = array();
	foreach ( $images as $img ) {
		$inner[] = kofc_image_inner( $img[0], $img[1] );
	}
	return "<!-- wp:gallery {\"linkTo\":\"none\"} -->\n<figure class=\"wp-block-gallery has-nested-images columns-default is-cropped\">" . implode( "\n\n", $inner ) . "</figure>\n<!-- /wp:gallery -->\n\n";
}
function kofc_pattern( $slug ) {
	$pattern = WP_Block_Patterns_Registry::get_instance()->get_registered( "kofc8600/$slug" );
	return $pattern ? trim( $pattern['content'] ) . "\n\n" : '';
}
/* A pattern with its placeholder photos swapped, in order, for uploaded ones. */
function kofc_pattern_photos( $slug, $ids ) {
	return preg_replace_callback(
		'/<!-- wp:image .*?<!-- \/wp:image -->/s',
		function ( $m ) use ( &$ids ) {
			return $ids ? kofc_image_inner( array_shift( $ids ) ) : $m[0];
		},
		kofc_pattern( $slug )
	);
}
function kofc_honour( $label, $photo_id, $when, $name, $text ) {
	$photo = kofc_image_inner( $photo_id, '', 'medium' );
	$inner = kofc_section( $label )
		. "<!-- wp:columns {\"verticalAlignment\":\"center\"} -->\n<div class=\"wp-block-columns are-vertically-aligned-center\"><!-- wp:column {\"verticalAlignment\":\"center\",\"width\":\"220px\"} -->\n<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:220px\">$photo</div>\n<!-- /wp:column -->\n\n"
		. "<!-- wp:column {\"verticalAlignment\":\"center\"} -->\n<div class=\"wp-block-column is-vertically-aligned-center\">" . trim( kofc_p( $when, 'kotm-month' ) . kofc_h( $name, 3 ) . kofc_p( $text ) ) . "</div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->";
	return kofc_group( $inner, 'kotm', true );
}
function kofc_media( $file, $title, $alt, $caption = '' ) {
	$upload = wp_upload_bits( $file, null, file_get_contents( __DIR__ . "/media/$file" ) );
	$type   = wp_check_filetype( $upload['file'] );
	$id     = wp_insert_attachment(
		array(
			'post_title'     => $title,
			'post_excerpt'   => $caption,
			'post_mime_type' => $type['type'],
			'post_status'    => 'inherit',
		),
		$upload['file']
	);
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return $id;
}
function kofc_page( $title, $slug, $content, $parent = 0, $extra = array() ) {
	return wp_insert_post(
		wp_slash(
			array_merge(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_parent'  => $parent,
					'post_content' => $content,
				),
				$extra
			)
		)
	);
}
function kofc_u( $path ) {
	return home_url( $path );
}
function kofc_form( $fields_html, $button ) {
	return kofc_html( "<form class=\"council-form\" data-demo>\n<p class=\"fine\">Fields marked * are required.</p>\n$fields_html\n<button type=\"submit\">$button</button>\n<p role=\"status\"></p>\n</form>" );
}

/* ── Photos and placeholders ── */
$kofc_wreaths  = kofc_media( 'wreaths.jpg', 'Wreaths Across America', 'A color guard carrying flags leads a procession along a brick path.', 'Wreaths Across America' );
$kofc_fish1    = kofc_media( 'fish-fry-1.jpg', 'Fish fry, dining room', 'Parishioners share a meal and conversation around tables at the fish fry.', 'A table for everyone at the Lenten fish fry' );
$kofc_fish2    = kofc_media( 'fish-fry-2.jpg', 'Fish fry, serving line', 'A serving table overlooks a parish hall filled with people enjoying the fish fry.', 'The parish hall on a fish fry Friday' );
$kofc_knight   = kofc_media( 'knight-photo-placeholder.png', 'Knight of the Month (placeholder)', 'Placeholder photo for the Knight of the Month' );
$kofc_family   = kofc_media( 'family-photo-placeholder.png', 'Family of the Month (placeholder)', 'Placeholder photo for the Family of the Month' );
$kofc_newphoto = kofc_media( 'new-knight-photo.png', 'New Knight of the Month photo (for the test task)', 'Photo of the new Knight of the Month' );
$kofc_mcgivney = kofc_media( 'mcgivney.png', 'Blessed Michael McGivney', 'A painting of Blessed Michael McGivney seated with a book, with immigrant families, the harbor and St. Mary\'s Church in New Haven behind him.' );

/* ── Program owners: each can edit only the pages and events they are the Author of ── */
function kofc_owner( $login, $name ) {
	$id = username_exists( $login );
	return $id ? $id : wp_insert_user(
		array(
			'user_login'   => $login,
			'user_pass'    => 'council8600',
			'user_email'   => "$login@example.com",
			'display_name' => $name,
			'role'         => 'program_owner',
		)
	);
}
$kofc_faith_owner = kofc_owner( 'faith', 'Faith Director (demo)' );
$kofc_cor_owner   = kofc_owner( 'cor', 'COR coordinator (demo)' );

/* Documents and links still kept on the Council's current site (on the live site, PDFs go in the Media Library). */
$kofc_doc = function ( $file ) {
	return "https://www.kofc8600.org/uploads/4/5/8/1/45813269/$file";
};
$kofc_sug = 'https://www.signupgenius.com/index.cfm?go=c.SignUpSearch&eid=0BC7C0D9FFC9F967&cs=09B1BAD88FCD8B6C7B79640E5BCF9BC9'; // The Council's open SignUpGenius sign-ups.

/* ── Pages ── */
$kofc_home = kofc_page(
	'Home',
	'home',
	kofc_pattern( 'hero' ) . kofc_pattern( 'quick-tasks' )
	. kofc_columns( kofc_pattern( 'coming-up' ), kofc_pattern( 'new-here' ) )
	. kofc_section( 'From the Grand Knight' )
	. kofc_group(
		kofc_p( 'Welcome to all our new members! I hope you get involved in some way very soon. You are a Knight, the men behind the scenes who support our parish events (Charity), who help each other to strengthen our faith (Unity), and who stand ready to help our brothers (Fraternity).' )
		. kofc_p( 'Vivat Jesus!<br><strong>Richard Cummings</strong><br>Grand Knight, Council 8600', 'signature' ),
		'is-style-card'
	)
	. kofc_pattern_photos( 'recent-photos', array( $kofc_wreaths, $kofc_fish2, $kofc_fish1 ) )
);

$kofc_events = kofc_page(
	'Events and calendar',
	'events',
	kofc_p( 'Everything on the Council\'s calendar, with the shifts that still need volunteers.', 'sub' )
	. kofc_shortcode( '[council_calendar]' )
	// The Council's public Google Calendar (council8600@gmail.com): officers add events there, and the site shows them within the hour.
	. kofc_card(
		'card-blue',
		'Add events to your calendar',
		'Subscribe once and every Council event appears on your own phone calendar, including any changes made later.',
		array(
			array( 'Add to Google Calendar', 'https://calendar.google.com/calendar/u/0?cid=Y291bmNpbDg2MDBAZ21haWwuY29t' ),
			array( 'Add to iPhone or Outlook', 'webcal://calendar.google.com/calendar/ical/council8600%40gmail.com/public/basic.ics', 'outline' ),
		)
	)
);

$kofc_involved = kofc_page(
	'Get involved',
	'get-involved',
	kofc_p( 'Four ways in. Pick whichever fits the time you have this month.', 'sub' )
	. kofc_columns(
		kofc_section( 'Become a member' )
		. kofc_card( 'card-gold', 'All Catholic men 18 and older are welcome!', 'Join online at kofc.org. Your first year is free.', array( array( 'Ready to join now', kofc_u( '/get-involved/join/' ), 'gold' ), array( 'Need more information', kofc_u( '/get-involved/join/learn-more/' ), 'outline' ) ) )
		. kofc_section( 'Help at an event', 'volunteer' )
		. kofc_p( 'These still need volunteers. Pick a shift on SignUpGenius and it sends you a reminder.' )
		. kofc_shortcode( '[council_help_needed count="3"]' )
		. kofc_buttons( array( array( 'See all open sign-ups', $kofc_sug, 'outline' ) ) ),
		kofc_section( 'Prayer' )
		. kofc_card( 'card', 'Prayer requests', 'Ask the Council to pray for someone, or read this week\'s intentions.', array( array( 'Ask for prayers', kofc_u( '/get-involved/prayer/#ask' ) ), array( 'Read the prayer list', kofc_u( '/get-involved/prayer/' ), 'outline' ) ) )
		. kofc_section( 'Our programs' )
		. kofc_rows(
			array(
				array( 'Faith', 'Adoration, Memorial Masses, OCIA', kofc_u( '/get-involved/programs/faith/' ), 'cross' ),
				array( 'Family', 'Picnic, pancake breakfasts, Christmas party', kofc_u( '/get-involved/programs/family/' ), 'home' ),
				array( 'Community', 'Christmas trees, fish fry, food baskets', kofc_u( '/get-involved/programs/community/' ), 'hands' ),
				array( 'Culture of Life', 'Adoration for life, pregnancy centers', kofc_u( '/get-involved/programs/life/' ), 'heart' ),
			)
		)
		. kofc_section( 'Our initiatives' )
		. kofc_rows(
			array(
				array( 'Initiatives', 'Cor, the COR Mass, Faith and Fun nights', kofc_u( '/get-involved/programs/initiatives/' ), 'star' ),
			)
		)
	)
);

/* Rows of answers to copy into the kofc.org application. The theme adds a Copy button to each <code>. */
function kofc_codes( $items ) {
	$inner = '';
	foreach ( $items as $i ) {
		list( $label, $hint, $code ) = $i;
		$extra  = isset( $i[3] ) ? ' ' . $i[3] : '';
		$inner .= kofc_p( "<span class=\"row-text\"><strong>$label</strong>" . ( $hint ? "<span class=\"row-sub\">$hint</span>" : '' ) . '</span>' . ( $code ? "<code>$code</code>" : '' ), "row code-row$extra" );
	}
	return kofc_group( $inner, 'rows codes' );
}
function kofc_list( $items ) {
	$inner = '';
	foreach ( $items as $item ) {
		$inner .= "<!-- wp:list-item -->\n<li>$item</li>\n<!-- /wp:list-item -->\n\n";
	}
	return "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . rtrim( $inner ) . "</ul>\n<!-- /wp:list -->\n\n";
}
function kofc_details( $summary, $inner ) {
	return "<!-- wp:details -->\n<details class=\"wp-block-details\"><summary>$summary</summary>" . trim( $inner ) . "</details>\n<!-- /wp:details -->\n\n";
}

/*
 * The official online application, with the Council's answers already filled in. The form reads its
 * own field names from the address (found by testing; kofc.org doesn't document it). If that ever
 * stops working the boxes are simply empty, and the page still lists every answer to copy. A Knight's
 * personal link (/get-involved/join/?by=1234567) adds his member number; see the theme's theme.js.
 */
$kofc_join_form = 'https://www2.kofc.org/mserv/mvc/ememberSpa/displayejoinSpaForm.action?' . http_build_query(
	array(
		'request_locale'                  => 'en',
		'hasAgentReferralCode'            => 'true',
		'dataForm.agentCode'              => 'JGHERING',
		'dataForm.preferredCouncilNumber' => '8600',
		'dataForm.parishName'             => 'St. Mary of Sorrows',
		'dataForm.parishCity'             => 'Fairfax Station',
		'dataForm.proposerMemberNumber'   => '5353066', // the Membership Director, unless a recruiter's link replaces it
	),
	'',
	'&',
	PHP_QUERY_RFC3986
);

$kofc_join = kofc_page(
	'Join the Knights',
	'join',
	kofc_p( 'Catholic men 18 and older are welcome. You join online at kofc.org, and your first year is free.', 'sub' )
	. kofc_section( 'Have this ready' )
	. kofc_p( 'The application asks for these. Our button fills in most of them for you; if a box is empty, copy the answer from here.' )
	. kofc_codes(
		array(
			array( 'Agent referral code', 'Our Field Agent\'s code', 'JGHERING' ),
			array( 'Member referral number', 'Our Membership Director\'s number. If another Knight invited you, use his member number instead.', '5353066', 'referral' ),
			array( 'Preferred local council', '', '8600' ),
			array( 'Parish', 'Fairfax Station, Virginia', 'St. Mary of Sorrows' ),
			array( 'Promo code', 'Makes your first year free', 'BLESSEDMCGIVNEY' ),
		)
	)
	. kofc_buttons( array( array( 'Start my application on kofc.org', $kofc_join_form, 'gold' ) ) )
	. kofc_p( 'The application is on the official Knights of Columbus website.', 'fine' )
	. kofc_p( '<a href="' . esc_url( kofc_u( '/get-involved/join/learn-more/' ) ) . '">Not ready yet? Learn about the Knights</a>', 'more-link' ),
	$kofc_involved
);

/* Richard's "Essential Facts" sheet, as a synced pattern: edit it once under Patterns and every page that shows it changes. */
$kofc_support_list = function ( $title, $items, $slug, $program = '' ) {
	return kofc_group( kofc_h( $title, 3 ) . kofc_list( $items ) . kofc_p( '<a href="' . esc_url( kofc_u( "/get-involved/programs/$slug/" ) ) . '">' . ( $program ? $program : $title ) . ' activities</a>', 'more-link' ), 'is-style-card support-list' );
};
$kofc_support = wp_insert_post(
	wp_slash(
		array(
			'post_type'    => 'wp_block',
			'post_status'  => 'publish',
			'post_title'   => 'What Council 8600 supports',
			'post_content' => kofc_p( 'The 500+ members of Council 8600, Saint Mary of Sorrows Catholic Church, conduct numerous programs to support our great parish.', 'support-lead' )
				. kofc_group(
					$kofc_support_list( 'Community', array( 'Coats for Kids', 'Citizenship essays', 'Vacation Bible School', 'Lenten fish fries', 'Labor Day chicken dinners', 'Holiday food baskets', 'College scholarships', 'KOVAR' ), 'community' )
					. $kofc_support_list( 'Faith', array( 'FOCUS: college Catholic mission support', 'TEACH: overseas mission support (Guatemala)', 'Seminarians and postulants', 'Sisters of La Salette', 'Ukraine Solidarity Fund', 'Archdiocese for the Military Services' ), 'faith' )
					. $kofc_support_list( 'Family', array( 'Scouting America programs', 'Spaghetti dinners', 'Pancake breakfasts', 'Veterans Day lunches', 'Corpus Christi dinners', 'Family bingo games', 'Insurance programs' ), 'family' )
					. $kofc_support_list( 'Life', array( 'Marian Homes', 'Project Gabriel', 'Special Olympics', 'A Best Chance Ultrasound', 'MaRiH Center' ), 'life', 'Culture of Life' ),
					'support-grid'
				)
				. kofc_p( 'Your membership means a life of faith in action, a life of boldness in brotherhood, and a life worth living. Please join millions of Catholic men on a unique mission.', 'support-close' ),
		)
	)
);

kofc_page(
	'Learn about the Knights',
	'learn-more',
	kofc_p( 'Since 1882, the Knights of Columbus has empowered Catholic men to put their faith into action, building stronger families, stronger parishes and stronger communities.', 'banner-lead' )
	. kofc_rows(
		array(
			array( 'Mission, vision, founder and principles', 'Who the Knights are, and why', '#mission', 'star' ),
			array( 'Frequently asked questions', 'Requirements, time, meetings and dues', '#faq', 'page' ),
			array( 'Talk to a Knight', 'Ask first, with no obligation', '#talk', 'people' ),
			array( 'Charities and events we support', 'What Council 8600 does for the parish', '#support', 'hands' ),
		)
	)
	. kofc_section( 'Mission, vision, founder and principles', 'mission' )
	. kofc_h( 'Our mission', 3 )
	. kofc_p( 'The Knights of Columbus empowers Catholic men to live their faith and serve their family, parish, community and country.' )
	. kofc_h( 'Our vision', 3 )
	. kofc_p( 'Founded by Blessed Michael McGivney in 1882, the Knights of Columbus is the premier lay Catholic men\'s organization. Guided by the principles of charity, unity and fraternity, we build lifelong relationships with our members and families. We are multigenerational and international. We offer formation, mutual aid and financial security to members through our charity, products and outreach. We aspire to invite every Catholic man to join the Knights of Columbus and to extend our charitable reach as widely as possible.' )
	. kofc_h( 'Our founder', 3 )
	. kofc_group( kofc_image_inner( $kofc_mcgivney, '', 'full' ), 'founder-photo' )
	. kofc_p( 'Father Michael McGivney was a 29-year-old assistant priest at St. Mary\'s Church in New Haven, Connecticut, when he gathered men in his parish basement and founded the Knights of Columbus in 1882. The mission: help keep men Catholic and ensure their families\' financial protection. He died in 1890, two days after his 38th birthday, and was beatified in 2020.' )
	. kofc_details(
		'Read his full story',
		kofc_p( 'When 29-year-old Father Michael McGivney founded the Knights of Columbus in 1882, he knew what hardships and pressures these husbands and fathers, mostly poor, immigrant Catholics, faced:' )
		. kofc_list(
			array(
				'A culture with deep mistrust of the Catholic community.',
				'Often dangerous working conditions.',
				'Membership organizations that promised social benefits and mutual aid but came with strong anti-Catholic biases.',
				'The burden of knowing that their death would likely leave their families penniless and at risk of being separated.',
			)
		)
		. kofc_p( 'A child of immigrants, and a faithful son who had to leave seminary to help support his mother and siblings after his factory-employed father died, Father McGivney was intimately familiar with these realities.' )
		. kofc_p( 'And so, as an assistant priest at St. Mary\'s Church in the bustling port city of New Haven, Connecticut, he stepped into the breach to do something about it. Gathering men in his parish basement, Father McGivney founded the Knights of Columbus. The mission: help keep men Catholic and ensure their families\' financial protection.' )
		. kofc_p( 'At the time, Christopher Columbus was widely lionized in American culture, despite being a Catholic, and Father McGivney proposed him as a model for these first Knights who sought to hold on to their Catholic faith and identity in the New World.' )
		. kofc_p( 'After founding the Knights, Father McGivney was notably intentional about placing leadership in the hands of the group\'s lay members. In this way, he anticipated by nearly a century Vatican II\'s focus on and empowerment of the laity in living out the universal call to holiness and the Church\'s mission to evangelize.' )
		. kofc_p( 'During the global flu pandemic of 1889–1890, Father McGivney was ministering among his people until his own weakening health confined him to bed, where he continued praying for his flock. He died on Aug. 14, 1890, two days after his 38th birthday.' )
		. kofc_p( 'In 2020, the Knights of Columbus announced the Vatican had approved a miracle involving the child of one of the Order\'s insurance agents, moving Father McGivney\'s cause for canonization to the stage of beatification.' )
		. kofc_p( 'In his <a href="https://files.kofc.org/download/assets/Apostolic+Letter/a2530c4a932911f0bf6e9a7a904fa67f">Apostolic Letter</a> announcing Father McGivney\'s beatification, Pope Francis stated that our Founder\'s "zeal for the proclamation of the Gospel and generous concern for the needs of his brothers and sisters made him an outstanding witness of Christian solidarity and fraternal assistance."' )
		. kofc_p( 'Blessed Michael McGivney is entombed at St. Mary\'s Church, birthplace of the Knights of Columbus and a pilgrimage destination for Knights, their families and all others who have a devotion to America\'s Parish Priest.' )
	)
	. kofc_h( 'Our principles', 3 )
	. kofc_rows(
		array(
			array( 'Charity', 'We find Christ in our neighbor and are changed by each encounter.' ),
			array( 'Unity', 'United in faith as members of the universal Church, our diverse brotherhood builds up the Body of Christ.' ),
			array( 'Fraternity', 'We seek Christ-centered brotherhood, encouraging one another to grow in holiness and virtue.' ),
			array( 'Patriotism', 'We strive to be faithful citizens, bearing witness to the true freedom that comes from pursuing lives of truth, justice, solidarity and above all, charity.' ),
		)
	)
	. kofc_section( 'Frequently asked questions', 'faq' )
	. kofc_p( 'Calling all practical Catholic men 18 years or older. If you\'re interested in joining Council 8600, email our Admissions Committee at <a href="mailto:' . antispambot( 'admissions@kofc8600.org' ) . '">' . antispambot( 'admissions@kofc8600.org' ) . '</a>.' )
	. kofc_group(
		kofc_details( 'What is the Knights of Columbus?', kofc_p( 'The Knights of Columbus is the world\'s largest Catholic fraternal benefit society, with more than 2.2 million members in 17 countries. Father Michael J. McGivney founded the Order in 1882 to assist Catholic widows and orphans. Today the Knights support a multitude of charitable causes: in 2025 they gave more than $200 million and 48 million volunteer hours, focused on Charity, Unity, Fraternity and Patriotism. The Knights also help provide financial aid to Catholic families who have lost their income to death, and the Order is now one of the largest life insurers in North America.' ) )
		. kofc_details( 'What are the requirements to be a Knight?', kofc_p( 'The only requirements are to be a practical Catholic man, 18 years old or older, and to pay dues. Annual Council dues are $45.' ) )
		. kofc_details( 'I don\'t have any spare time. Why should I join?', kofc_p( 'There is no minimum volunteer time commitment. As a Knight, you choose the projects you\'re involved with and the time you give to them. Many programs enrich family life through the parish and the community, and social activities are open to the whole family. As with most volunteer organizations, you get out of it what you put in. Most members give a few hours a year.' ) )
		. kofc_details(
			'How does Council 8600 support the parish?',
			kofc_p( 'The Council supports the parish community in many ways. We support the Pastor and our priests, help maintain the buildings and promote the building campaign. We give financial support to the Children\'s Choir and recognize the Altar Servers for their service. We support seminarians financially and with their annual cookout. We support the annual Labor Day picnic. We help with Feast Day celebrations, and with funerals through Honor Guards. We support the parish\'s Scouting America program, both financially and with leaders. Some members start new programs of their own to meet parish needs. Knights are Eucharistic ministers, ushers at Mass, choir members, members of the Legion of Mary, catechists and members of the OCIA team. In just about every ministry at St. Mary of Sorrows, you\'ll find Knights involved or leading the way.' )
			. kofc_p( '<strong>Our fundraising includes</strong> Christmas tree sales, the Marian Homes shredding event, Celebrate Fairfax, Bingo and the silent auction, pancake breakfasts, spaghetti dinners, the Polar Plunge, Tex-Mex, Italian and Polish nights, Christmas cards and scholarships.' )
			. kofc_p( '<strong>Our volunteer work includes</strong> Marian Homes, Helping Hands, April Improve-a-Home, Special Olympics, KAIROS Prison Ministry, Culture of Life, the Route 123 cleanup (Adopt a Highway), Thanksgiving and Christmas food baskets, Scouts, Squires, Squire Roses, the Paul Stefan Foundation, the children\'s Christmas party, the hypothermia dinner, Project Gabriel, Project Manger and the March for Life.' )
		)
		. kofc_details( 'When and where are the meetings, and what are they like?', kofc_p( 'The Grand Knight leads the Council and is elected by the members for a fraternal year, July 1 to June 30. One of our parish priests serves as the Council\'s Chaplain and guides the members in spiritual matters. The Council meets at Old St. Mary\'s Hall on the first and third Tuesdays of each month, except in July and August, when it meets only on the third Tuesday. Evenings start with fraternal time and a light meal at 7:00 pm, followed by Our Lady\'s Rosary at 7:30 pm. The business meeting begins at 8:00 pm, following Robert\'s Rules of Order, and runs about an hour, followed by more fraternal time (and ice cream). Nobody has to attend every meeting, but coming is the best way to learn about the many activities and charities that benefit our parish and community.' ) )
		. kofc_details( 'What is a practical Catholic?', kofc_p( 'A practical Catholic accepts the teaching authority of the Catholic Church on matters of faith and morals, aspires to live in accord with the precepts of the Catholic Church, and is in good standing in the Catholic Church.' ) )
		. kofc_details( 'Why can\'t women join the Knights of Columbus?', kofc_p( 'The Order was designed to provide spiritual, moral and financial support among Catholic men, with a distinct model of male Catholic friendship, camaraderie and service. It keeps its historical men-only membership, as a dedicated space for men to encourage one another in faith, family leadership and charitable work. Women cannot join the Knights of Columbus itself, but Catholic women can join affiliated or parallel organizations that partner with local councils.' ) )
		. kofc_details( 'Do I have to buy Knights of Columbus insurance to become a member?', kofc_p( 'No. Insurance is optional. A man has to be a member before he can use the insurance benefit.' ) )
		. kofc_details(
			'What are the annual dues?',
			kofc_p( 'Council dues are $45 a year if paid by cash or check: $6.50 goes to the Supreme Council, $7.00 to the Virginia State Council and $31.50 to Council 8600. There is a small fee for paying by card, and special members such as Honorary and Honorary Life members pay less. There is also an optional Penny per Knight per Day (PKD) contribution of $3.65 a year; it doesn\'t go to Council 8600. If you join online, your first year is free with our promo code.' )
			. kofc_p( '<a href="' . esc_url( kofc_u( '/give/pay/#dues' ) ) . '">Dues for each membership type</a>', 'more-link' )
		),
		'faq'
	)
	. kofc_p( 'Still have a question? Email our Grand Knight at <a href="mailto:' . antispambot( 'grandknight@kofc8600.org' ) . '">' . antispambot( 'grandknight@kofc8600.org' ) . '</a>, or visit <a href="https://www.kofc.org/">kofc.org</a>.' )
	. kofc_section( 'Talk to a Knight', 'talk' )
	. kofc_p( 'Prefer to talk it over first? A Knight from the Council will answer your questions. There is no obligation.' )
	. kofc_h( 'What happens when you join', 3 )
	. kofc_steps(
		array(
			array( 'Apply online', 'Fill in the application at kofc.org. With our promo code, your first year is free.' ),
			array( 'Come to a meeting', 'First and third Tuesdays at Old St. Mary\'s Hall, with a light meal at 7:00 pm.' ),
			array( 'Hear from the Council', 'The Knights of Columbus lets Council 8600 know when you join online. A Knight then gets in touch to welcome you and to help you take part in the Exemplification of Charity, Unity and Fraternity, the ceremony that welcomes new Knights.' ),
		)
	)
	. kofc_buttons( array( array( 'Start my membership', kofc_u( '/get-involved/join/' ), 'gold' ), array( 'Ask a question first', kofc_u( '/more/contact/' ), 'outline' ) ) )
	. kofc_card( 'card-blue', 'What it costs', 'Council dues are paid each January. Members having difficulty should speak to the Grand Knight. Nobody is turned away over dues.', array( array( 'Dues for each membership type', kofc_u( '/give/pay/#dues' ), 'outline' ) ) )
	. kofc_section( 'Charities and events we support', 'support' )
	. "<!-- wp:block {\"ref\":$kofc_support} /-->\n\n"
	. kofc_buttons( array( array( 'Ready to join now', kofc_u( '/get-involved/join/' ), 'gold' ) ) ),
	$kofc_join
);

function kofc_activity( $name, $line, $facts = '', $more = '', $link = array() ) {
	$inner = kofc_h( $name, 3 ) . kofc_p( $line );
	if ( $facts ) {
		$inner .= kofc_p( $facts, 'facts' );
	}
	if ( $more ) {
		$inner .= "<!-- wp:details -->\n<details class=\"wp-block-details\"><summary>More about this</summary>" . trim( kofc_p( $more ) ) . "</details>\n<!-- /wp:details -->\n\n";
	}
	// One link as array( text, url ), or several as a list of them.
	foreach ( ( $link && is_array( $link[0] ) ) ? $link : ( $link ? array( $link ) : array() ) as $l ) {
		$inner .= kofc_p( '<a href="' . esc_url( $l[1] ) . '">' . $l[0] . '</a>', 'more-link' );
	}
	return kofc_group( $inner, 'is-style-card program' );
}
function kofc_activities( $items ) {
	$cards = '';
	foreach ( $items as $i ) {
		$cards .= call_user_func_array( 'kofc_activity', $i );
	}
	return kofc_group( $cards, 'program-grid' );
}
function kofc_program_page( $title, $slug, $intro, $owner, $items, $parent, $author = 1 ) {
	return kofc_page(
		$title,
		$slug,
		kofc_p( $intro, 'sub' ) . kofc_activities( $items )
		. kofc_p( "This page is kept up to date by the $owner. Sample content: confirm details before launch.", 'fine' ),
		$parent,
		array( 'post_author' => $author )
	);
}

$kofc_programs = kofc_page(
	'Our programs',
	'programs',
	kofc_p( 'The Council\'s work, grouped the way the Knights of Columbus organize it. Choose a program to see its activities.', 'sub' )
	. kofc_activities(
		array(
			array( 'Faith', 'Prayer, the sacraments and service to the parish.', 'First Friday Adoration · Memorial Masses · OCIA', '', array( 'Faith activities', kofc_u( '/get-involved/programs/faith/' ) ) ),
			array( 'Family', 'Events that bring Council families and the parish together.', 'Labor Day picnic · Bingo · Pancake breakfasts', '', array( 'Family activities', kofc_u( '/get-involved/programs/family/' ) ) ),
			array( 'Community', 'Charity in Fairfax Station and beyond.', 'Christmas trees · Lenten fish fry · Food baskets', '', array( 'Community activities', kofc_u( '/get-involved/programs/community/' ) ) ),
			array( 'Culture of Life', 'Prayer and practical help for mothers and children.', 'Diaper drive · Respect Life Month · March for Life', '', array( 'Culture of Life activities', kofc_u( '/get-involved/programs/life/' ) ) ),
		)
	)
	. kofc_p( 'Each program has a director who keeps its page up to date.', 'fine' )
	. kofc_section( 'Our initiatives', 'initiatives' )
	. kofc_p( 'Council work that runs alongside the four programs: Cor, the COR Mass and Faith and Fun nights.', 'sub' )
	. kofc_buttons( array( array( 'See our initiatives', kofc_u( '/get-involved/programs/initiatives/' ), 'outline' ) ) ),
	$kofc_involved
);

kofc_program_page(
	'Faith',
	'faith',
	'Knights serve the parish as lectors, ushers, Eucharistic ministers and catechists.',
	'Faith Director',
	array(
		array( 'First Friday Adoration', 'An hour of prayer before the Blessed Sacrament.', 'First Fridays · from 7:00 pm · Church', 'Sign up online for an hour. Early-morning hours are the hardest to fill.', array( 'Sign up for an hour of Adoration', 'https://smos.weadorehim.com/' ) ),
		array( 'Memorial Masses', 'Masses offered for deceased Knights of the Council.' ),
		array( 'Founder\'s Day Mass', 'Mass marking the founding of the Knights of Columbus.' ),
		array( 'OCIA support', 'Helping adults who are exploring or returning to the Catholic faith.', '', 'Know someone who comes to Mass but is not Catholic, or who never received all the sacraments? Introduce them to the parish OCIA team.' ),
		array( 'Communion to the homebound', 'Bringing the Eucharist to parishioners who cannot come to Mass.' ),
		array( 'Seminarians and postulants', 'Support for men and women preparing for the priesthood and religious life, including the seminarians\' annual cookout.' ),
		array( 'Sisters of La Salette', 'Support for the Sisters of La Salette.' ),
		array( 'FOCUS and TEACH missions', 'Support for FOCUS missionaries to college students, and for TEACH missions in Guatemala.' ),
		array( 'Ukraine Solidarity Fund', 'The Knights of Columbus fund for relief in Ukraine.' ),
		array( 'Archdiocese for the Military Services', 'Support for the Archdiocese that serves Catholics in the U.S. armed forces.' ),
	),
	$kofc_programs,
	$kofc_faith_owner
);

kofc_program_page(
	'Family',
	'family',
	'Events that bring Council families and the parish together.',
	'Family Director',
	array(
		array( 'Labor Day picnic', 'A picnic for Knights and their families.', 'Labor Day' ),
		array( 'Bingo', 'Bingo nights, with food, in the parish hall.', 'Farrell Hall · 6:30 pm' ),
		array( 'Pancake breakfasts', 'Breakfasts cooked and served by Knights.' ),
		array( 'Children\'s Christmas party', 'A Christmas party for the children of the parish.', 'December' ),
		array(
			'Keep Christ in Christmas poster contest',
			'Children draw a poster that keeps Christ at the center of Christmas.',
			'Kindergarten to 8th grade · Entries due in early December',
			'Posters are 11 by 17 inches, with the child\'s name and grade on the back. Hand the poster in with a signed entry form (Form 5025) at the box in the Parish Center lobby. The Council judges each grade level on slogan, artistic merit and overall impact.',
			array(
				array( 'Contest flyer (PDF)', $kofc_doc( 'keep_christ_in_christmas_poster_contest.pdf' ) ),
				array( 'Entry form 5025 (PDF)', $kofc_doc( '5025-kcic-entry-score-sheet-fillable.pdf' ) ),
			),
		),
		array( 'Spaghetti dinners and International Night', 'Dinners that bring the parish together.' ),
		array( 'Scouting and Vacation Bible School', 'Support for the parish\'s youth programs.' ),
		array( 'Young Man and Young Woman of the Year', 'Recognition for young people of the parish.' ),
		array( 'Veterans Day lunch', 'A lunch honoring veterans.', 'November' ),
		array( 'Corpus Christi dinner', 'A parish dinner for the feast of Corpus Christi.' ),
		array( 'Insurance programs', 'Life insurance and financial protection for members and their families, through the Council\'s Field Agent.', '', '', array( 'Talk to our Field Agent', kofc_u( '/more/contact/' ) ) ),
	),
	$kofc_programs
);

$kofc_community = kofc_program_page(
	'Community',
	'community',
	'Charity in Fairfax Station and beyond.',
	'Community Director',
	array(
		array( 'Christmas tree sales', 'One of the Council\'s largest fundraisers.', 'Christmas season · Shifts on Signup Genius' ),
		array( 'Lenten fish fry', '1,179 dinners served during Lent 2026.', 'Fridays in Lent' ),
		array( 'Thanksgiving and Christmas food baskets', 'Holiday meals for families in need.', 'Thanksgiving and Christmas' ),
		array( 'Coats for Kids', 'New winter coats for children who need them.' ),
		array(
			'Catholic Citizenship Essay Contest',
			'An essay contest for students, on a theme set each year.',
			'Grades 8 to 12 · Entries due in early December',
			'Essays are 500 to 750 words. Email the typed essay and a signed entry form (Form 4208) to the Community Director; the address is on the flyer. Each grade competes on its own, and Council winners go on to compete at higher levels.',
			array(
				array( 'Contest flyer (PDF)', $kofc_doc( 'catholic_citizenship_essay_contest.pdf' ) ),
				array( 'Entry form 4208 (PDF)', $kofc_doc( '4208-essay-entry-form.pdf' ) ),
				array( 'For younger children: the Christmas poster contest', kofc_u( '/get-involved/programs/family/' ) ),
			),
		),
		array( 'Route 123 cleanup', 'The Council\'s Adopt-a-Highway stretch of Route 123.', 'Meet at Old St. Mary\'s Hall · Sign up on Signup Genius' ),
		array( 'Wreaths Across America', 'Laying wreaths to honor veterans.', 'December' ),
		array( 'Scholarships', 'College scholarships for students from parish and Council families.', '', '', array( 'Scholarships and the 2026 winners', kofc_u( '/get-involved/programs/community/scholarships/' ) ) ),
		array( 'Soccer and free-throw challenges', 'Youth soccer and basketball free-throw competitions.' ),
		array( 'Blood drives', 'Blood drives for the community.' ),
		array( 'Global Wheelchair Mission', 'Wheelchairs for people who cannot afford one, at home and abroad.' ),
		array( 'HomeAid', 'Helping HomeAid build and repair housing for people who have been homeless.' ),
		array( 'Old St. Mary\'s Hall', 'Renovation and upkeep of Old St. Mary\'s Hall.' ),
		array( 'KOVAR', 'Support for Virginians with intellectual disabilities.' ),
	),
	$kofc_programs
);

kofc_page(
	'Scholarships',
	'scholarships',
	kofc_p( 'College scholarships from the Council\'s Scholarships Committee, for students from parish and Council families.', 'sub' )
	. kofc_section( 'The 2026 winners' )
	. kofc_p( 'This year\'s awards include the Joel Byrne Memorial Scholarship and the Kelly Elizabeth Baker Memorial Scholarship. Read about each winner and their plans for college.' )
	. kofc_buttons( array( array( 'Meet the 2026 winners (PDF)', $kofc_doc( '2026_pix___plans_for_website_051826m.pdf' ) ) ) )
	. kofc_section( 'How to apply' )
	. kofc_card( 'card-blue', 'Applications', 'The application form, who can apply and the deadline go here when applications open.' )
	. kofc_section( 'Help fund a scholarship' )
	. kofc_p( 'You can give to Council scholarships online, with the same form used for dues.' )
	. kofc_buttons( array( array( 'Donate to scholarships', kofc_u( '/give/pay/#donate' ), 'outline' ) ) )
	. kofc_p( 'This page is kept up to date by the Scholarships Committee. Sample content: confirm details before launch.', 'fine' ),
	$kofc_community
);

kofc_program_page(
	'Culture of Life',
	'life',
	'Prayer and practical help for mothers and children.',
	'Culture of Life Director',
	array(
		array( 'Diaper, wipes and formula drive', 'Collected for mothers and babies in need.', '4th Sunday of each month' ),
		array( 'Pregnancy resource centers', 'Time and donations for local pregnancy centers.', '', 'Centers the Council supports include the MaRiH Center, A Best Choice, the Paul Stefan Home and House of Mercy.' ),
		array( 'Adoration for life', 'Praying for life before the Blessed Sacrament.' ),
		array( 'Silver Rose', 'A rosary pilgrimage praying for respect for life.' ),
		array( 'Respect Life Month', 'Prayer and events for life.', 'October' ),
		array( 'March for Life', 'Joining the national and Virginia marches.', 'National march: January' ),
		array( 'Choose Life license plates', 'Virginia\'s Choose Life license plate campaign.' ),
		array( 'Marian Homes', 'Group homes for adults with intellectual disabilities. Marian Homes grew out of Council 8600.', '', '', array( 'Visit Marian Homes', 'https://www.marianhomes.org/' ) ),
		array( 'Project Gabriel', 'Help for women facing an unexpected pregnancy.' ),
		array( 'Special Olympics', 'Volunteering with Special Olympics Virginia, and the Polar Plunge that raises money for it.' ),
	),
	$kofc_programs
);

$kofc_initiatives = kofc_program_page(
	'Initiatives',
	'initiatives',
	'Council work that runs alongside the four programs.',
	'Grand Knight',
	array(
		array( 'Cor: Evangelization and Faith Formation', 'The Knights of Columbus initiative for prayer, formation and fraternity.', 'Open to all men of the parish' ),
		array( 'COR Mass', 'An early Mass for parishioners who start work early.', 'First Mondays · 5:30 am · Main church', '', array( 'About the COR Mass', kofc_u( '/get-involved/programs/initiatives/cor-mass/' ) ) ),
		array( 'Faith and Fun nights', 'Fellowship evenings with a short talk on the faith.', '', 'The Lenten trivia night paired trivia games with a talk on living Lent well.' ),
	),
	$kofc_programs
);

kofc_page(
	'COR Mass',
	'cor-mass',
	kofc_p( 'An early Mass on the first Monday of each month, for parishioners who start work early.', 'sub' )
	. kofc_card( 'card-blue', 'When and where', 'First Monday of each month at 5:30 am, in the main church at St. Mary of Sorrows. Open to all parishioners. Scheduled through June 2027.' )
	. kofc_h( 'Why an early Mass' )
	. kofc_p( 'Many parishioners have to be at work before the regular daily Masses. This Mass lets them start the week at Mass.' )
	. kofc_h( 'Part of Cor' )
	. kofc_p( 'The COR Mass is hosted by the Council\'s Cor initiative: the Knights of Columbus program of prayer, formation and fraternity for men.' )
	. kofc_buttons( array( array( 'Add to my calendar', '#', 'outline' ) ) )
	. kofc_p( 'This page is kept up to date by the COR coordinator.', 'fine' ),
	$kofc_initiatives,
	array( 'post_author' => $kofc_cor_owner )
);

kofc_page(
	'Prayer requests',
	'prayer',
	kofc_p( 'The Council prays for these intentions at every meeting.', 'sub' )
	. kofc_section( 'This week\'s intentions' )
	. kofc_rows(
		array(
			array( 'For the sick of our parish', 'Added this week' ),
			array( 'For the repose of our departed members', 'Ongoing' ),
			array( 'For vocations to the priesthood', 'Ongoing' ),
			array( 'For families in need in our community', 'Added last week' ),
		)
	)
	. kofc_section( 'Ask for prayers', 'ask' )
	. kofc_form(
		'<div class="field"><label for="p-name">Your name *</label><input id="p-name" name="name" autocomplete="name" required></div>
<div class="field"><label for="p-email">Your email address *</label><input id="p-email" name="email" type="email" autocomplete="email" required></div>
<div class="field"><label for="p-for">Who is the request for? *</label><input id="p-for" name="for" required></div>
<div class="field"><label for="p-text">Your request *</label><textarea id="p-text" name="request" rows="5" required></textarea></div>
<label class="check"><input type="checkbox" name="permission" required> <span>I have permission to share this request. *</span></label>',
		'Send prayer request'
	)
	. kofc_p( 'Requests are read by an officer before they appear on the list.', 'fine' ),
	$kofc_involved
);

$kofc_give = kofc_page(
	'Give',
	'give',
	kofc_p( 'Dues and donations in one place, on one payment system.', 'sub' )
	. kofc_columns(
		kofc_section( 'Council dues' )
		. kofc_card( 'card-gold', 'Annual Council dues', 'Due each January. Pay by card in about two minutes, or mail a check if you prefer.', array( array( 'Pay dues', kofc_u( '/give/pay/' ), 'gold' ) ) )
		. kofc_buttons( array( array( 'Dues for each membership type', kofc_u( '/give/pay/#dues' ), 'outline' ) ) )
		. kofc_section( 'Support a cause' )
		. kofc_rows(
			array(
				array( 'Parish food pantry', 'Feeds local families year-round', kofc_u( '/give/pay/#donate' ) ),
				array( 'KOVAR', 'Virginians with intellectual disabilities', kofc_u( '/give/pay/#donate' ) ),
				array( 'Council scholarships', 'For parish and school students', kofc_u( '/give/pay/#donate' ) ),
				array( 'Council Charitable Fund', 'What it supports, and how to give (PDF)', $kofc_doc( 'council_8600_charitable_fund_information_how-to-contribute_v2.pdf' ) ),
			)
		)
		. kofc_section( 'Other ways to give' )
		. kofc_rows(
			array(
				array( 'Knights of Columbus charities', 'Give to the Order\'s charities at kofc.org', 'https://www.kofc.org/donate/' ),
				array( 'St. Mary of Sorrows', 'Give to the parish online', 'https://www.parishgiving.org/index' ),
			)
		),
		kofc_section( 'What your giving did' )
		. kofc_group( kofc_p( '<strong>1,179</strong>Fish fry dinners', 'stat' ) . kofc_p( '<strong>183</strong>Volunteers', 'stat' ) . kofc_p( '<strong>565</strong>Service hours', 'stat' ), 'stats', true )
		. kofc_p( '2026 Lenten program, as reported on the Council\'s current website.', 'fine' )
		. kofc_card( 'card-blue', 'Where the money goes', 'Annual accounts are presented at the business meeting, and any member may ask to see them.' )
	)
);

kofc_page(
	'Pay dues or donate',
	'pay',
	kofc_p( 'About two minutes by card, Apple Pay or Google Pay.', 'sub' )
	. kofc_html( '<div class="pay-placeholder"><strong>The payment form appears here</strong>On the live site this is an embedded Zeffy form: dues for each membership type, with optional yearly renewal, plus donations and event tickets. Members never leave the Council\'s page.</div>' )
	. kofc_section( 'Dues for each membership type', 'dues' )
	. kofc_p( 'Yearly amounts by cash or check. Paying by card adds a small fee, shown when you pay.' )
	. kofc_h( 'Council 8600', 3 )
	. kofc_rows(
		array(
			array( 'Regular member', '$45 a year' ),
			array( 'Student and Honorary members', 'Less: ask the Financial Secretary' ),
			array( 'Honorary life member', 'No dues' ),
			array( 'Penny per Knight per Day (PKD)', 'Optional, $3.65 a year. It doesn\'t go to Council 8600.' ),
		)
	)
	. kofc_h( 'Fourth Degree Assembly', 3 )
	. kofc_rows(
		array(
			array( 'Regular member', '$26.83' ),
			array( 'Honorary member', '$12.06' ),
			array( 'Honorary life member', 'No dues' ),
		)
	)
	. kofc_section( 'Donate to a cause', 'donate' )
	. kofc_p( 'The same form takes donations to the food pantry, KOVAR and Council scholarships.' )
	. kofc_card( 'card', 'Prefer to mail a check?', 'Make it payable to Knights of Columbus Council 8600 and mail it to the Financial Secretary. The address appears here, as text, with no PDF to open.' )
	. kofc_card( 'card-blue', 'Not sure whether you\'ve paid?', 'Call the Financial Secretary. He can check in a moment.', array( array( 'Call the Financial Secretary', 'tel:+15715550100', 'outline' ) ) )
	. kofc_p( 'Sample content. Phone numbers in this prototype are placeholders.', 'fine' ),
	$kofc_give
);

$kofc_more = kofc_page(
	'More',
	'more',
	// On phones the More tab shows this page as a slide-up menu (theme inc/more-menu.php).
	kofc_p( 'Everything else, one tap away.', 'sub' )
	. kofc_section( 'Programs and initiatives' )
	. kofc_apps(
		array(
			array( 'Faith', kofc_u( '/get-involved/programs/faith/' ), 'cross' ),
			array( 'Family', kofc_u( '/get-involved/programs/family/' ), 'home' ),
			array( 'Community', kofc_u( '/get-involved/programs/community/' ), 'hands' ),
			array( 'Life', kofc_u( '/get-involved/programs/life/' ), 'heart' ),
		)
	)
	. kofc_rows( array( array( 'Initiatives', 'Cor, the COR Mass, Faith and Fun nights', kofc_u( '/get-involved/programs/initiatives/' ), 'star' ) ) )
	. kofc_columns(
		kofc_section( 'About the Council' )
		. kofc_rows(
			array(
				array( 'Officers and contacts', 'Who to contact about what', kofc_u( '/more/officers/' ), 'people' ),
				array( 'Recognition', 'Knight and Family of the Month, Knight of the Year', kofc_u( '/more/recognition/' ), 'award' ),
				array( 'Past Grand Knights', 'Every Grand Knight since 1984', kofc_u( '/more/past-grand-knights/' ), 'star' ),
				array( 'Photos', 'Council events, by year', kofc_u( '/more/photos/' ), 'camera' ),
			)
		)
		. kofc_section( 'Get in touch' )
		. kofc_rows(
			array(
				array( 'Contact us', 'Send the Council a message', kofc_u( '/more/contact/' ), 'mail' ),
				array( 'Find us', 'St. Mary of Sorrows · Fairfax Station, VA', kofc_u( '/more/find-us/' ), 'pin' ),
				array( 'Insurance', 'Talk to our Field Agent', kofc_u( '/more/contact/' ), 'phone' ),
			)
		),
		kofc_section( 'For members' )
		. kofc_rows(
			array(
				array( 'Members\' area', 'Sign in, or ask for access', kofc_u( '/members/' ), 'lock' ),
				array( 'Council emails', 'Sign up, or fix emails going to spam', kofc_u( '/members/#emails' ), 'mail' ),
				array( 'Helpful links', 'Supreme, State Council and charities', kofc_u( '/more/links/' ), 'link' ),
			)
		)
	)
);

kofc_page(
	'Officers and contacts',
	'officers',
	kofc_p( 'Sorted by the question you have, not by rank.', 'sub' )
	. kofc_rows(
		array(
			array( 'Joining the Council', 'Membership Director', kofc_u( '/more/contact/' ) ),
			array( 'Dues and payments', 'Financial Secretary', kofc_u( '/more/contact/' ) ),
			array( 'Events and volunteering', 'Program Director', kofc_u( '/more/contact/' ) ),
			array( 'Prayer requests', 'Chaplain', kofc_u( '/get-involved/prayer/#ask' ) ),
			array( 'Insurance', 'Field Agent', kofc_u( '/more/contact/' ) ),
			array( 'Anything else', 'Grand Knight', kofc_u( '/more/contact/' ) ),
		)
	)
	. kofc_card( 'card-blue', 'Full officer list', 'Names, roles and terms for every officer go here as text on the page. Updating it each July takes one edit.' )
	. kofc_p( 'Names are left out of this prototype on purpose.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Contact us',
	'contact',
	kofc_p( 'Send the Council a message and the right officer will reply by email.', 'sub' )
	. kofc_form(
		'<div class="field"><label for="c-to">Who do you want to reach? *</label><select id="c-to" name="to" required><option value="">Choose one</option><option>Joining the Council</option><option>Dues and payments</option><option>Events and volunteering</option><option>Prayer requests</option><option>Insurance</option><option>The website</option><option>Anything else</option></select></div>
<fieldset><legend>Your name *</legend><div class="pair"><span><label for="c-first">First</label><input id="c-first" name="first" autocomplete="given-name" required></span><span><label for="c-last">Last</label><input id="c-last" name="last" autocomplete="family-name" required></span></div></fieldset>
<div class="field"><label for="c-email">Your email address *</label><input id="c-email" name="email" type="email" autocomplete="email" required></div>
<div class="field"><label for="c-message">Your message *</label><textarea id="c-message" name="message" rows="7" required></textarea></div>',
		'Send message'
	)
	. kofc_p( 'One form replaces the 18 separate officer contact pages on the current site.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Recognition',
	'recognition',
	kofc_p( 'Knight and Family of the Month, Knight of the Year and Family of the Year, on one page.', 'sub' )
	. kofc_honour( 'Knight of the Month', $kofc_knight, 'This month', 'Name of the Knight', 'Two or three sentences on why he was chosen: the work he led, or the help he gave without being asked.' )
	. kofc_honour( 'Family of the Month', $kofc_family, 'This month', 'Name of the family', 'A short note on what the family did for the parish and the Council.' )
	. kofc_section( 'Knight of the Year' )
	. kofc_rows( array( array( '2025–26', 'Name appears here' ), array( '2024–25', 'Name appears here' ) ) )
	. kofc_section( 'Family of the Year' )
	. kofc_rows( array( array( '2025–26', 'Family name appears here' ), array( '2024–25', 'Family name appears here' ) ) )
	. kofc_p( 'Names are left out of this prototype on purpose.', 'fine' ),
	$kofc_more
);

/* Real names, from the current site's Past Grand Knights page (unlike the placeholder officer names). */
$kofc_pgk = array(
	'1984–85' => 'S. James Rannazzisi',
	'1985–86' => 'Al Obuchowski',
	'1986–87' => 'Ercole Barone',
	'1987–88' => 'Anthony DiGregorio',
	'1988–89' => 'Paul Muldoon',
	'1989–90' => 'Carl Kaczmarek',
	'1990–91' => 'Mike Stephens',
	'1991–92' => 'Paul Gauthier',
	'1992–93' => 'Fred Walker',
	'1993–94' => 'James W. “Jake” Jacobson',
	'1994–95' => 'Richard LaFrance',
	'1995–96' => 'Neil Buttimer',
	'1996–97' => 'Curtis Winters',
	'1997–98' => 'Pete Garry',
	'1998–99' => 'Bill Crowder',
	'1999–2000' => 'Ercole Barone',
	'2000–01' => 'Jim Cella',
	'2001–02' => 'Tim Donovan',
	'2002–03' => 'Richard Lee',
	'2003–04' => 'Mike Sakraida',
	'2004–05' => 'Kurt Meinsen',
	'2005–06' => 'Jerry Hovan',
	'2006–07' => 'Tony Vanderbeek',
	'2007–08' => 'Johnny Restivo',
	'2008–09' => 'Paul Maltagliati',
	'2009–10' => 'Dan Turgeon',
	'2010–11' => 'Don Wilkinson',
	'2011–12' => 'David Sharp',
	'2012–13' => 'R. David Lopez',
	'2013–14' => 'Fidel Rodriguez',
	'2014–15' => 'Gerard Rutkowski',
	'2015–16' => 'Jim McHugh',
	'2016–17' => 'Brian Prindle',
	'2017–18' => 'Richard Cardenas',
	'2018–19' => 'Thomas Silva',
	'2019–20' => 'Stephen Bucher',
	'2020–21' => 'Mike Mellor',
	'2021–22' => 'John Morgan',
	'2022–23' => 'Mike Mannion',
	'2023–24' => 'Gordon Goetz',
	'2024–25' => 'Joseph Minus Jr.',
	'2025–26' => 'J. Kevin O’Brien',
);
$kofc_pgk_rows = array();
foreach ( array_reverse( $kofc_pgk, true ) as $kofc_year => $kofc_name ) {
	$kofc_pgk_rows[] = array( $kofc_name, $kofc_year );
}
kofc_page(
	'Past Grand Knights',
	'past-grand-knights',
	kofc_p( 'Every Grand Knight of Council 8600, most recent first.', 'sub' ) . kofc_rows( $kofc_pgk_rows ),
	$kofc_more
);

kofc_page(
	'Photos',
	'photos',
	kofc_p( 'A permanent home for Council photos, so links never expire.', 'sub' )
	. kofc_section( 'Lenten fish fry 2026' )
	. kofc_gallery( array( array( $kofc_fish1, 'A table for everyone' ), array( $kofc_fish2, 'The parish hall on a fish fry Friday' ) ) )
	. kofc_section( 'Wreaths Across America' )
	. kofc_gallery( array( array( $kofc_wreaths, 'Honoring those who served' ) ) )
	. kofc_card( 'card-blue', 'Adding photos', 'Edit this page, click a gallery, choose Add, and drag photos in from your computer or phone.' )
	. kofc_p( 'Photographs are from the Council\'s current website.', 'fine' ),
	$kofc_more
);

/* ── Members' area: brothers sign in to read pages set to "Members only" (Council 8600 Members plugin) ── */
update_option( 'kofc_members_demo_providers', 1 ); // Show the Google and Amazon buttons as prototypes.
$kofc_members = kofc_page(
	'Members',
	'members',
	kofc_p( 'The members\' area, for brothers of Council 8600: Council emails, minutes, the budget, by-laws and the prayer list.', 'sub' )
	. kofc_shortcode( '[council_members]' )
	. kofc_card(
		'card-blue',
		'Trying the demo',
		'The demo starts you signed in as the administrator, who sees everything, so sign out first (top right). Then sign in here as <strong>brother</strong> with the password <strong>council8600</strong>. Signing in asks for a code that normally arrives by email; the demo shows it on the screen. Or ask for access with any email address, then sign in as <strong>volunteer</strong>, open <strong>Brothers</strong> in the dashboard and approve the request. One request, from Tom Sample, is already waiting. Officers find every email the demo would have sent under Tools, Demo emails.'
	)
	. kofc_section( 'Council emails', 'emails' )
	. kofc_p( 'One email a week at most, and you can stop any time.' )
	. kofc_buttons( array( array( 'Sign up for Council emails', '#' ) ) )
	. kofc_section( 'Not getting our emails?' )
	. kofc_steps(
		array(
			array( 'Look in your spam or junk folder', 'Search for "Council 8600".' ),
			array( 'Mark it "not spam"', 'This tells your email provider the messages are wanted.' ),
			array( 'Add the Council to your contacts', 'The address to save appears here.' ),
		)
	)
);

kofc_page(
	'Documents',
	'documents',
	kofc_p( 'For brothers of Council 8600 only. Please do not forward these documents outside the Council.', 'sub' )
	. kofc_rows(
		array(
			array( 'Meeting minutes', 'One entry per month' ),
			array( 'Annual budget', 'Current fraternal year' ),
			array( 'By-laws', 'As amended' ),
			array( 'Expenditure instructions', 'How to request reimbursement' ),
		)
	)
	. kofc_p( 'Sample list. No documents are included in the prototype.', 'fine' ),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Minutes, budget, by-laws and reimbursement',
		'menu_order'   => 1,
	)
);

kofc_page(
	'Prayer list',
	'prayer-list',
	kofc_p( 'Brothers and their families the Council is praying for. Shared with brothers only, so families can ask in confidence.', 'sub' )
	. kofc_rows(
		array(
			array( 'A brother recovering from surgery', 'Added this month' ),
			array( 'The family of a brother who passed away', 'Added this month' ),
			array( 'A brother\'s wife, undergoing treatment', 'Added last month' ),
		)
	)
	. kofc_p( 'Sample entries. To add a name, use the prayer request form and choose "Brothers only".', 'fine' ),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Brothers and families to pray for',
		'menu_order'   => 2,
	)
);

kofc_page(
	'Opening and Closing Ode',
	'ode',
	kofc_p( 'Sung at the start and end of Council meetings.', 'sub' )
	. kofc_section( 'Opening Ode' )
	. kofc_p( 'To the tune of “O Christmas Tree”', 'fine' )
	. kofc_p( 'Sing ye his praises loud and long,<br>And let the unenlightened know,<br>In every echo of your song,<br>The great deeds done, tho’ long ago' )
	. kofc_p( 'By Columbus of the valiant soul,<br>Who first old Neptune has controlled,<br>Despite of envy, intrigue, gold,<br>In the dim past of long ago' )
	. kofc_p( 'With vessels three o’er stormy sea,<br>He thrilled the world of long ago,<br>While wisdom linked with destiny,<br>In justice scales its weight did throw.' )
	. kofc_p( 'We are his heirs; we wear his name;<br>We boast his deeds; we spread his fame.<br>Our Order is the shining flame,<br>That lights the gloom of long ago.' )
	. kofc_section( 'Closing Ode' )
	. kofc_p( 'To the tune of “My Country ’Tis of Thee”', 'fine' )
	. kofc_p( 'Now our evening’s work is done,<br>Then let us every one,<br>Join in song.<br>Long may our Order stand<br>Foremost in this free land,<br>Ready with heart and hand<br>To right each wrong.' )
	. kofc_p( 'We have a mission great,<br>True to our Church and State,<br>Onward we move.<br>We dry the mourner’s tear,<br>The tired heart we cheer,<br>Faith in our works appear,<br>Upheld by Love.' ),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Sung at the start and end of meetings',
		'menu_order'   => 3,
	)
);

/* Council emails: the members-only list, and sample emails as they would arrive from Flocknote (council-emails.php in the Members plugin). */
kofc_page(
	'Council emails',
	'emails',
	kofc_p( 'Every email the Council has sent through Flocknote, newest first.', 'sub' )
	. kofc_shortcode( '[council_emails]' )
	. kofc_card(
		'card-blue',
		'Trying the demo',
		'These emails are made up for the demo. On the live site, each email the Council sends through Flocknote appears here by itself within the hour, once an officer pastes the Flocknote group\'s feed link under <strong>Council emails, Flocknote feed</strong> in the dashboard. Officers can also add an email by hand.'
	),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Every email the Council has sent, newest first',
		'menu_order'   => 0,
	)
);
$kofc_today  = current_time( 'timestamp' );
$kofc_on     = function ( $when ) use ( $kofc_today ) {
	return wp_date( 'l, F j', strtotime( $when, $kofc_today ), new DateTimeZone( 'UTC' ) );
};
$kofc_sign   = '<p>Vivat Jesus!<br>Fraternally,<br>Grand Knight</p>';
$kofc_emails = array(
	array(
		'Men\'s Night Out with the Pastor',
		'-1 day 20:15',
		'<p><strong>Worthy Brother Knights,</strong></p><p>The date is set for our next <strong>Men\'s Night Out with the Pastor</strong>: ' . $kofc_on( 'third friday of next month' ) . ', at 7:00 pm in Old St. Mary\'s Hall. All men of the parish and their friends are invited.</p><p>Dinner is free. Bring a favorite drink to share if you like. There will be a campfire, weather permitting, around which we will solve all the world\'s problems.</p><p>This is a "just for fun" evening hosted by the Knights. Please bring along a man from the parish who has never been to one of our events.</p>' . $kofc_sign,
	),
	array(
		'This Week: Holy Hour, International Night and the Shredding Truck',
		'-6 days 18:40',
		'<p><strong>Worthy Brother Knights,</strong></p><p>A busy week ahead. Please come to as many as you can:</p><ul><li><strong>Sacred Heart Holy Hour,</strong> Friday in the main church, right after the 7:00 pm Stations of the Cross.</li><li><strong>International Night,</strong> Saturday at 6:30 pm in St. Joseph Hall. Over 30 countries will be serving their best dishes. Tickets at the door.</li><li><strong>Shredding truck,</strong> Saturday from 10:00 am to noon in the parish parking lot. Donations support Marian Homes.</li></ul>' . $kofc_sign,
	),
	array(
		'Last Chance to Order Council Shirts',
		'-9 days 09:30',
		'<p><strong>Worthy Brother Knights,</strong></p><p>You have one more chance to order Council and Assembly shirts. We held the order a few days so our newest brothers can be included.</p><p>Reply to this email with your size and whether you would like the Council or the Assembly emblem. Orders close this Sunday.</p>' . $kofc_sign,
	),
	array(
		'Volunteers Needed: Food Pantry Collection',
		'-16 days 19:05',
		'<p><strong>Worthy Brother Knights,</strong></p><p>We need three more volunteers for the food pantry collection after all Masses on ' . $kofc_on( 'saturday next week' ) . '. Meet parishioners in the parking lot, take donations and load the van. Two hours at most.</p><p>Sign up on Signup Genius, or reply to this email.</p>' . $kofc_sign,
	),
	array(
		'Council Meeting: Rosary at 7:30, Meeting at 8:00',
		'-23 days 12:10',
		'<p><strong>Worthy Brother Knights,</strong></p><p>Our business meeting is this Tuesday at Old St. Mary\'s Hall. Supper is at 7:00 pm and the Rosary at 7:30 pm, and the meeting starts at 8:00 pm.</p><p>On the agenda: the Christmas tree lot, the fall membership drive and a vote on this year\'s charitable gifts. Refreshments afterward.</p>' . $kofc_sign,
	),
	array(
		'Christmas Tree Lot: Shift Sign-Ups Are Open',
		'-30 days 17:45',
		'<p><strong>Worthy Brother Knights,</strong></p><p>The Christmas tree lot is the Council\'s largest fundraiser, and it opens ' . $kofc_on( 'last saturday of next month' ) . '. Shifts are two hours and no experience is needed. Bring your sons: teenagers are welcome to help.</p><p>Please pick a shift on Signup Genius this week, so we know which days still need help.</p>' . $kofc_sign,
	),
	array(
		'Welcome to Our Newest Brothers',
		'-38 days 21:00',
		'<p><strong>Worthy Brother Knights,</strong></p><p>Please join me in welcoming the six men who took their Exemplification of Charity, Unity and Fraternity on Saturday. When you see them at Mass, introduce yourself and invite them to our next event.</p><p>Thank you to everyone who came to support them.</p>' . $kofc_sign,
	),
	array(
		'Welcome Back: The Council\'s Fall Schedule',
		'-52 days 10:20',
		'<p><strong>Worthy Brother Knights,</strong></p><p>I hope you all had a restful summer. Here is what is coming up this fall:</p><ul><li>Council meetings are back on the first and third Tuesdays of each month.</li><li>The COR Mass continues on the first Monday of each month at 5:30 am.</li><li>The food pantry collection, the Christmas tree lot and Wreaths Across America all need volunteers.</li></ul><p>The full calendar is on the Council website.</p>' . $kofc_sign,
	),
);
foreach ( $kofc_emails as $kofc_m ) {
	$kofc_id = wp_insert_post(
		wp_slash(
			array(
				'post_type'    => 'council_email',
				'post_status'  => 'private',
				'post_title'   => $kofc_m[0],
				'post_content' => $kofc_m[2],
				'post_date'    => gmdate( 'Y-m-d H:i:s', strtotime( $kofc_m[1], $kofc_today ) ),
			)
		)
	);
	update_post_meta( $kofc_id, '_kofc_email_sender', 'the Grand Knight' );
}

kofc_page(
	'Find us',
	'find-us',
	kofc_p( 'St. Mary of Sorrows · Fairfax Station, Virginia', 'sub' )
	. kofc_html( '<div class="map-placeholder" role="img" aria-label="Map placeholder">A map appears here</div>' )
	. kofc_buttons( array( array( 'Open in Maps', 'https://maps.google.com/?q=St.+Mary+of+Sorrows+Fairfax+Station+VA' ) ) )
	. kofc_card( 'card', 'Parking', 'Use the main lot by the church entrance. Accessible spaces are nearest the hall doors, and the hall is step-free from that side.' )
	. kofc_p( 'Sample content for the prototype.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Helpful links',
	'links',
	kofc_p( 'The handful of sites members actually ask for.', 'sub' )
	. kofc_rows(
		array(
			array( 'Knights of Columbus', 'kofc.org', 'https://www.kofc.org' ),
			array( 'Virginia State Council', 'vakofc.org', 'https://www.vakofc.org' ),
			array( 'KOVAR', 'kovarva.org', 'https://kovarva.org' ),
			array( 'Assembly 3596', 'Fourth Degree', 'http://www.assembly3596.org' ),
		)
	),
	$kofc_more
);

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $kofc_home );

/* ── Section tabs: an ordinary navigation menu officers can edit ── */
$kofc_tabs = '';
foreach ( array(
	array( 'Home', $kofc_home, 'tab-home' ),
	array( 'Events', $kofc_events, 'tab-events' ),
	array( 'Involved', $kofc_involved, 'tab-involved' ),
	array( 'Give', $kofc_give, 'tab-give' ),
	array( 'More', $kofc_more, 'tab-more' ),
	array( 'Members', $kofc_members, 'tab-members' ),
) as $kofc_t ) {
	$kofc_tabs .= '<!-- wp:navigation-link ' . wp_json_encode(
		array(
			'label'     => $kofc_t[0],
			'type'      => 'page',
			'id'        => $kofc_t[1],
			'url'       => get_permalink( $kofc_t[1] ),
			'kind'      => 'post-type',
			'className' => $kofc_t[2],
		),
		JSON_UNESCAPED_SLASHES
	) . " /-->\n";
}
wp_insert_post(
	wp_slash(
		array(
			'post_type'    => 'wp_navigation',
			'post_status'  => 'publish',
			'post_title'   => 'Sections',
			'post_name'    => 'council-sections',
			'post_content' => $kofc_tabs,
		)
	)
);

/* A volunteer login with the Editor role, for the two test tasks. */
if ( ! username_exists( 'volunteer' ) ) {
	wp_insert_user(
		array(
			'user_login'   => 'volunteer',
			'user_pass'    => 'council8600',
			'user_email'   => 'volunteer@example.com',
			'display_name' => 'Volunteer editor',
			'role'         => 'editor',
		)
	);
}

/* Members' area: an approved brother, and a request waiting for an officer. */
if ( ! username_exists( 'brother' ) ) {
	wp_insert_user(
		array(
			'user_login'   => 'brother',
			'user_pass'    => 'council8600',
			'user_email'   => 'brother@example.com',
			'first_name'   => 'John',
			'last_name'    => 'Sample',
			'display_name' => 'John Sample (demo)',
			'role'         => 'brother',
		)
	);
}
if ( ! email_exists( 'tom.sample@example.com' ) ) {
	$kofc_tom = wp_insert_user(
		array(
			'user_login'   => 'tom.sample@example.com',
			'user_pass'    => 'council8600',
			'user_email'   => 'tom.sample@example.com',
			'first_name'   => 'Tom',
			'last_name'    => 'Sample',
			'display_name' => 'Tom Sample',
			'role'         => 'brother_pending',
		)
	);
	update_user_meta( $kofc_tom, 'kofc_member_number', '1234567' );
	update_user_meta( $kofc_tom, 'kofc_phone', '(571) 555-0142' );
	update_user_meta( $kofc_tom, 'kofc_requested', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - DAY_IN_SECONDS ) );
}

flush_rewrite_rules();
echo "Council 8600 demo ready.\n";
