<?php
/**
 * Builds the Council 8600 demo site inside WordPress Playground.
 *
 * Runs once from blueprint.json after the theme and the events plugin are
 * active. Everything here is sample content: names, dates and phone numbers
 * are placeholders, and nothing is sent anywhere.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

wp_set_current_user( 1 );

/* Demo-only behaviour: emails shown on screen, and the automatic admin sign-in (see demo-only.php). */
wp_mkdir_p( WPMU_PLUGIN_DIR );
copy( __DIR__ . '/demo-only.php', WPMU_PLUGIN_DIR . '/kofc8600-demo-only.php' );

/* ── Site settings ── */
update_option( 'blogname', 'Knights of Columbus Council 8600' );
update_option( 'blogdescription', 'Fairfax Station, Virginia' );
update_option( 'blog_public', 0 ); // Prototype: ask search engines not to index.
update_option( 'timezone_string', 'America/New_York' );
global $wp_rewrite;
$wp_rewrite->set_permalink_structure( '/%postname%/' );

foreach ( get_posts( array( 'post_type' => array( 'post', 'page' ), 'numberposts' => -1, 'post_status' => 'any' ) ) as $kofc_old ) {
	wp_delete_post( $kofc_old->ID, true );
}

/* ── Block markup helpers ── */
function kofc_attrs( $attrs ) {
	return $attrs ? ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
}
function kofc_p( $html, $class = '' ) {
	$cls = $class ? ' class="' . esc_attr( $class ) . '"' : '';
	return '<!-- wp:paragraph' . kofc_attrs( $class ? array( 'className' => $class ) : array() ) . " -->\n<p$cls>$html</p>\n<!-- /wp:paragraph -->\n\n";
}
function kofc_h( $text, $level = 2, $class = '', $anchor = '' ) {
	$attrs = array();
	if ( 2 !== $level ) {
		$attrs['level'] = $level;
	}
	if ( $class ) {
		$attrs['className'] = $class;
	}
	if ( $anchor ) {
		$attrs['anchor'] = $anchor;
	}
	$id = $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '';
	return '<!-- wp:heading' . kofc_attrs( $attrs ) . " -->\n<h$level class=\"wp-block-heading" . ( $class ? " $class" : '' ) . "\"$id>$text</h$level>\n<!-- /wp:heading -->\n\n";
}
function kofc_section( $text, $anchor = '' ) {
	return kofc_h( $text, 2, '', $anchor );
}
function kofc_buttons( $buttons ) {
	$inner = '';
	foreach ( $buttons as $b ) {
		list( $text, $url ) = $b;
		$style  = isset( $b[2] ) ? $b[2] : '';
		$inner .= '<!-- wp:button' . kofc_attrs( $style ? array( 'className' => "is-style-$style" ) : array() ) . " -->\n"
			. '<div class="wp-block-button' . ( $style ? " is-style-$style" : '' ) . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . "\">$text</a></div>\n<!-- /wp:button -->\n\n";
	}
	return "<!-- wp:buttons -->\n<div class=\"wp-block-buttons\">" . rtrim( $inner ) . "</div>\n<!-- /wp:buttons -->\n\n";
}
function kofc_group( $inner, $class, $lock = false ) {
	$attrs = array( 'className' => $class );
	if ( $lock ) {
		$attrs['templateLock'] = 'contentOnly';
	}
	$attrs['layout'] = array( 'type' => 'default' );
	return '<!-- wp:group' . kofc_attrs( $attrs ) . " -->\n<div class=\"wp-block-group $class\">" . trim( $inner ) . "</div>\n<!-- /wp:group -->\n\n";
}
function kofc_columns( $left, $right ) {
	return "<!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column -->\n<div class=\"wp-block-column\">" . trim( $left )
		. "</div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\">" . trim( $right ) . "</div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->\n\n";
}
function kofc_rows( $rows ) {
	$inner = '';
	foreach ( $rows as $r ) {
		list( $title, $sub ) = $r;
		$url  = isset( $r[2] ) ? $r[2] : '';
		$icon = isset( $r[3] ) ? " icon-{$r[3]}" : '';
		if ( $url ) {
			$html = '<a href="' . esc_url( $url ) . "\"><strong>$title</strong>" . ( $sub ? "<span>$sub</span>" : '' ) . '</a>';
		} else {
			$html = "<span class=\"row-text\"><strong>$title</strong>" . ( $sub ? "<span class=\"row-sub\">$sub</span>" : '' ) . '</span>';
		}
		$inner .= kofc_p( $html, "row$icon" );
	}
	return kofc_group( $inner, 'rows' );
}
function kofc_callstrip( $icon, $title, $sub, $url ) {
	return kofc_p( '<a href="' . esc_url( $url ) . "\"><strong>$title</strong><span>$sub</span></a>", "callstrip icon-$icon" );
}
function kofc_card( $style, $title, $text, $buttons = array(), $lock = false ) {
	return kofc_group( kofc_h( $title, 3 ) . kofc_p( $text ) . ( $buttons ? kofc_buttons( $buttons ) : '' ), "is-style-$style", $lock );
}
function kofc_html( $html ) {
	return "<!-- wp:html -->\n$html\n<!-- /wp:html -->\n\n";
}
function kofc_shortcode( $code ) {
	return "<!-- wp:shortcode -->\n$code\n<!-- /wp:shortcode -->\n\n";
}
function kofc_steps( $items ) {
	$inner = '';
	foreach ( $items as $i ) {
		$inner .= "<!-- wp:list-item -->\n<li><strong>{$i[0]}</strong>{$i[1]}</li>\n<!-- /wp:list-item -->\n\n";
	}
	return "<!-- wp:list {\"ordered\":true,\"className\":\"is-style-steps\"} -->\n<ol class=\"wp-block-list is-style-steps\">" . rtrim( $inner ) . "</ol>\n<!-- /wp:list -->\n\n";
}
function kofc_image_inner( $id, $caption = '', $size = 'large' ) {
	$src = wp_get_attachment_image_url( $id, $size );
	$alt = esc_attr( get_post_meta( $id, '_wp_attachment_image_alt', true ) );
	$cap = $caption ? "<figcaption class=\"wp-element-caption\">$caption</figcaption>" : '';
	return "<!-- wp:image {\"id\":$id,\"sizeSlug\":\"$size\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-$size\"><img src=\"$src\" alt=\"$alt\" class=\"wp-image-$id\"/>$cap</figure>\n<!-- /wp:image -->";
}
function kofc_gallery( $images ) {
	$inner = array();
	foreach ( $images as $img ) {
		$inner[] = kofc_image_inner( $img[0], $img[1] );
	}
	return "<!-- wp:gallery {\"linkTo\":\"none\"} -->\n<figure class=\"wp-block-gallery has-nested-images columns-default is-cropped\">" . implode( "\n\n", $inner ) . "</figure>\n<!-- /wp:gallery -->\n\n";
}
function kofc_pattern( $slug ) {
	$pattern = WP_Block_Patterns_Registry::get_instance()->get_registered( "kofc8600/$slug" );
	return $pattern ? trim( $pattern['content'] ) . "\n\n" : '';
}
/* A pattern with its placeholder photos swapped, in order, for uploaded ones. */
function kofc_pattern_photos( $slug, $ids ) {
	return preg_replace_callback(
		'/<!-- wp:image .*?<!-- \/wp:image -->/s',
		function ( $m ) use ( &$ids ) {
			return $ids ? kofc_image_inner( array_shift( $ids ) ) : $m[0];
		},
		kofc_pattern( $slug )
	);
}
function kofc_honour( $label, $photo_id, $when, $name, $text ) {
	$photo = kofc_image_inner( $photo_id, '', 'medium' );
	$inner = kofc_section( $label )
		. "<!-- wp:columns {\"verticalAlignment\":\"center\"} -->\n<div class=\"wp-block-columns are-vertically-aligned-center\"><!-- wp:column {\"verticalAlignment\":\"center\",\"width\":\"220px\"} -->\n<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:220px\">$photo</div>\n<!-- /wp:column -->\n\n"
		. "<!-- wp:column {\"verticalAlignment\":\"center\"} -->\n<div class=\"wp-block-column is-vertically-aligned-center\">" . trim( kofc_p( $when, 'kotm-month' ) . kofc_h( $name, 3 ) . kofc_p( $text ) ) . "</div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->";
	return kofc_group( $inner, 'kotm', true );
}
function kofc_media( $file, $title, $alt, $caption = '' ) {
	$upload = wp_upload_bits( $file, null, file_get_contents( __DIR__ . "/media/$file" ) );
	$type   = wp_check_filetype( $upload['file'] );
	$id     = wp_insert_attachment(
		array(
			'post_title'     => $title,
			'post_excerpt'   => $caption,
			'post_mime_type' => $type['type'],
			'post_status'    => 'inherit',
		),
		$upload['file']
	);
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return $id;
}
function kofc_page( $title, $slug, $content, $parent = 0, $extra = array() ) {
	return wp_insert_post(
		wp_slash(
			array_merge(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_parent'  => $parent,
					'post_content' => $content,
				),
				$extra
			)
		)
	);
}
function kofc_u( $path ) {
	return home_url( $path );
}
function kofc_form( $fields_html, $button ) {
	return kofc_html( "<form class=\"council-form\" data-demo>\n<p class=\"fine\">Fields marked * are required.</p>\n$fields_html\n<button type=\"submit\">$button</button>\n<p role=\"status\"></p>\n</form>" );
}

/* ── Photos and placeholders ── */
$kofc_wreaths  = kofc_media( 'wreaths.jpg', 'Wreaths Across America', 'A color guard carrying flags leads a procession along a brick path.', 'Wreaths Across America' );
$kofc_fish1    = kofc_media( 'fish-fry-1.jpg', 'Fish fry, dining room', 'Parishioners share a meal and conversation around tables at the fish fry.', 'A table for everyone at the Lenten fish fry' );
$kofc_fish2    = kofc_media( 'fish-fry-2.jpg', 'Fish fry, serving line', 'A serving table overlooks a parish hall filled with people enjoying the fish fry.', 'The parish hall on a fish fry Friday' );
$kofc_knight   = kofc_media( 'knight-photo-placeholder.png', 'Knight of the Month (placeholder)', 'Placeholder photo for the Knight of the Month' );
$kofc_family   = kofc_media( 'family-photo-placeholder.png', 'Family of the Month (placeholder)', 'Placeholder photo for the Family of the Month' );
$kofc_newphoto = kofc_media( 'new-knight-photo.png', 'New Knight of the Month photo (for the test task)', 'Photo of the new Knight of the Month' );

/* ── Program owners: each can edit only the pages and events they are the Author of ── */
function kofc_owner( $login, $name ) {
	$id = username_exists( $login );
	return $id ? $id : wp_insert_user(
		array(
			'user_login'   => $login,
			'user_pass'    => 'council8600',
			'user_email'   => "$login@example.com",
			'display_name' => $name,
			'role'         => 'program_owner',
		)
	);
}
$kofc_faith_owner = kofc_owner( 'faith', 'Faith Director (demo)' );
$kofc_cor_owner   = kofc_owner( 'cor', 'COR coordinator (demo)' );

/* ── Pages ── */
$kofc_home = kofc_page(
	'Home',
	'home',
	kofc_pattern_photos( 'hero', array( $kofc_wreaths, $kofc_fish2, $kofc_fish1 ) ) . kofc_pattern( 'quick-tasks' )
	. kofc_columns( kofc_pattern( 'coming-up' ), kofc_pattern( 'new-here' ) )
);

$kofc_events = kofc_page(
	'Events and calendar',
	'events',
	kofc_p( 'Everything the Council has scheduled. Nothing to download, nothing to zoom into.', 'sub' )
	. kofc_columns(
		kofc_section( 'Coming up' ) . kofc_shortcode( '[council_events count="12"]' ),
		kofc_card( 'card-blue', 'Never check the website again', 'Subscribe once and every Council event appears on your own phone calendar, including any changes made later.', array( array( 'Add Council events to my phone', '#' ) ) )
		. kofc_card( 'card', 'The full Council calendar', 'On the live site, the Council\'s Google Calendar can appear here as well, so officers keep using the calendar they already know.' )
	)
);

$kofc_involved = kofc_page(
	'Get involved',
	'get-involved',
	kofc_p( 'Four ways in. Pick whichever fits the time you have this month.', 'sub' )
	. kofc_columns(
		kofc_section( 'Become a member' )
		. kofc_card( 'card-gold', 'Join the Knights', 'Catholic men 18 and older. About ten minutes to start, then a member calls you. No obligation.', array( array( 'How to join', kofc_u( '/get-involved/join/' ), 'gold' ) ) )
		. kofc_section( 'Help at an event', 'volunteer' )
		. kofc_p( 'Volunteer sign-ups stay on SignUpGenius, which the Council already uses. Pick a shift and it sends you a reminder.' )
		. kofc_buttons( array( array( 'See open sign-ups', 'https://www.signupgenius.com/' ) ) ),
		kofc_section( 'Prayer' )
		. kofc_card( 'card', 'Prayer requests', 'Ask the Council to pray for someone, or read this week\'s intentions.', array( array( 'Ask for prayers', kofc_u( '/get-involved/prayer/#ask' ) ), array( 'Read the prayer list', kofc_u( '/get-involved/prayer/' ), 'outline' ) ) )
		. kofc_section( 'Our programs' )
		. kofc_rows(
			array(
				array( 'Faith', 'Adoration, Memorial Masses, OCIA', kofc_u( '/get-involved/programs/faith/' ), 'cross' ),
				array( 'Family', 'Picnic, pancake breakfasts, Christmas party', kofc_u( '/get-involved/programs/family/' ), 'home' ),
				array( 'Community', 'Christmas trees, fish fry, food baskets', kofc_u( '/get-involved/programs/community/' ), 'hands' ),
				array( 'Culture of Life', 'Adoration for life, pregnancy centers', kofc_u( '/get-involved/programs/life/' ), 'heart' ),
			)
		)
		. kofc_section( 'Our initiatives' )
		. kofc_rows(
			array(
				array( 'Initiatives', 'Cor, the COR Mass, Faith and Fun nights', kofc_u( '/get-involved/programs/initiatives/' ), 'star' ),
			)
		)
	)
);

kofc_page(
	'Join the Knights',
	'join',
	kofc_p( 'Practicing Catholic men, 18 and older. That is the only requirement.', 'sub' )
	. kofc_steps(
		array(
			array( 'Fill in the form', 'Name, email and phone. About ten minutes.' ),
			array( 'A member calls you', 'Usually within a week. Ask anything; there is no obligation.' ),
			array( 'Come to a meeting', 'Bring your questions. Families are welcome at Council socials.' ),
		)
	)
	. kofc_buttons( array( array( 'Start my membership', '#', 'gold' ), array( 'Ask a question first', kofc_u( '/more/contact/' ), 'outline' ) ) )
	. kofc_card( 'card-blue', 'What it costs', 'Annual Council dues, payable each January. Members having difficulty should speak to the Grand Knight. Nobody is turned away over dues.' )
	. kofc_p( 'Sample content for the prototype.', 'fine' ),
	$kofc_involved
);

function kofc_activity( $name, $line, $facts = '', $more = '', $link = array() ) {
	$inner = kofc_h( $name, 3 ) . kofc_p( $line );
	if ( $facts ) {
		$inner .= kofc_p( $facts, 'facts' );
	}
	if ( $more ) {
		$inner .= "<!-- wp:details -->\n<details class=\"wp-block-details\"><summary>More about this</summary>" . trim( kofc_p( $more ) ) . "</details>\n<!-- /wp:details -->\n\n";
	}
	if ( $link ) {
		$inner .= kofc_p( '<a href="' . esc_url( $link[1] ) . '">' . $link[0] . '</a>', 'more-link' );
	}
	return kofc_group( $inner, 'is-style-card program' );
}
function kofc_activities( $items ) {
	$cards = '';
	foreach ( $items as $i ) {
		$cards .= call_user_func_array( 'kofc_activity', $i );
	}
	return kofc_group( $cards, 'program-grid' );
}
function kofc_program_page( $title, $slug, $intro, $owner, $items, $parent, $author = 1 ) {
	return kofc_page(
		$title,
		$slug,
		kofc_p( $intro, 'sub' ) . kofc_activities( $items )
		. kofc_p( "This page is kept up to date by the $owner. Sample content: confirm details before launch.", 'fine' ),
		$parent,
		array( 'post_author' => $author )
	);
}

$kofc_programs = kofc_page(
	'Our programs',
	'programs',
	kofc_p( 'The Council\'s work, grouped the way the Knights of Columbus organize it. Choose a program to see its activities.', 'sub' )
	. kofc_activities(
		array(
			array( 'Faith', 'Prayer, the sacraments and service to the parish.', 'First Friday Adoration · Memorial Masses · OCIA', '', array( 'Faith activities', kofc_u( '/get-involved/programs/faith/' ) ) ),
			array( 'Family', 'Events that bring Council families and the parish together.', 'Labor Day picnic · Bingo · Pancake breakfasts', '', array( 'Family activities', kofc_u( '/get-involved/programs/family/' ) ) ),
			array( 'Community', 'Charity in Fairfax Station and beyond.', 'Christmas trees · Lenten fish fry · Food baskets', '', array( 'Community activities', kofc_u( '/get-involved/programs/community/' ) ) ),
			array( 'Culture of Life', 'Prayer and practical help for mothers and children.', 'Diaper drive · Respect Life Month · March for Life', '', array( 'Culture of Life activities', kofc_u( '/get-involved/programs/life/' ) ) ),
		)
	)
	. kofc_p( 'Each program has a director who keeps its page up to date.', 'fine' )
	. kofc_section( 'Our initiatives', 'initiatives' )
	. kofc_p( 'Council work that runs alongside the four programs: Cor, the COR Mass and Faith and Fun nights.', 'sub' )
	. kofc_buttons( array( array( 'See our initiatives', kofc_u( '/get-involved/programs/initiatives/' ), 'outline' ) ) ),
	$kofc_involved
);

kofc_program_page(
	'Faith',
	'faith',
	'Knights serve the parish as lectors, ushers, Eucharistic ministers and catechists.',
	'Faith Director',
	array(
		array( 'First Friday Adoration', 'An hour of prayer before the Blessed Sacrament.', 'First Fridays · from 7:00 pm · Church', 'Sign up online for an hour. Early-morning hours are the hardest to fill.' ),
		array( 'Memorial Masses', 'Masses offered for deceased Knights of the Council.' ),
		array( 'Founder\'s Day Mass', 'Mass marking the founding of the Knights of Columbus.' ),
		array( 'OCIA support', 'Helping adults who are exploring or returning to the Catholic faith.', '', 'Know someone who comes to Mass but is not Catholic, or who never received all the sacraments? Introduce them to the parish OCIA team.' ),
		array( 'Keep Christ in Christmas', 'An Advent campaign and a poster contest for young people.', 'Advent' ),
		array( 'Communion to the homebound', 'Bringing the Eucharist to parishioners who cannot come to Mass.' ),
	),
	$kofc_programs,
	$kofc_faith_owner
);

kofc_program_page(
	'Family',
	'family',
	'Events that bring Council families and the parish together.',
	'Family Director',
	array(
		array( 'Labor Day picnic', 'A picnic for Knights and their families.', 'Labor Day' ),
		array( 'Bingo', 'Bingo nights, with food, in the parish hall.', 'Farrell Hall · 6:30 pm' ),
		array( 'Pancake breakfasts', 'Breakfasts cooked and served by Knights.' ),
		array( 'Children\'s Christmas party', 'A Christmas party for the children of the parish.', 'December' ),
		array( 'Spaghetti dinners and International Night', 'Dinners that bring the parish together.' ),
		array( 'Scouting and Vacation Bible School', 'Support for the parish\'s youth programs.' ),
		array( 'Young Man and Young Woman of the Year', 'Recognition for young people of the parish.' ),
	),
	$kofc_programs
);

kofc_program_page(
	'Community',
	'community',
	'Charity in Fairfax Station and beyond.',
	'Community Director',
	array(
		array( 'Christmas tree sales', 'One of the Council\'s largest fundraisers.', 'Christmas season · Shifts on Signup Genius' ),
		array( 'Lenten fish fry', '1,179 dinners served during Lent 2026.', 'Fridays in Lent' ),
		array( 'Thanksgiving and Christmas food baskets', 'Holiday meals for families in need.', 'Thanksgiving and Christmas' ),
		array( 'Coats for Kids', 'New winter coats for children who need them.' ),
		array( 'Route 123 cleanup', 'The Council\'s Adopt-a-Highway stretch of Route 123.', 'Meet at Old St. Mary\'s Hall · Sign up on Signup Genius' ),
		array( 'Wreaths Across America', 'Laying wreaths to honor veterans.', 'December' ),
		array( 'Scholarships', 'College scholarships for students from parish and Council families.' ),
		array( 'Soccer challenge', 'Youth soccer and free-throw competitions.' ),
		array( 'Blood drives', 'Blood drives for the community.' ),
		array( 'KOVAR', 'Support for Virginians with intellectual disabilities.' ),
	),
	$kofc_programs
);

kofc_program_page(
	'Culture of Life',
	'life',
	'Prayer and practical help for mothers and children.',
	'Culture of Life Director',
	array(
		array( 'Diaper, wipes and formula drive', 'Collected for mothers and babies in need.', '4th Sunday of each month' ),
		array( 'Pregnancy resource centers', 'Time and donations for local pregnancy centers.', '', 'Centers the Council supports include the MaRiH Center, A Best Choice, the Paul Stefan Home and House of Mercy.' ),
		array( 'Adoration for life', 'Praying for life before the Blessed Sacrament.' ),
		array( 'Silver Rose', 'A rosary pilgrimage praying for respect for life.' ),
		array( 'Respect Life Month', 'Prayer and events for life.', 'October' ),
		array( 'March for Life', 'Joining the national and Virginia marches.', 'National march: January' ),
		array( 'Choose Life license plates', 'Virginia\'s Choose Life license plate campaign.' ),
	),
	$kofc_programs
);

$kofc_initiatives = kofc_program_page(
	'Initiatives',
	'initiatives',
	'Council work that runs alongside the four programs.',
	'Grand Knight',
	array(
		array( 'Cor: Evangelization and Faith Formation', 'The Knights of Columbus initiative for prayer, formation and fraternity.', 'Open to all men of the parish' ),
		array( 'COR Mass', 'An early Mass for parishioners who start work early.', 'First Mondays · 5:30 am · Main church', '', array( 'About the COR Mass', kofc_u( '/get-involved/programs/initiatives/cor-mass/' ) ) ),
		array( 'Faith and Fun nights', 'Fellowship evenings with a short talk on the faith.', '', 'The Lenten trivia night paired trivia games with a talk on living Lent well.' ),
	),
	$kofc_programs
);

kofc_page(
	'COR Mass',
	'cor-mass',
	kofc_p( 'An early Mass on the first Monday of each month, for parishioners who start work early.', 'sub' )
	. kofc_card( 'card-blue', 'When and where', 'First Monday of each month at 5:30 am, in the main church at St. Mary of Sorrows. Open to all parishioners. Scheduled through June 2027.' )
	. kofc_h( 'Why an early Mass' )
	. kofc_p( 'Many parishioners have to be at work before the regular daily Masses. This Mass lets them start the week at Mass.' )
	. kofc_h( 'Part of Cor' )
	. kofc_p( 'The COR Mass is hosted by the Council\'s Cor initiative: the Knights of Columbus program of prayer, formation and fraternity for men.' )
	. kofc_buttons( array( array( 'Add to my calendar', '#', 'outline' ) ) )
	. kofc_p( 'This page is kept up to date by the COR coordinator.', 'fine' ),
	$kofc_initiatives,
	array( 'post_author' => $kofc_cor_owner )
);

kofc_page(
	'Prayer requests',
	'prayer',
	kofc_p( 'The Council prays for these intentions at every meeting.', 'sub' )
	. kofc_section( 'This week\'s intentions' )
	. kofc_rows(
		array(
			array( 'For the sick of our parish', 'Added this week' ),
			array( 'For the repose of our departed members', 'Ongoing' ),
			array( 'For vocations to the priesthood', 'Ongoing' ),
			array( 'For families in need in our community', 'Added last week' ),
		)
	)
	. kofc_section( 'Ask for prayers', 'ask' )
	. kofc_form(
		'<div class="field"><label for="p-name">Your name *</label><input id="p-name" name="name" autocomplete="name" required></div>
<div class="field"><label for="p-email">Your email address *</label><input id="p-email" name="email" type="email" autocomplete="email" required></div>
<div class="field"><label for="p-for">Who is the request for? *</label><input id="p-for" name="for" required></div>
<div class="field"><label for="p-text">Your request *</label><textarea id="p-text" name="request" rows="5" required></textarea></div>
<label class="check"><input type="checkbox" name="permission" required> <span>I have permission to share this request. *</span></label>',
		'Send prayer request'
	)
	. kofc_p( 'Requests are read by an officer before they appear on the list.', 'fine' ),
	$kofc_involved
);

$kofc_give = kofc_page(
	'Give',
	'give',
	kofc_p( 'Dues and donations in one place, on one payment system.', 'sub' )
	. kofc_columns(
		kofc_section( 'Council dues' )
		. kofc_card( 'card-gold', 'Annual Council dues', 'Due each January. Pay by card in about two minutes, or mail a check if you prefer.', array( array( 'Pay dues', kofc_u( '/give/pay/' ), 'gold' ) ) )
		. kofc_section( 'Support a cause' )
		. kofc_rows(
			array(
				array( 'Parish food pantry', 'Feeds local families year-round', kofc_u( '/give/pay/#donate' ) ),
				array( 'KOVAR', 'Virginians with intellectual disabilities', kofc_u( '/give/pay/#donate' ) ),
				array( 'Council scholarships', 'For parish and school students', kofc_u( '/give/pay/#donate' ) ),
			)
		),
		kofc_section( 'What your giving did' )
		. kofc_group( kofc_p( '<strong>1,179</strong>Fish fry dinners', 'stat' ) . kofc_p( '<strong>183</strong>Volunteers', 'stat' ) . kofc_p( '<strong>565</strong>Service hours', 'stat' ), 'stats', true )
		. kofc_p( '2026 Lenten program, as reported on the Council\'s current website.', 'fine' )
		. kofc_card( 'card-blue', 'Where the money goes', 'Annual accounts are presented at the business meeting, and any member may ask to see them.' )
	)
);

kofc_page(
	'Pay dues or donate',
	'pay',
	kofc_p( 'About two minutes by card, Apple Pay or Google Pay.', 'sub' )
	. kofc_html( '<div class="pay-placeholder"><strong>The payment form appears here</strong>On the live site this is an embedded Zeffy form: dues for each membership type, with optional yearly renewal, plus donations and event tickets. Members never leave the Council\'s page.</div>' )
	. kofc_section( 'Donate to a cause', 'donate' )
	. kofc_p( 'The same form takes donations to the food pantry, KOVAR and Council scholarships.' )
	. kofc_card( 'card', 'Prefer to mail a check?', 'Make it payable to Knights of Columbus Council 8600 and mail it to the Financial Secretary. The address appears here, as text, with no PDF to open.' )
	. kofc_card( 'card-blue', 'Not sure whether you\'ve paid?', 'Call the Financial Secretary. He can check in a moment.', array( array( 'Call the Financial Secretary', 'tel:+15715550100', 'outline' ) ) )
	. kofc_p( 'Sample content. Phone numbers in this prototype are placeholders.', 'fine' ),
	$kofc_give
);

$kofc_more = kofc_page(
	'More',
	'more',
	kofc_p( 'Everything else, one tap away.', 'sub' )
	. kofc_columns(
		kofc_section( 'About the Council' )
		. kofc_rows(
			array(
				array( 'Officers and contacts', 'Who to contact about what', kofc_u( '/more/officers/' ), 'people' ),
				array( 'Recognition', 'Knight and Family of the Month, Knight of the Year', kofc_u( '/more/recognition/' ), 'award' ),
				array( 'Photos', 'Council events, by year', kofc_u( '/more/photos/' ), 'camera' ),
			)
		)
		. kofc_callstrip( 'mail', 'Contact us', 'Send the Council a message', kofc_u( '/more/contact/' ) )
		. kofc_callstrip( 'pin', 'Find us', 'St. Mary of Sorrows · Fairfax Station, VA', kofc_u( '/more/find-us/' ) ),
		kofc_section( 'For members' )
		. kofc_rows(
			array(
				array( 'Members\' area', 'Sign in, or ask for access', kofc_u( '/members/' ), 'lock' ),
				array( 'Council emails', 'Sign up, or fix emails going to spam', kofc_u( '/members/#emails' ), 'mail' ),
				array( 'Helpful links', 'Supreme, State Council and charities', kofc_u( '/more/links/' ), 'link' ),
			)
		)
	)
);

kofc_page(
	'Officers and contacts',
	'officers',
	kofc_p( 'Sorted by the question you have, not by rank.', 'sub' )
	. kofc_rows(
		array(
			array( 'Joining the Council', 'Membership Director', kofc_u( '/more/contact/' ) ),
			array( 'Dues and payments', 'Financial Secretary', kofc_u( '/more/contact/' ) ),
			array( 'Events and volunteering', 'Program Director', kofc_u( '/more/contact/' ) ),
			array( 'Prayer requests', 'Chaplain', kofc_u( '/get-involved/prayer/#ask' ) ),
			array( 'Insurance', 'Field Agent', kofc_u( '/more/contact/' ) ),
			array( 'Anything else', 'Grand Knight', kofc_u( '/more/contact/' ) ),
		)
	)
	. kofc_card( 'card-blue', 'Full officer list', 'Names, roles and terms for every officer go here as text on the page. Updating it each July takes one edit.' )
	. kofc_p( 'Names are left out of this prototype on purpose.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Contact us',
	'contact',
	kofc_p( 'Send the Council a message and the right officer will reply by email.', 'sub' )
	. kofc_form(
		'<div class="field"><label for="c-to">Who do you want to reach? *</label><select id="c-to" name="to" required><option value="">Choose one</option><option>Joining the Council</option><option>Dues and payments</option><option>Events and volunteering</option><option>Prayer requests</option><option>Insurance</option><option>The website</option><option>Anything else</option></select></div>
<fieldset><legend>Your name *</legend><div class="pair"><span><label for="c-first">First</label><input id="c-first" name="first" autocomplete="given-name" required></span><span><label for="c-last">Last</label><input id="c-last" name="last" autocomplete="family-name" required></span></div></fieldset>
<div class="field"><label for="c-email">Your email address *</label><input id="c-email" name="email" type="email" autocomplete="email" required></div>
<div class="field"><label for="c-message">Your message *</label><textarea id="c-message" name="message" rows="7" required></textarea></div>',
		'Send message'
	)
	. kofc_p( 'One form replaces the 18 separate officer contact pages on the current site.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Recognition',
	'recognition',
	kofc_p( 'Knight and Family of the Month, Knight of the Year and Family of the Year, on one page.', 'sub' )
	. kofc_honour( 'Knight of the Month', $kofc_knight, 'This month', 'Name of the Knight', 'Two or three sentences on why he was chosen: the work he led, or the help he gave without being asked.' )
	. kofc_honour( 'Family of the Month', $kofc_family, 'This month', 'Name of the family', 'A short note on what the family did for the parish and the Council.' )
	. kofc_section( 'Knight of the Year' )
	. kofc_rows( array( array( '2025–26', 'Name appears here' ), array( '2024–25', 'Name appears here' ) ) )
	. kofc_section( 'Family of the Year' )
	. kofc_rows( array( array( '2025–26', 'Family name appears here' ), array( '2024–25', 'Family name appears here' ) ) )
	. kofc_p( 'Names are left out of this prototype on purpose.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Photos',
	'photos',
	kofc_p( 'A permanent home for Council photos, so links never expire.', 'sub' )
	. kofc_section( 'Lenten fish fry 2026' )
	. kofc_gallery( array( array( $kofc_fish1, 'A table for everyone' ), array( $kofc_fish2, 'The parish hall on a fish fry Friday' ) ) )
	. kofc_section( 'Wreaths Across America' )
	. kofc_gallery( array( array( $kofc_wreaths, 'Honoring those who served' ) ) )
	. kofc_card( 'card-blue', 'Adding photos', 'Edit this page, click a gallery, choose Add, and drag photos in from your computer or phone.' )
	. kofc_p( 'Photographs are from the Council\'s current website.', 'fine' ),
	$kofc_more
);

/* ── Members' area: brothers sign in to read pages set to "Members only" (Council 8600 Members plugin) ── */
update_option( 'kofc_members_demo_providers', 1 ); // Show the Google and Amazon buttons as prototypes.
$kofc_members = kofc_page(
	'Members',
	'members',
	kofc_p( 'The members\' area, for brothers of Council 8600: minutes, the budget, by-laws and the prayer list.', 'sub' )
	. kofc_shortcode( '[council_members]' )
	. kofc_card(
		'card-blue',
		'Trying the demo',
		'The demo starts you signed in as the administrator, who sees everything, so sign out first (top right). Then sign in here as <strong>brother</strong> with the password <strong>council8600</strong>. Signing in asks for a code that normally arrives by email; the demo shows it on the screen. Or ask for access with any email address, then sign in as <strong>volunteer</strong>, open <strong>Brothers</strong> in the dashboard and approve the request. One request, from Tom Sample, is already waiting. Officers find every email the demo would have sent under Tools, Demo emails.'
	)
	. kofc_section( 'Council emails', 'emails' )
	. kofc_p( 'One email a week at most, and you can stop any time.' )
	. kofc_buttons( array( array( 'Sign up for Council emails', '#' ) ) )
	. kofc_section( 'Not getting our emails?' )
	. kofc_steps(
		array(
			array( 'Look in your spam or junk folder', 'Search for "Council 8600".' ),
			array( 'Mark it "not spam"', 'This tells your email provider the messages are wanted.' ),
			array( 'Add the Council to your contacts', 'The address to save appears here.' ),
		)
	)
);

kofc_page(
	'Documents',
	'documents',
	kofc_p( 'For brothers of Council 8600 only. Please do not forward these documents outside the Council.', 'sub' )
	. kofc_rows(
		array(
			array( 'Meeting minutes', 'One entry per month' ),
			array( 'Annual budget', 'Current fraternal year' ),
			array( 'By-laws', 'As amended' ),
			array( 'Expenditure instructions', 'How to request reimbursement' ),
		)
	)
	. kofc_p( 'Sample list. No documents are included in the prototype.', 'fine' ),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Minutes, budget, by-laws and reimbursement',
		'menu_order'   => 1,
	)
);

kofc_page(
	'Prayer list',
	'prayer-list',
	kofc_p( 'Brothers and their families the Council is praying for. Shared with brothers only, so families can ask in confidence.', 'sub' )
	. kofc_rows(
		array(
			array( 'A brother recovering from surgery', 'Added this month' ),
			array( 'The family of a brother who passed away', 'Added this month' ),
			array( 'A brother\'s wife, undergoing treatment', 'Added last month' ),
		)
	)
	. kofc_p( 'Sample entries. To add a name, use the prayer request form and choose "Brothers only".', 'fine' ),
	$kofc_members,
	array(
		'post_status'  => 'private',
		'post_excerpt' => 'Brothers and families to pray for',
		'menu_order'   => 2,
	)
);

kofc_page(
	'Find us',
	'find-us',
	kofc_p( 'St. Mary of Sorrows · Fairfax Station, Virginia', 'sub' )
	. kofc_html( '<div class="map-placeholder" role="img" aria-label="Map placeholder">A map appears here</div>' )
	. kofc_buttons( array( array( 'Open in Maps', 'https://maps.google.com/?q=St.+Mary+of+Sorrows+Fairfax+Station+VA' ) ) )
	. kofc_card( 'card', 'Parking', 'Use the main lot by the church entrance. Accessible spaces are nearest the hall doors, and the hall is step-free from that side.' )
	. kofc_p( 'Sample content for the prototype.', 'fine' ),
	$kofc_more
);

kofc_page(
	'Helpful links',
	'links',
	kofc_p( 'The handful of sites members actually ask for.', 'sub' )
	. kofc_rows(
		array(
			array( 'Knights of Columbus', 'kofc.org', 'https://www.kofc.org' ),
			array( 'Virginia State Council', 'vakofc.org', 'https://www.vakofc.org' ),
			array( 'KOVAR', 'kovarva.org', 'https://kovarva.org' ),
			array( 'Assembly 3596', 'Fourth Degree', 'http://www.assembly3596.org' ),
		)
	),
	$kofc_more
);

/* ── Sample events, dated relative to today so the demo never looks stale ── */
$kofc_now    = current_time( 'timestamp' );
$kofc_sample = array(
	array( 'Council business meeting', 'second tuesday of next month', '7:30 pm', 'Parish Hall', '', 'Open to all members. Rosary at 7:00 pm beforehand for those who would like to come early. Refreshments afterward.' ),
	array( 'Food pantry collection', 'saturday next week', 'After all Masses', 'Parish parking lot', '3 volunteers still needed', 'Meet parishioners in the parking lot, take donations and load the van. Two hours at most.' ),
	array( 'Officers\' meeting', 'fourth tuesday of next month', '7:00 pm', 'Room 202', '', 'Officers and directors. Members are welcome to bring an item for the agenda.' ),
	array( 'Christmas tree lot opens', 'last saturday of next month', '9:00 am', 'Parish parking lot', 'Shift sign-ups open now', 'The Council\'s largest fundraiser. Shifts are two hours; no experience needed.' ),
	array( 'Wreaths Across America', 'second saturday of +2 months', '8:00 am', 'Meet at the parish lot to carpool', '', 'Laying wreaths to honor veterans. Dress warmly.' ),
	array( 'COR Mass', 'first monday of next month', '5:30 am', 'Main church', '', 'An early Mass for parishioners who start work early. Hosted by the Council\'s Cor initiative.', 'cor' ),
	array( 'Chili Cook-Off', 'yesterday', '6:00 pm', 'Parish Hall', '', 'A past event, kept to show that past events drop off the list on their own.' ),
);
foreach ( $kofc_sample as $kofc_e ) {
	$kofc_id = wp_insert_post(
		wp_slash(
			array(
				'post_type'    => 'event',
				'post_status'  => 'publish',
				'post_title'   => $kofc_e[0],
				'post_content' => kofc_p( $kofc_e[5] ),
				'post_author'  => isset( $kofc_e[6] ) ? $kofc_cor_owner : 1,
			)
		)
	);
	update_post_meta( $kofc_id, '_event_date', gmdate( 'Y-m-d', strtotime( $kofc_e[1], $kofc_now ) ) );
	update_post_meta( $kofc_id, '_event_time', $kofc_e[2] );
	update_post_meta( $kofc_id, '_event_place', $kofc_e[3] );
	update_post_meta( $kofc_id, '_event_note', $kofc_e[4] );
}

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $kofc_home );

/* ── Section tabs: an ordinary navigation menu officers can edit ── */
$kofc_tabs = '';
foreach ( array(
	array( 'Home', $kofc_home, 'tab-home' ),
	array( 'Events', $kofc_events, 'tab-events' ),
	array( 'Involved', $kofc_involved, 'tab-involved' ),
	array( 'Give', $kofc_give, 'tab-give' ),
	array( 'More', $kofc_more, 'tab-more' ),
	array( 'Members', $kofc_members, 'tab-members' ),
) as $kofc_t ) {
	$kofc_tabs .= '<!-- wp:navigation-link ' . wp_json_encode(
		array(
			'label'     => $kofc_t[0],
			'type'      => 'page',
			'id'        => $kofc_t[1],
			'url'       => get_permalink( $kofc_t[1] ),
			'kind'      => 'post-type',
			'className' => $kofc_t[2],
		),
		JSON_UNESCAPED_SLASHES
	) . " /-->\n";
}
wp_insert_post(
	wp_slash(
		array(
			'post_type'    => 'wp_navigation',
			'post_status'  => 'publish',
			'post_title'   => 'Sections',
			'post_name'    => 'council-sections',
			'post_content' => $kofc_tabs,
		)
	)
);

/* A volunteer login with the Editor role, for the two test tasks. */
if ( ! username_exists( 'volunteer' ) ) {
	wp_insert_user(
		array(
			'user_login'   => 'volunteer',
			'user_pass'    => 'council8600',
			'user_email'   => 'volunteer@example.com',
			'display_name' => 'Volunteer editor',
			'role'         => 'editor',
		)
	);
}

/* Members' area: an approved brother, and a request waiting for an officer. */
if ( ! username_exists( 'brother' ) ) {
	wp_insert_user(
		array(
			'user_login'   => 'brother',
			'user_pass'    => 'council8600',
			'user_email'   => 'brother@example.com',
			'first_name'   => 'John',
			'last_name'    => 'Sample',
			'display_name' => 'John Sample (demo)',
			'role'         => 'brother',
		)
	);
}
if ( ! email_exists( 'tom.sample@example.com' ) ) {
	$kofc_tom = wp_insert_user(
		array(
			'user_login'   => 'tom.sample@example.com',
			'user_pass'    => 'council8600',
			'user_email'   => 'tom.sample@example.com',
			'first_name'   => 'Tom',
			'last_name'    => 'Sample',
			'display_name' => 'Tom Sample',
			'role'         => 'brother_pending',
		)
	);
	update_user_meta( $kofc_tom, 'kofc_member_number', '1234567' );
	update_user_meta( $kofc_tom, 'kofc_phone', '(571) 555-0142' );
	update_user_meta( $kofc_tom, 'kofc_requested', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - DAY_IN_SECONDS ) );
}

flush_rewrite_rules();
echo "Council 8600 demo ready.\n";
