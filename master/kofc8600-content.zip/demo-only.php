<?php
/**
 * Plugin Name: Council 8600 demo only
 * Description: Prototype only, not part of the live site. Keeps emails instead of sending them (a sign-in code or password-reset email appears on the sign-in screen, and officers see every email under Tools, Demo emails), and lets the demo open already signed in as the administrator without a sign-in code.
 *
 * setup.php copies this file into mu-plugins.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * The demo opens already signed in as the administrator, through WordPress's
 * normal sign-in step, which would otherwise ask for an emailed code. Only that
 * automatic sign-in on the first visit skips the code; signing in by hand still
 * asks for it.
 */
add_filter(
	'two_factor_is_required_for_user',
	function ( $required ) {
		return ( defined( 'PLAYGROUND_AUTO_LOGIN_AS_USER' ) && ! isset( $_COOKIE['playground_auto_login_already_happened'] ) ) ? false : $required;
	}
);

/* Keep each email instead of sending it, and report it as sent. */
add_filter(
	'pre_wp_mail',
	function ( $result, $atts ) {
		$outbox = get_option( 'kofc_demo_outbox', array() );
		array_unshift(
			$outbox,
			array(
				'to'      => implode( ', ', (array) $atts['to'] ),
				'subject' => (string) $atts['subject'],
				'message' => (string) $atts['message'],
				'time'    => time(),
			)
		);
		update_option( 'kofc_demo_outbox', array_slice( $outbox, 0, 25 ), false );
		return true;
	},
	10,
	2
);

/*
 * On the sign-in screens, show the sign-in code or password-reset email that was just "sent".
 * It goes below the form: the code screen sends its email after the top of the page is printed.
 */
add_action(
	'login_footer',
	function () {
		foreach ( get_option( 'kofc_demo_outbox', array() ) as $mail ) {
			if ( time() - $mail['time'] > 15 * MINUTE_IN_SECONDS ) {
				return;
			}
			if ( false !== stripos( $mail['subject'], 'sign-in code' ) || false !== stripos( $mail['subject'], 'password reset' ) ) {
				echo '<div class="kofc-demo-mail" style="max-width:320px;margin:0 auto 24px;padding:12px 16px;border-left:4px solid #f7b718;background:#fdf6e3;border-radius:8px;font-size:15px;line-height:1.5;color:#16181d">'
					. '<p style="margin:0"><strong>Prototype: the demo does not send email.</strong> This email would have gone to ' . esc_html( $mail['to'] ) . ':</p>'
					. '<p style="margin:8px 0 0"><strong>' . esc_html( $mail['subject'] ) . '</strong></p>'
					. '<p style="margin:6px 0 0;white-space:pre-line">' . esc_html( $mail['message'] ) . '</p></div>';
				return;
			}
		}
	}
);

/* Tools, Demo emails: everything the demo would have sent, newest first. */
add_action(
	'admin_menu',
	function () {
		add_management_page(
			'Demo emails',
			'Demo emails',
			'edit_pages',
			'kofc-demo-emails',
			function () {
				echo '<div class="wrap"><h1>Demo emails</h1><p>The demo does not send email. These are the emails the live site would have sent, newest first.</p>';
				$outbox = get_option( 'kofc_demo_outbox', array() );
				if ( ! $outbox ) {
					echo '<p>None yet.</p>';
				}
				foreach ( $outbox as $mail ) {
					echo '<div class="card" style="max-width:720px">'
						. '<p><strong>' . esc_html( $mail['subject'] ) . '</strong><br>To ' . esc_html( $mail['to'] ) . ', ' . esc_html( human_time_diff( $mail['time'] ) ) . ' ago</p>'
						. '<p style="white-space:pre-line">' . esc_html( $mail['message'] ) . '</p></div>';
				}
				echo '</div>';
			}
		);
	}
);

/*
 * Local testing: a playground/feed.json (ignored by git) replaces the published events
 * feed, for example one just built with tools/build-feed.py. The public demo has none.
 */
add_filter(
	'kofc8600_feed_file',
	function ( $file ) {
		return is_readable( '/demo/feed.json' ) ? '/demo/feed.json' : $file;
	}
);
