<?php
/**
 * Plugin Name: Council 8600 demo only
 * Description: Prototype only, not part of the live site. Keeps emails instead of sending them (officers see every email under Tools, Demo emails).
 *
 * setup.php copies this file into mu-plugins.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* The demo says plainly that it is a prototype; the live site's theme doesn't. */
add_action(
	'wp_body_open',
	function () {
		echo '<p class="proto-note">Design prototype, not the official Council 8600 website. Sample content. Real site: <a href="https://www.kofc8600.org">kofc8600.org</a></p>';
	}
);

/* Keep each email instead of sending it, and report it as sent. */
add_filter(
	'pre_wp_mail',
	function ( $result, $atts ) {
		$outbox = get_option( 'kofc_demo_outbox', array() );
		array_unshift(
			$outbox,
			array(
				'to'      => implode( ', ', (array) $atts['to'] ),
				'subject' => (string) $atts['subject'],
				'message' => (string) $atts['message'],
				'time'    => time(),
			)
		);
		update_option( 'kofc_demo_outbox', array_slice( $outbox, 0, 25 ), false );
		return true;
	},
	10,
	2
);

/* Tools, Demo emails: everything the demo would have sent, newest first. */
add_action(
	'admin_menu',
	function () {
		add_management_page(
			'Demo emails',
			'Demo emails',
			'edit_pages',
			'kofc-demo-emails',
			function () {
				echo '<div class="wrap"><h1>Demo emails</h1><p>The demo does not send email. These are the emails the live site would have sent, newest first.</p>';
				$outbox = get_option( 'kofc_demo_outbox', array() );
				if ( ! $outbox ) {
					echo '<p>None yet.</p>';
				}
				foreach ( $outbox as $mail ) {
					echo '<div class="card" style="max-width:720px">'
						. '<p><strong>' . esc_html( $mail['subject'] ) . '</strong><br>To ' . esc_html( $mail['to'] ) . ', ' . esc_html( human_time_diff( $mail['time'] ) ) . ' ago</p>'
						. '<p style="white-space:pre-line">' . esc_html( $mail['message'] ) . '</p></div>';
				}
				echo '</div>';
			}
		);
	}
);

/*
 * Local testing: a playground/feed.json (ignored by git) replaces the published events
 * feed, for example one just built with tools/build-feed.py. The public demo has none.
 */
add_filter(
	'kofc8600_feed_file',
	function ( $file ) {
		return is_readable( '/demo/feed.json' ) ? '/demo/feed.json' : $file;
	}
);

/* The demo's web server can't refuse direct links (Playground ignores server rules), so skip the officers' protection check for members' documents. */
add_filter( 'kofc_docs_check_protection', '__return_false' );
