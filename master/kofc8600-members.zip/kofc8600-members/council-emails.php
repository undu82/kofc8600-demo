<?php
/**
 * Council emails: every email the Council sends through Flocknote, kept in the
 * members' area so brothers can read the latest one and look back at the rest.
 *
 * How it works:
 * - Each email is a "Council email" post, always Members only (Private), so
 *   only brothers and officers can read it. Its address is
 *   /members/emails/<subject>/.
 * - Once an officer pastes the Flocknote group's RSS feed link under
 *   Council emails, Flocknote feed, the site checks the feed every hour and
 *   adds each new email. Emails stay here after they drop off Flocknote's feed,
 *   so the archive keeps growing.
 * - Without a feed (Flocknote has none for closed or hidden groups), an officer
 *   can add an email by hand: Council emails, Add a Council email.
 * - [council_emails] lists them: the latest in full, then the earlier ones by
 *   month. The Members page shows the latest one at the top for brothers.
 *
 * Loaded by kofc8600-members.php.
 *
 * @package kofc8600-members
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KOFC_EMAILS_CHECK = 'kofc_emails_check';

/* What officers may do with Council emails. Brothers only read them. */
function kofc_emails_officer_caps() {
	return array(
		'edit_council_emails',
		'edit_others_council_emails',
		'edit_private_council_emails',
		'edit_published_council_emails',
		'publish_council_emails',
		'read_private_council_emails',
		'delete_council_emails',
		'delete_others_council_emails',
		'delete_private_council_emails',
		'delete_published_council_emails',
	);
}

add_action(
	'init',
	function () {
		register_post_type(
			'council_email',
			array(
				'labels'          => array(
					'name'           => 'Council emails',
					'singular_name'  => 'Council email',
					'menu_name'      => 'Council emails',
					'all_items'      => 'All emails',
					'add_new'        => 'Add email',
					'add_new_item'   => 'Add a Council email',
					'edit_item'      => 'Edit Council email',
					'view_item'      => 'View email',
					'search_items'   => 'Search emails',
					'not_found'      => 'No Council emails yet',
					'item_published' => 'Email saved. Only brothers and officers can read it.',
					'item_updated'   => 'Email updated.',
				),
				'public'              => true,
				'exclude_from_search' => true, // The site search adds them for brothers (theme inc/search.php).
				'show_in_rest'        => true,
				'show_in_nav_menus'   => false,
				'has_archive'         => false, // The list is the members-only Council emails page.
				'menu_position'       => 72,
				'menu_icon'           => 'dashicons-email-alt',
				'rewrite'             => array(
					'slug'       => 'members/emails',
					'with_front' => false,
				),
				'capability_type'     => array( 'council_email', 'council_emails' ),
				'map_meta_cap'        => true,
				'supports'            => array( 'title', 'editor', 'revisions' ),
				'template'            => array(
					array( 'core/paragraph', array( 'placeholder' => 'Paste the email here. Put its subject in the title above.' ) ),
				),
			)
		);
	}
);

/* Council emails are always Members only, however they are saved. */
add_filter(
	'wp_insert_post_data',
	function ( $data ) {
		if ( 'council_email' === $data['post_type'] && in_array( $data['post_status'], array( 'publish', 'future' ), true ) ) {
			$data['post_status'] = 'private';
		}
		return $data;
	}
);

/* ───────── Reading them ───────── */

/* All Council emails, newest first. Only for people who may read them. */
function kofc_emails_all( $limit = -1 ) {
	if ( ! current_user_can( 'read_private_council_emails' ) ) {
		return array();
	}
	return get_posts(
		array(
			'post_type'      => 'council_email',
			'post_status'    => 'private',
			'posts_per_page' => $limit,
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);
}

/* The Council emails page: the members-only page that holds [council_emails]. */
function kofc_emails_page_url() {
	$page = get_page_by_path( 'members/emails' );
	return $page ? get_permalink( $page ) : kofc_members_url();
}

/* An email's text as HTML. Emails from Flocknote are plain HTML; emails typed in the editor are blocks. */
function kofc_emails_body( $post ) {
	$html = $post->post_content;
	$html = has_blocks( $html ) ? do_blocks( $html ) : wpautop( $html );
	return wp_kses_post( $html );
}

/* The first words of an email, without the "Worthy Brother Knights" every email opens with. */
function kofc_emails_preview( $post, $words = 18 ) {
	// A space after each paragraph, list item and line break, so their words do not run together.
	$html = preg_replace( '#</(p|li|div|h[1-6]|td|th|blockquote)>|<br\s*/?>#i', '$0 ', $post->post_content );
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( $html, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
	$text = preg_replace( '/^(worthy\s+)?(brother\s+knights|brothers)\b[\s,.:;!]*/iu', '', $text );
	return html_entity_decode( wptexturize( wp_trim_words( $text, $words ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ); // Curly quotes, as in the titles.
}

/* "Wednesday, October 21 · Sent by the Grand Knight" */
function kofc_emails_meta( $post, $long = true ) {
	$parts  = array( get_the_date( $long ? 'l, F j, Y' : 'M j', $post ) );
	$sender = get_post_meta( $post->ID, '_kofc_email_sender', true );
	if ( $long && $sender ) {
		$parts[] = 'Sent by ' . $sender;
	}
	return implode( ' · ', $parts );
}

/* A Reply button for emails that came from Flocknote: replies and comments happen there. */
function kofc_emails_reply_button( $post ) {
	$url = get_post_meta( $post->ID, '_kofc_flocknote_url', true );
	if ( ! $url ) {
		return '';
	}
	return '<div class="wp-block-buttons email-reply"><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . '">Reply or comment in Flocknote</a></div></div>';
}

/* [council_emails]: the latest email in full, then every earlier one by month. */
add_shortcode(
	'council_emails',
	function () {
		$emails = kofc_emails_all();
		if ( ! $emails ) {
			return current_user_can( 'read_private_council_emails' ) ? '<p class="email-empty">No Council emails yet.</p>' : '';
		}
		$latest = array_shift( $emails );
		$html   = '<article class="email-latest" aria-labelledby="email-latest-title">'
			. '<p class="email-kicker">Latest email</p>'
			. '<h2 id="email-latest-title" class="email-title"><a href="' . esc_url( get_permalink( $latest ) ) . '">' . esc_html( get_the_title( $latest ) ) . '</a></h2>'
			. '<p class="email-meta">' . esc_html( kofc_emails_meta( $latest ) ) . '</p>'
			. '<div class="email-body">' . kofc_emails_body( $latest ) . '</div>'
			. kofc_emails_reply_button( $latest )
			. '</article>';
		if ( ! $emails ) {
			return $html;
		}
		$html .= '<h2 class="wp-block-heading email-earlier">Earlier emails</h2>';
		$month = '';
		foreach ( $emails as $email ) {
			$this_month = get_the_date( 'F Y', $email );
			if ( $this_month !== $month ) {
				$html .= ( $month ? '</div>' : '' ) . '<h3 class="email-month">' . esc_html( $this_month ) . '</h3><div class="rows email-list">';
				$month = $this_month;
			}
			$html .= '<p class="row"><a href="' . esc_url( get_permalink( $email ) ) . '"><strong>' . esc_html( get_the_title( $email ) ) . '</strong>'
				. '<span>' . esc_html( get_the_date( 'D, M j', $email ) . ' · ' . kofc_emails_preview( $email, 14 ) ) . '</span></a></p>';
		}
		return $html . '</div>';
	}
);

/* On the Members page, brothers see the latest email first. Called by kofc_members_area(). */
function kofc_emails_latest_row() {
	$latest = kofc_emails_all( 1 );
	if ( ! $latest ) {
		return '';
	}
	$latest = $latest[0];
	return '<div class="rows members-latest-email"><p class="row icon-mail"><a href="' . esc_url( get_permalink( $latest ) ) . '">'
		. '<strong>' . esc_html( get_the_title( $latest ) ) . '</strong>'
		. '<span>Latest email, ' . esc_html( get_the_date( 'l, F j', $latest ) ) . ' · ' . esc_html( kofc_emails_preview( $latest, 12 ) ) . '</span></a></p></div>';
}

/* One email on its own page: who sent it, a Reply button, and the emails before and after it. */
add_filter(
	'render_block_core/post-content',
	function ( $html, $block, $instance ) {
		$id = isset( $instance->context['postId'] ) ? (int) $instance->context['postId'] : 0;
		if ( ! is_singular( 'council_email' ) || get_queried_object_id() !== $id ) {
			return $html;
		}
		$post   = get_post( $id );
		$sender = get_post_meta( $id, '_kofc_email_sender', true );
		$top    = $sender ? '<p class="email-meta email-sender">Sent by ' . esc_html( $sender ) . '</p>' : '';

		$nav = '';
		foreach ( array( 'Earlier email' => get_adjacent_post( false, '', true ), 'Later email' => get_adjacent_post( false, '', false ) ) as $label => $other ) {
			if ( $other ) {
				$nav .= '<p class="row"><a href="' . esc_url( get_permalink( $other ) ) . '"><span>' . esc_html( $label . ', ' . get_the_date( 'M j', $other ) ) . '</span><strong>' . esc_html( get_the_title( $other ) ) . '</strong></a></p>';
			}
		}
		$bottom = kofc_emails_reply_button( $post )
			. '<nav class="email-nav" aria-label="Other Council emails">'
			. ( $nav ? '<div class="rows">' . $nav . '</div>' : '' )
			. '<p><a href="' . esc_url( kofc_emails_page_url() ) . '">All Council emails</a></p></nav>';

		// The block's outer element wraps the email, so the extras go inside it.
		$open  = strpos( $html, '>' );
		$close = strrpos( $html, '</' );
		if ( false === $open || false === $close ) {
			return $top . $html . $bottom;
		}
		return substr( $html, 0, $open + 1 ) . $top . '<div class="email-body">' . substr( $html, $open + 1, $close - $open - 1 ) . '</div>' . $bottom . substr( $html, $close );
	},
	10,
	3
);

/* Breadcrumbs: Home › Members › Council emails › the email. */
add_filter(
	'block_core_breadcrumbs_items',
	function ( $items ) {
		$page = get_page_by_path( 'members/emails' );
		if ( ! is_singular( 'council_email' ) || ! $page ) {
			return $items;
		}
		$add = array();
		foreach ( array_merge( array_reverse( get_post_ancestors( $page ) ), array( $page->ID ) ) as $id ) {
			$add[] = array(
				'label' => get_the_title( $id ),
				'url'   => get_permalink( $id ),
			);
		}
		array_splice( $items, count( $items ) - 1, 0, $add );
		return $items;
	}
);

/* Someone opening an email without access goes to the Members page to sign in, then comes back. */
add_action(
	'template_redirect',
	function () {
		global $wp;
		if ( ! is_404() || current_user_can( 'read_private_council_emails' ) || empty( $wp->query_vars['council_email'] ) ) {
			return;
		}
		$email = get_page_by_path( $wp->query_vars['council_email'], OBJECT, 'council_email' );
		if ( $email && 'private' === $email->post_status ) {
			wp_safe_redirect(
				kofc_members_url(
					array(
						'members-only' => 1,
						'redirect_to'  => rawurlencode( home_url( user_trailingslashit( $wp->request ) ) ),
					)
				)
			);
			exit;
		}
	},
	6
);

/* ───────── Bringing them in from Flocknote ───────── */

/*
 * Read the Flocknote feed and add each email not seen before. Returns how many
 * were added, or a WP_Error. Emails already here are left as they are, so an
 * officer's corrections are kept.
 */
function kofc_emails_import() {
	$url = get_option( 'kofc_emails_feed', '' );
	if ( ! $url ) {
		return new WP_Error( 'kofc_no_feed', 'No feed address yet.' );
	}
	$feed = fetch_feed( $url );
	if ( is_wp_error( $feed ) ) {
		$result = new WP_Error( 'kofc_feed', 'The feed could not be read: ' . $feed->get_error_message() );
	} else {
		$added = 0;
		foreach ( array_reverse( (array) $feed->get_items() ) as $item ) { // Oldest first.
			$guid = (string) $item->get_id();
			if ( '' === $guid || get_posts(
				array(
					'post_type'   => 'council_email',
					'post_status' => 'any',
					'meta_key'    => '_kofc_flocknote_id', // phpcs:ignore WordPress.DB.SlowDBQuery -- one lookup per feed item.
					'meta_value'  => $guid, // phpcs:ignore WordPress.DB.SlowDBQuery
					'fields'      => 'ids',
				)
			) ) {
				continue;
			}
			$gmt    = $item->get_gmdate( 'Y-m-d H:i:s' );
			$author = $item->get_author();
			$id     = wp_insert_post(
				wp_slash(
					array(
						'post_type'     => 'council_email',
						'post_status'   => 'private',
						'post_title'    => sanitize_text_field( html_entity_decode( (string) $item->get_title(), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ),
						'post_content'  => wp_kses_post( (string) $item->get_content() ),
						'post_date_gmt' => $gmt ? $gmt : current_time( 'mysql', true ),
						'post_date'     => $gmt ? get_date_from_gmt( $gmt ) : current_time( 'mysql' ),
						'post_author'   => 0,
					)
				),
				true
			);
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_kofc_flocknote_id', $guid );
			update_post_meta( $id, '_kofc_flocknote_url', esc_url_raw( (string) $item->get_permalink() ) );
			if ( $author && $author->get_name() ) {
				update_post_meta( $id, '_kofc_email_sender', sanitize_text_field( $author->get_name() ) );
			}
			++$added;
		}
		$result = $added;
	}
	update_option(
		'kofc_emails_status',
		array(
			'time'  => time(),
			'added' => is_wp_error( $result ) ? 0 : $result,
			'error' => is_wp_error( $result ) ? $result->get_error_message() : '',
		),
		false
	);
	return $result;
}

/* Always read the feed fresh: WordPress would otherwise reuse a copy for 12 hours. */
add_action(
	'wp_feed_options',
	function ( $feed, $url ) {
		if ( $url && get_option( 'kofc_emails_feed' ) === $url ) {
			$feed->enable_cache( false );
		}
	},
	10,
	2
);

/* Check every hour while a feed address is set. */
add_action( KOFC_EMAILS_CHECK, 'kofc_emails_import' );
add_action(
	'init',
	function () {
		$scheduled = wp_next_scheduled( KOFC_EMAILS_CHECK );
		if ( get_option( 'kofc_emails_feed' ) && ! $scheduled ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', KOFC_EMAILS_CHECK );
		} elseif ( ! get_option( 'kofc_emails_feed' ) && $scheduled ) {
			wp_clear_scheduled_hook( KOFC_EMAILS_CHECK );
		}
	}
);

/* ───────── Officers: Council emails, Flocknote feed ───────── */

add_action(
	'admin_menu',
	function () {
		add_submenu_page(
			'edit.php?post_type=council_email',
			'Flocknote feed',
			'Flocknote feed',
			'edit_others_council_emails',
			'kofc-emails-feed',
			'kofc_emails_feed_screen'
		);
	}
);

function kofc_emails_feed_screen() {
	if ( ! current_user_can( 'edit_others_council_emails' ) ) {
		return;
	}
	$url    = get_option( 'kofc_emails_feed', '' );
	$status = get_option( 'kofc_emails_status', array() );
	// phpcs:ignore WordPress.Security.NonceVerification -- display only.
	$done = isset( $_GET['done'] ) ? sanitize_key( $_GET['done'] ) : '';

	echo '<div class="wrap"><h1>Flocknote feed</h1>';
	if ( 'saved' === $done || 'checked' === $done ) {
		$message = 'saved' === $done ? ( $url ? 'Feed address saved, and checked for emails.' : 'Feed address removed. Emails already here stay.' ) : 'Checked for new emails.';
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}
	echo '<p style="max-width:44rem">Every email the Council sends through Flocknote can appear in the members\' area by itself: the latest one on the Members page, and all of them on the Council emails page. Only brothers and officers who are signed in can read them. The site checks the feed every hour, and emails stay here after they drop off Flocknote\'s feed.</p>';

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="kofc_emails_feed">' . wp_nonce_field( 'kofc_emails_feed', '_wpnonce', true, false )
		. '<table class="form-table" role="presentation"><tr><th scope="row"><label for="kofc-feed">Feed address</label></th><td>'
		. '<input id="kofc-feed" name="feed" type="url" class="large-text code" placeholder="https://…flocknote.com/…" value="' . esc_attr( $url ) . '" aria-describedby="kofc-feed-help">'
		. '<p class="description" id="kofc-feed-help">The Flocknote group\'s RSS feed link. In Flocknote, a group admin opens the group, clicks the gear at the top right, chooses <strong>Social &amp; Sharing</strong>, and copies the <strong>RSS Feed</strong> link at the bottom. Flocknote offers it only for open groups. Leave the box empty to stop checking.</p>'
		. '</td></tr></table>'
		. '<p><button type="submit" class="button button-primary">Save</button></p></form>';

	if ( $url ) {
		echo '<h2>Last check</h2><p>';
		if ( empty( $status['time'] ) ) {
			echo 'Not checked yet.';
		} elseif ( $status['error'] ) {
			echo '<strong>' . esc_html( human_time_diff( $status['time'] ) ) . ' ago, it did not work.</strong> ' . esc_html( $status['error'] );
		} else {
			echo esc_html( human_time_diff( $status['time'] ) . ' ago: ' . sprintf( 1 === $status['added'] ? '%d new email.' : '%d new emails.', $status['added'] ) );
		}
		$next = wp_next_scheduled( KOFC_EMAILS_CHECK );
		echo $next ? ' ' . esc_html( 'Next check in ' . human_time_diff( $next ) . '.' ) : '';
		echo '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. '<input type="hidden" name="action" value="kofc_emails_check">' . wp_nonce_field( 'kofc_emails_check', '_wpnonce', true, false )
			. '<button type="submit" class="button">Check now</button></form>';
	}

	echo '<h2>No feed?</h2><p style="max-width:44rem">If the Council\'s group is closed, Flocknote has no feed for it. An officer can still add each email by hand: <a href="' . esc_url( admin_url( 'post-new.php?post_type=council_email' ) ) . '">Add a Council email</a>, put the subject in the title, paste the email below it, and press Publish. It is saved as Members only.</p>';
	echo '</div>';
}

add_action(
	'admin_post_kofc_emails_feed',
	function () {
		if ( ! current_user_can( 'edit_others_council_emails' ) ) {
			wp_die( 'You are not allowed to change the Flocknote feed.', 403 );
		}
		check_admin_referer( 'kofc_emails_feed' );
		$url = isset( $_POST['feed'] ) ? esc_url_raw( trim( wp_unslash( $_POST['feed'] ) ), array( 'http', 'https' ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- esc_url_raw sanitizes.
		update_option( 'kofc_emails_feed', $url, false );
		delete_option( 'kofc_emails_status' );
		wp_clear_scheduled_hook( KOFC_EMAILS_CHECK );
		if ( $url ) {
			kofc_emails_import();
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', KOFC_EMAILS_CHECK );
		}
		wp_safe_redirect( admin_url( 'edit.php?post_type=council_email&page=kofc-emails-feed&done=saved' ) );
		exit;
	}
);

add_action(
	'admin_post_kofc_emails_check',
	function () {
		if ( ! current_user_can( 'edit_others_council_emails' ) ) {
			wp_die( 'You are not allowed to check the Flocknote feed.', 403 );
		}
		check_admin_referer( 'kofc_emails_check' );
		kofc_emails_import();
		wp_safe_redirect( admin_url( 'edit.php?post_type=council_email&page=kofc-emails-feed&done=checked' ) );
		exit;
	}
);
