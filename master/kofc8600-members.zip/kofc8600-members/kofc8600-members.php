<?php
/**
 * Plugin Name: Council 8600 Members
 * Description: A members' area for brothers of the Council. A brother signs in with WordPress.com (Google, Apple or an emailed link, always with two-step), an officer checks him against the Council roster and approves him, and he can then read pages set to "Members only".
 * Version: 0.3.0
 * Requires at least: 7.0
 * Requires PHP: 7.4
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 *
 * How it works:
 * - "Members only" is WordPress's own Private visibility, renamed in the editor.
 *   Brothers may read private pages; visitors who are not signed in cannot.
 * - Everyone signs in through WordPress.com's login (Jetpack's single sign-on):
 *   with Google, Apple, a WordPress.com password or an emailed login link, and
 *   always with WordPress.com's two-step. The site keeps no passwords.
 * - [council_members] on the Members page shows visitors one button, to sign in
 *   or, the first time, to ask for access; and shows brothers the list of
 *   members-only pages.
 * - Someone new who signs in from there gets an account with the "Brother
 *   (waiting for approval)" role, which cannot get in. Officers (Editors and
 *   Administrators) approve or decline it under Brothers in the dashboard, which
 *   never touches an officer's own account.
 * - Council emails (council-emails.php): the emails the Council sends through
 *   Flocknote, kept in the members' area.
 * - Members' documents (documents.php): PDFs such as minutes and budgets, which
 *   nobody can open without signing in, even with the file's link.
 *
 * @package kofc8600-members
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/council-emails.php';
require_once __DIR__ . '/documents.php';

/* ───────── Roles ───────── */

/* What reading the members' area takes: members-only pages, Council emails, and members' documents. */
function kofc_members_reader_caps() {
	return array( 'read_private_pages', 'read_private_posts', 'read_private_council_emails' );
}

function kofc_members_setup_roles() {
	remove_role( 'brother' );
	add_role( 'brother', 'Brother', array_fill_keys( array_merge( array( 'read' ), kofc_members_reader_caps() ), true ) );
	// Program owners (WordPress's Contributor role, see the owners plugin) are brothers too, so they read the members' area.
	$owner = get_role( 'contributor' );
	if ( $owner ) {
		foreach ( kofc_members_reader_caps() as $cap ) {
			$owner->add_cap( $cap );
		}
	}
	remove_role( 'brother_pending' );
	add_role( 'brother_pending', 'Brother (waiting for approval)', array() );
	foreach ( array( 'administrator', 'editor' ) as $officer ) {
		$role = get_role( $officer );
		if ( $role ) {
			$role->add_cap( 'kofc_review_members' );
			foreach ( kofc_emails_officer_caps() as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
}
register_activation_hook(
	__FILE__,
	function () {
		kofc_members_setup_roles();
		// The Council emails' addresses (/members/emails/<subject>/) are new to WordPress. Clearing its saved
		// address rules makes it rebuild them on the next page load, with those included; otherwise each email
		// opens "Page not found" until someone re-saves Settings > Permalinks.
		delete_option( 'rewrite_rules' );
	}
);
register_deactivation_hook(
	__FILE__,
	function () {
		delete_option( 'rewrite_rules' );
		$owner = get_role( 'contributor' );
		if ( $owner ) {
			foreach ( kofc_members_reader_caps() as $cap ) {
				$owner->remove_cap( $cap );
			}
		}
	}
);

add_action(
	'init',
	function () {
		$editor = get_role( 'editor' );
		$owner  = get_role( 'contributor' );
		if ( ! get_role( 'brother' ) || ! get_role( 'brother_pending' ) || ( $editor && ! $editor->has_cap( 'edit_others_council_emails' ) ) || ( $owner && ! $owner->has_cap( 'read_private_council_emails' ) ) ) {
			kofc_members_setup_roles();
		}
	}
);

/* True for brothers, approved or waiting, and nobody else. Officers' accounts are never "brother accounts". */
function kofc_members_is_brother_account( $user ) {
	$roles = $user ? (array) $user->roles : array();
	return $roles && ! array_diff( $roles, array( 'brother', 'brother_pending' ) );
}

/* The Members page, found by its address. */
function kofc_members_url( $args = array() ) {
	$page = get_page_by_path( 'members' );
	return add_query_arg( $args, $page ? get_permalink( $page ) : home_url( '/' ) );
}

function kofc_members_waiting() {
	return get_users(
		array(
			'role'    => 'brother_pending',
			'orderby' => 'registered',
			'order'   => 'ASC',
		)
	);
}

/* ───────── Members-only pages ───────── */

/* Show "Members only" pages as they are, without WordPress's "Private:" in front of the title. */
add_filter(
	'private_title_format',
	function () {
		return '%s';
	}
);

/* A members-only page in a menu shows for brothers and officers, and stays hidden from everyone else. */
add_filter(
	'render_block_core_navigation_link_allowed_post_status',
	function ( $statuses ) {
		if ( current_user_can( 'read_private_pages' ) ) {
			$statuses[] = 'private';
		}
		return $statuses;
	}
);

/* Someone opening a members-only page without access goes to the Members page to sign in, then comes back. */
add_action(
	'template_redirect',
	function () {
		global $wp;
		if ( ! is_404() || current_user_can( 'read_private_pages' ) || '' === $wp->request ) {
			return;
		}
		$page = get_page_by_path( $wp->request );
		if ( $page && 'private' === $page->post_status ) {
			// The address as typed: WordPress gives private pages a plain ?page_id= link for visitors.
			$back = home_url( user_trailingslashit( $wp->request ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which members' document to show after signing in (documents.php).
			if ( ! empty( $_GET['doc'] ) ) {
				$back = add_query_arg( 'doc', absint( $_GET['doc'] ), $back );
			}
			wp_safe_redirect(
				kofc_members_url(
					array(
						'members-only' => 1,
						'redirect_to'  => rawurlencode( $back ),
					)
				)
			);
			exit;
		}
	},
	5
);

/* A "Members only" label above the title, so brothers know not to share the page. */
add_filter(
	'render_block_core/post-title',
	function ( $html, $block, $instance ) {
		$id = isset( $instance->context['postId'] ) ? (int) $instance->context['postId'] : 0;
		if ( $id && is_singular() && get_queried_object_id() === $id && 'private' === get_post_status( $id ) ) {
			$html = '<p class="members-badge">Members only</p>' . $html;
		}
		return $html;
	},
	10,
	3
);

/* In the editor and the Pages list, call Private visibility "Members only". */
add_action(
	'enqueue_block_editor_assets',
	function () {
		wp_register_script( 'kofc8600-members-editor', false, array( 'wp-hooks' ), '0.1.0', false );
		wp_enqueue_script( 'kofc8600-members-editor' );
		wp_add_inline_script(
			'kofc8600-members-editor',
			"wp.hooks.addFilter('i18n.gettext','kofc8600/members',function(t,text){if(text==='Private')return 'Members only';if(text==='Only visible to site admins and editors.')return 'Only brothers and officers who are signed in can see it.';return t;});"
		);
	}
);
add_filter(
	'display_post_states',
	function ( $states ) {
		if ( isset( $states['private'] ) ) {
			$states['private'] = 'Members only';
		}
		return $states;
	}
);

/* ───────── Signing in: WordPress.com only, always with two steps ───────── */

/*
 * Everyone signs in through WordPress.com's login (Jetpack's single sign-on,
 * always on for our plan): with Google, Apple, a WordPress.com password, or a
 * login link by email. Two of Jetpack's settings make that the only way in, and
 * always with a second step:
 * - Require two-step: a sign-in counts only if the WordPress.com account has
 *   WordPress.com's two-step on (a code by text message or from an app, or a
 *   security key). Setting it here also greys out the box in Jetpack's
 *   settings, so nobody can untick it by mistake.
 * - Remove the login form: the site's own username and password form is hidden
 *   and refused, so there are no passwords on this site to guess.
 * Both only act where Jetpack's login runs (WordPress.com). On a local copy,
 * WordPress's own sign-in screen works as usual.
 */
add_filter( 'jetpack_sso_require_two_step', '__return_true' );
add_filter( 'jetpack_remove_login_form', '__return_true' );

/* A brother whose request has not been approved yet cannot sign in (a safety net; there is no password form on WordPress.com). */
add_filter(
	'authenticate',
	function ( $user ) {
		if ( $user instanceof WP_User && in_array( 'brother_pending', (array) $user->roles, true ) ) {
			return new WP_Error( 'kofc_pending', 'Your request for the members\' area is waiting for an officer to check the Council roster. You will get an email once it is approved.' );
		}
		return $user;
	},
	99
);

/*
 * After WordPress.com, before he is signed in:
 * - someone new, signing in from the Members page, is asking for access (Jetpack
 *   has just made him an account waiting for approval; see below);
 * - someone still waiting goes back to the Members page and is told so;
 * - an approved brother carries on. Jetpack then takes him to the page he was
 *   trying to open, which it kept in a cookie while he was at WordPress.com.
 */
add_action(
	'jetpack_sso_handle_login',
	function ( $user ) {
		$from_members = ! empty( $_COOKIE['kofc_wpcom_request'] );
		if ( $from_members && ! headers_sent() ) {
			setcookie( 'kofc_wpcom_request', ' ', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
		}
		if ( ! $user instanceof WP_User ) {
			// Not made into a request (over the hourly limit). From the Members page, say so there; otherwise Jetpack says it couldn't find the account.
			if ( $from_members ) {
				wp_safe_redirect( kofc_members_url( array( 'request' => 'later' ) ) );
				exit;
			}
			return;
		}
		if ( in_array( 'brother_pending', (array) $user->roles, true ) ) {
			if ( ! get_user_meta( $user->ID, 'kofc_requested', true ) ) {
				update_user_meta( $user->ID, 'kofc_requested', current_time( 'mysql' ) );
				kofc_members_count_request();
				kofc_members_tell_officers( $user );
				wp_safe_redirect( kofc_members_url( array( 'request' => 'sent' ) ) );
				exit;
			}
			wp_safe_redirect( kofc_members_url( array( 'members-waiting' => 1 ) ) );
			exit;
		}
	}
);

/*
 * Someone the site doesn't know who signs in from the Members page is asking for
 * access: Jetpack makes him an account waiting for approval, from his WordPress.com
 * name and email. Jetpack's own sign-in screen keeps refusing unknown accounts, so
 * an officer's sign-in never turns into a brother's request.
 */
add_filter(
	'jetpack_sso_new_user_override',
	function ( $role ) {
		return ( ! empty( $_COOKIE['kofc_wpcom_request'] ) && kofc_members_requests_left() ) ? 'brother_pending' : $role;
	}
);
add_action(
	'login_init',
	function () {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- marks where the sign-in started, nothing else.
		if ( ! empty( $_GET['kofc-wpcom'] ) && ! headers_sent() ) {
			setcookie( 'kofc_wpcom_request', '1', time() + HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
		}
	},
	1 // Before Jetpack's own login_init sends him to WordPress.com.
);

/*
 * Jetpack turns away a WordPress.com account without two-step before anything
 * else, with a short message on the sign-in screen. When he came from the Members
 * page, send him back there instead, with the steps to turn it on.
 */
add_action(
	'wp_login_failed',
	function ( $username, $error = null ) {
		if ( $error instanceof WP_Error && 'two_step_required' === $error->get_error_code() && ! empty( $_COOKIE['kofc_wpcom_request'] ) ) {
			wp_safe_redirect( kofc_members_url( array( 'two-step' => 1 ) ) );
			exit;
		}
	},
	10,
	2
);

/*
 * The Members page's "Continue with WordPress.com" button, shown where WordPress.com's
 * login runs. The button opens WordPress's sign-in screen with kofc-wpcom=1, which
 * tells Jetpack to note the page the brother wanted and go straight on to
 * WordPress.com, in one click.
 */
function kofc_members_wpcom_login_on() {
	$on = class_exists( '\Automattic\Jetpack\Modules' ) && ( new \Automattic\Jetpack\Modules() )->is_active( 'sso' );
	return (bool) apply_filters( 'kofc_members_wpcom_login', $on );
}
add_filter(
	'jetpack_sso_bypass_login_forward_wpcom',
	function ( $forward ) {
		return empty( $_GET['kofc-wpcom'] ) ? $forward : true; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only skips a click.
	}
);

/* Brothers land on the Members page, or the page they were trying to open, never on the dashboard. */
add_filter(
	'login_redirect',
	function ( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && kofc_members_is_brother_account( $user ) ) {
			return ( $requested && false === strpos( $requested, '/wp-admin' ) ) ? $redirect_to : kofc_members_url();
		}
		return $redirect_to;
	},
	10,
	3
);
add_action(
	'admin_init',
	function () {
		if ( wp_doing_ajax() || ! kofc_members_is_brother_account( wp_get_current_user() ) ) {
			return;
		}
		global $pagenow;
		if ( 'profile.php' !== $pagenow && 'admin-post.php' !== $pagenow ) {
			wp_safe_redirect( kofc_members_url() );
			exit;
		}
	}
);
add_filter(
	'show_admin_bar',
	function ( $show ) {
		return kofc_members_is_brother_account( wp_get_current_user() ) ? false : $show;
	}
);

/* ───────── Asking for access ───────── */

/* Five requests an hour from one connection. */
function kofc_members_request_limit_key() {
	return 'kofc_member_requests_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' );
}
function kofc_members_requests_left() {
	return (int) get_transient( kofc_members_request_limit_key() ) < 5;
}
function kofc_members_count_request() {
	set_transient( kofc_members_request_limit_key(), (int) get_transient( kofc_members_request_limit_key() ) + 1, HOUR_IN_SECONDS );
}

/* Email the officers about a new request. The address is the site's admin email (Settings, General). */
function kofc_members_tell_officers( $user ) {
	wp_mail(
		apply_filters( 'kofc_members_notify', get_option( 'admin_email' ) ),
		'Members\' area request: ' . $user->display_name,
		"{$user->display_name} has asked for access to the members' area, by signing in with WordPress.com.\n\n"
		. "Name: {$user->display_name}\n"
		. "Email: {$user->user_email}\n\n"
		. "Check him against the Council roster, then approve or decline the request here:\n"
		. admin_url( 'admin.php?page=kofc-brothers' ) . "\n"
	);
}

/* ───────── The Members page: [council_members] ───────── */

add_shortcode(
	'council_members',
	function () {
		if ( current_user_can( 'read_private_pages' ) ) {
			return kofc_members_area();
		}
		if ( is_user_logged_in() ) {
			return '<div class="members-notice"><p><strong>Your account does not include the members\' area.</strong> Ask an officer to add it, or <a href="' . esc_url( wp_logout_url( kofc_members_url() ) ) . '">sign out</a> and sign in as a brother.</p></div>';
		}
		return kofc_members_signin();
	}
);

/* What a signed-in brother sees: the members-only pages. */
function kofc_members_area() {
	$user  = wp_get_current_user();
	$pages = get_pages(
		array(
			'post_status'  => 'private',
			'sort_column'  => 'menu_order,post_title',
			'hierarchical' => 0, // Otherwise pages under a public parent (the Members page) are left out.
		)
	);
	$html  = '<div class="members-welcome"><p class="members-hello">Welcome, ' . esc_html( $user->first_name ? 'Brother ' . $user->first_name : $user->display_name ) . '.</p>';
	$html .= '<p><a href="' . esc_url( wp_logout_url( kofc_members_url() ) ) . '">Sign out</a></p></div>';
	if ( current_user_can( 'kofc_review_members' ) ) {
		$waiting = count( kofc_members_waiting() );
		$html   .= '<div class="members-notice"><p><strong>' . esc_html( sprintf( 1 === $waiting ? '%d request is waiting.' : '%d requests are waiting.', $waiting ) ) . '</strong> <a href="' . esc_url( admin_url( 'admin.php?page=kofc-brothers' ) ) . '">Review requests</a></p></div>';
	}
	$html .= kofc_emails_latest_row();
	if ( ! $pages ) {
		return $html . '<p>No members-only pages yet.</p>';
	}
	$html .= '<div class="rows members-pages">';
	foreach ( $pages as $page ) {
		$html .= '<p class="row icon-lock"><a href="' . esc_url( get_permalink( $page ) ) . '"><strong>' . esc_html( get_the_title( $page ) ) . '</strong>'
			. ( $page->post_excerpt ? '<span>' . esc_html( $page->post_excerpt ) . '</span>' : '' ) . '</a></p>';
	}
	return $html . '</div>';
}

/* What a visitor sees: one button, to sign in or, the first time, to ask for access. */
function kofc_members_signin() {
	// phpcs:disable WordPress.Security.NonceVerification -- display only.
	$redirect = isset( $_GET['redirect_to'] ) && is_string( $_GET['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ), kofc_members_url() ) : kofc_members_url();
	$request  = isset( $_GET['request'] ) && is_string( $_GET['request'] ) ? sanitize_key( $_GET['request'] ) : '';
	$two_step = ! empty( $_GET['two-step'] );
	$locked   = ! empty( $_GET['members-only'] );
	$waiting  = ! empty( $_GET['members-waiting'] );
	// phpcs:enable

	$html = '';
	if ( 'sent' === $request ) {
		$html .= '<div class="members-notice is-done" role="status"><p><strong>Thank you. Your request has been sent.</strong> An officer will check the Council roster, and you will get an email when you can sign in, usually within a few days.</p></div>';
	} elseif ( $waiting ) {
		$html .= '<div class="members-notice" role="status"><p><strong>Your request is waiting for an officer.</strong> An officer will check the Council roster, and you will get an email once you can sign in.</p></div>';
	} elseif ( 'later' === $request ) {
		$html .= '<div class="members-notice" role="status"><p><strong>Your request could not be sent just now.</strong> There have been too many requests from this connection. Please try again in an hour.</p></div>';
	} elseif ( $two_step ) {
		$html .= '<div class="members-notice" role="status"><p><strong>One more step: turn on two-step sign-in at WordPress.com.</strong> The members\' area asks for it, to keep brothers\' information safe. You do this once.</p>'
			. '<ol class="members-steps">'
			. '<li><a href="https://wordpress.com/me/security/two-step" target="_blank" rel="noopener">Open your WordPress.com two-step settings</a>. You are already signed in there.</li>'
			. '<li>Choose <strong>Set up using SMS</strong>: WordPress.com will text a code to your phone when you sign in. (An authenticator app works too.)</li>'
			. '<li>Come back to this page and press <strong>Continue with WordPress.com</strong> again.</li>'
			. '</ol></div>';
	} elseif ( $locked ) {
		$html .= '<div class="members-notice"><p><strong>That page is for brothers of Council 8600.</strong> Sign in to open it.</p></div>';
	}

	$html .= '<div class="members-grid">';
	$html .= '<section class="members-card" aria-labelledby="signin-title"><h2 id="signin-title" class="members-card-title">Sign in</h2>'
		. '<p>Brothers sign in through WordPress.com: with Google, with Apple, or with a sign-in link sent to your email.</p>';
	if ( kofc_members_wpcom_login_on() ) {
		$html .= '<div class="signin-providers"><a class="provider" href="' . esc_url( add_query_arg( 'kofc-wpcom', '1', wp_login_url( $redirect ) ) ) . '">Continue with WordPress.com</a></div>';
	} elseif ( get_option( 'kofc_members_demo_providers' ) ) {
		$html .= '<div class="signin-providers"><button type="button" class="provider" data-demo-provider="WordPress.com">Continue with WordPress.com</button><p class="provider-status" role="status"></p></div>';
	} else {
		$html .= '<p class="fine">Signing in works on the live site, through WordPress.com.</p>';
	}
	$html .= '<p class="hint">For safety, signing in always takes a second step: a code sent to your phone by text message, or from an app. On your own phone or computer you stay signed in for a year.</p>'
		. '</section>';

	$html .= '<section class="members-card" id="request" aria-labelledby="request-title"><h2 id="request-title" class="members-card-title">First time?</h2>'
		. '<ol class="is-style-steps members-steps">'
		. '<li><strong>Press Continue with WordPress.com</strong> and sign in with Google, Apple or your email. WordPress.com may ask you to make a free account.</li>'
		. '<li><strong>Turn on two-step sign-in</strong> in your WordPress.com account, by text message. If it is not on yet, this page shows you how.</li>'
		. '<li><strong>An officer checks the Council roster.</strong> You get an email when you can sign in, usually within a few days.</li>'
		. '</ol></section></div>';
	return $html;
}

/* ───────── Officers: Brothers screen ───────── */

add_action(
	'admin_menu',
	function () {
		$waiting = current_user_can( 'kofc_review_members' ) ? count( kofc_members_waiting() ) : 0;
		add_menu_page(
			'Brothers',
			'Brothers' . ( $waiting ? ' <span class="awaiting-mod">' . (int) $waiting . '</span>' : '' ),
			'kofc_review_members',
			'kofc-brothers',
			'kofc_members_screen',
			'dashicons-groups',
			71
		);
	}
);

/* On the dashboard, remind officers when requests are waiting. */
add_action(
	'admin_notices',
	function () {
		global $pagenow;
		if ( 'index.php' !== $pagenow || ! current_user_can( 'kofc_review_members' ) ) {
			return;
		}
		$waiting = count( kofc_members_waiting() );
		if ( $waiting ) {
			printf(
				'<div class="notice notice-warning"><p><strong>%s</strong> <a href="%s">Review requests</a></p></div>',
				esc_html( sprintf( 1 === $waiting ? '%d brother is waiting for access to the members\' area.' : '%d brothers are waiting for access to the members\' area.', $waiting ) ),
				esc_url( admin_url( 'admin.php?page=kofc-brothers' ) )
			);
		}
	}
);

function kofc_members_action_button( $user, $action, $label, $class, $confirm = '' ) {
	return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="kofc-inline"'
		. ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '>'
		. '<input type="hidden" name="action" value="kofc_brother"><input type="hidden" name="do" value="' . esc_attr( $action ) . '">'
		. '<input type="hidden" name="user" value="' . (int) $user->ID . '">'
		. wp_nonce_field( "kofc_brother_{$action}_{$user->ID}", '_wpnonce', true, false )
		. '<button type="submit" class="button ' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
}

function kofc_members_date( $mysql ) {
	return $mysql ? esc_html( mysql2date( 'M j, Y', $mysql ) ) : '—';
}

function kofc_members_screen() {
	if ( ! current_user_can( 'kofc_review_members' ) ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification -- display only.
	$done = isset( $_GET['done'] ) ? sanitize_key( $_GET['done'] ) : '';
	$who  = isset( $_GET['who'] ) ? sanitize_text_field( wp_unslash( $_GET['who'] ) ) : '';
	// phpcs:enable
	$messages = array(
		'approved'        => array( 'success', "$who can now sign in to the members' area. He has been emailed." ),
		'approved-nomail' => array( 'warning', "$who can now sign in to the members' area, but the email to tell him could not be sent. Please let him know yourself." ),
		'declined'        => array( 'success', "The request from $who was declined and deleted." ),
		'removed'         => array( 'success', "$who no longer has access. His account was deleted." ),
	);

	echo '<div class="wrap"><h1>Brothers</h1>';
	echo '<style>.kofc-inline{display:inline-block;margin:0 6px 4px 0}.kofc-brothers td{vertical-align:middle}</style>';
	if ( isset( $messages[ $done ] ) ) {
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $messages[ $done ][0] ), esc_html( $messages[ $done ][1] ) );
	}
	echo '<p>Brothers sign in to read the pages set to <strong>Members only</strong>. A request comes from someone who signed in with WordPress.com on the Members page, so it has his name and email only. Check them against the Council roster before approving.</p>';

	$waiting = kofc_members_waiting();
	echo '<h2>Waiting for approval (' . count( $waiting ) . ')</h2>';
	if ( ! $waiting ) {
		echo '<p>No requests are waiting.</p>';
	} else {
		echo '<table class="widefat striped kofc-brothers"><thead><tr><th>Name</th><th>Email</th><th>Asked on</th><th>Decision</th></tr></thead><tbody>';
		foreach ( $waiting as $user ) {
			echo '<tr><td><strong>' . esc_html( $user->display_name ) . '</strong></td>'
				. '<td><a href="mailto:' . esc_attr( $user->user_email ) . '">' . esc_html( $user->user_email ) . '</a></td>'
				. '<td>' . kofc_members_date( get_user_meta( $user->ID, 'kofc_requested', true ) ) . '</td>'
				. '<td>' . kofc_members_action_button( $user, 'approve', 'Approve', 'button-primary' )
				. kofc_members_action_button( $user, 'decline', 'Decline', '', "Decline and delete the request from {$user->display_name}?" ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}

	$brothers = get_users(
		array(
			'role'    => 'brother',
			'orderby' => 'display_name',
		)
	);
	echo '<h2 style="margin-top:2em">Brothers with access (' . count( $brothers ) . ')</h2>';
	if ( ! $brothers ) {
		echo '<p>Nobody yet.</p>';
	} else {
		echo '<table class="widefat striped kofc-brothers"><thead><tr><th>Name</th><th>Email</th><th>Approved</th><th></th></tr></thead><tbody>';
		foreach ( $brothers as $user ) {
			$by_id = (int) get_user_meta( $user->ID, 'kofc_approved_by', true );
			$by    = $by_id ? get_userdata( $by_id ) : null;
			echo '<tr><td><strong>' . esc_html( $user->display_name ) . '</strong></td>'
				. '<td><a href="mailto:' . esc_attr( $user->user_email ) . '">' . esc_html( $user->user_email ) . '</a></td>'
				. '<td>' . kofc_members_date( get_user_meta( $user->ID, 'kofc_approved', true ) ) . ( $by ? ' by ' . esc_html( $by->display_name ) : '' ) . '</td>'
				. '<td>' . kofc_members_action_button( $user, 'remove', 'Remove access', '', "Remove {$user->display_name}'s access? His account will be deleted." ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

add_action(
	'admin_post_kofc_brother',
	function () {
		if ( ! current_user_can( 'kofc_review_members' ) ) {
			wp_die( 'You are not allowed to review members\' area requests.', 403 );
		}
		$user_id = isset( $_POST['user'] ) ? absint( $_POST['user'] ) : 0;
		$action  = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';
		check_admin_referer( "kofc_brother_{$action}_{$user_id}" );
		$user = get_userdata( $user_id );
		// Only ever change brothers' accounts, never an officer's.
		if ( ! kofc_members_is_brother_account( $user ) ) {
			wp_die( 'That is not a brother\'s account.', 400 );
		}
		$result = '';
		if ( 'approve' === $action && in_array( 'brother_pending', $user->roles, true ) ) {
			$user->set_role( 'brother' );
			update_user_meta( $user_id, 'kofc_approved', current_time( 'mysql' ) );
			update_user_meta( $user_id, 'kofc_approved_by', get_current_user_id() );
			$sent   = wp_mail(
				$user->user_email,
				'Welcome to the Council 8600 members\' area',
				'Dear ' . ( $user->first_name ? 'Brother ' . $user->first_name : $user->display_name ) . ",\n\n"
				. "An officer has approved your access to the members' area of the Council 8600 website.\n\n"
				. "On the Members page, press \"Continue with WordPress.com\" and sign in with the same Google, Apple or WordPress.com account you used to ask. WordPress.com then asks for your second step, such as the code it texts to your phone.\n\n"
				. kofc_members_url() . "\n\n"
				. "Vivat Jesus!\nCouncil 8600\n"
			);
			$result = $sent ? 'approved' : 'approved-nomail';
		} elseif ( in_array( $action, array( 'decline', 'remove' ), true ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );
			$result = 'decline' === $action ? 'declined' : 'removed';
		}
		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'kofc-brothers',
					'done' => $result,
					'who'  => rawurlencode( $user->display_name ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
);
