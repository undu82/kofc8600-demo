<?php
/**
 * Plugin Name: Council 8600 Members
 * Description: A members' area for brothers of the Council. A brother asks for access, an officer checks him against the Council roster and approves him, and he can then sign in and read pages set to "Members only".
 * Version: 0.2.0
 * Requires at least: 7.0
 * Requires PHP: 7.4
 * Requires Plugins: two-factor
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 *
 * How it works:
 * - "Members only" is WordPress's own Private visibility, renamed in the editor.
 *   Brothers may read private pages; visitors who are not signed in cannot.
 * - [council_members] on the Members page shows visitors a sign-in box and a
 *   request form, and shows brothers the list of members-only pages.
 * - A request creates an account with the "Brother (waiting for approval)"
 *   role, which cannot sign in. Officers (Editors and Administrators) approve or
 *   decline it under Brothers in the dashboard, which never touches an officer's
 *   own account.
 * - Signing in with a password takes a second step: a code emailed to the
 *   brother or officer, from the Two Factor plugin (WordPress.org). Anyone can
 *   switch to an authenticator app in their profile instead.
 * - Council emails (council-emails.php): the emails the Council sends through
 *   Flocknote, kept in the members' area.
 * - Members' documents (documents.php): PDFs such as minutes and budgets, which
 *   nobody can open without signing in, even with the file's link.
 *
 * @package kofc8600-members
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/council-emails.php';
require_once __DIR__ . '/documents.php';

/* ───────── Roles ───────── */

function kofc_members_setup_roles() {
	remove_role( 'brother' );
	add_role(
		'brother',
		'Brother',
		array(
			'read'                        => true,
			'read_private_pages'          => true,
			'read_private_posts'          => true,
			'read_private_council_emails' => true,
		)
	);
	remove_role( 'brother_pending' );
	add_role( 'brother_pending', 'Brother (waiting for approval)', array() );
	foreach ( array( 'administrator', 'editor' ) as $officer ) {
		$role = get_role( $officer );
		if ( $role ) {
			$role->add_cap( 'kofc_review_members' );
			foreach ( kofc_emails_officer_caps() as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
}
register_activation_hook(
	__FILE__,
	function () {
		kofc_members_setup_roles();
		// The Council emails' addresses (/members/emails/<subject>/) are new to WordPress. Clearing its saved
		// address rules makes it rebuild them on the next page load, with those included; otherwise each email
		// opens "Page not found" until someone re-saves Settings > Permalinks.
		delete_option( 'rewrite_rules' );
	}
);
register_deactivation_hook(
	__FILE__,
	function () {
		delete_option( 'rewrite_rules' );
	}
);

add_action(
	'init',
	function () {
		$editor = get_role( 'editor' );
		if ( ! get_role( 'brother' ) || ! get_role( 'brother_pending' ) || ( $editor && ! $editor->has_cap( 'edit_others_council_emails' ) ) ) {
			kofc_members_setup_roles();
		}
	}
);

/* True for brothers, approved or waiting, and nobody else. Officers' accounts are never "brother accounts". */
function kofc_members_is_brother_account( $user ) {
	$roles = $user ? (array) $user->roles : array();
	return $roles && ! array_diff( $roles, array( 'brother', 'brother_pending' ) );
}

/* The Members page, found by its address. */
function kofc_members_url( $args = array() ) {
	$page = get_page_by_path( 'members' );
	return add_query_arg( $args, $page ? get_permalink( $page ) : home_url( '/' ) );
}

function kofc_members_waiting() {
	return get_users(
		array(
			'role'    => 'brother_pending',
			'orderby' => 'registered',
			'order'   => 'ASC',
		)
	);
}

/* ───────── Members-only pages ───────── */

/* Show "Members only" pages as they are, without WordPress's "Private:" in front of the title. */
add_filter(
	'private_title_format',
	function () {
		return '%s';
	}
);

/* A members-only page in a menu shows for brothers and officers, and stays hidden from everyone else. */
add_filter(
	'render_block_core_navigation_link_allowed_post_status',
	function ( $statuses ) {
		if ( current_user_can( 'read_private_pages' ) ) {
			$statuses[] = 'private';
		}
		return $statuses;
	}
);

/* Someone opening a members-only page without access goes to the Members page to sign in, then comes back. */
add_action(
	'template_redirect',
	function () {
		global $wp;
		if ( ! is_404() || current_user_can( 'read_private_pages' ) || '' === $wp->request ) {
			return;
		}
		$page = get_page_by_path( $wp->request );
		if ( $page && 'private' === $page->post_status ) {
			// The address as typed: WordPress gives private pages a plain ?page_id= link for visitors.
			$back = home_url( user_trailingslashit( $wp->request ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which members' document to show after signing in (documents.php).
			if ( ! empty( $_GET['doc'] ) ) {
				$back = add_query_arg( 'doc', absint( $_GET['doc'] ), $back );
			}
			wp_safe_redirect(
				kofc_members_url(
					array(
						'members-only' => 1,
						'redirect_to'  => rawurlencode( $back ),
					)
				)
			);
			exit;
		}
	},
	5
);

/* A "Members only" label above the title, so brothers know not to share the page. */
add_filter(
	'render_block_core/post-title',
	function ( $html, $block, $instance ) {
		$id = isset( $instance->context['postId'] ) ? (int) $instance->context['postId'] : 0;
		if ( $id && is_singular() && get_queried_object_id() === $id && 'private' === get_post_status( $id ) ) {
			$html = '<p class="members-badge">Members only</p>' . $html;
		}
		return $html;
	},
	10,
	3
);

/* In the editor and the Pages list, call Private visibility "Members only". */
add_action(
	'enqueue_block_editor_assets',
	function () {
		wp_register_script( 'kofc8600-members-editor', false, array( 'wp-hooks' ), '0.1.0', false );
		wp_enqueue_script( 'kofc8600-members-editor' );
		wp_add_inline_script(
			'kofc8600-members-editor',
			"wp.hooks.addFilter('i18n.gettext','kofc8600/members',function(t,text){if(text==='Private')return 'Members only';if(text==='Only visible to site admins and editors.')return 'Only brothers and officers who are signed in can see it.';return t;});"
		);
	}
);
add_filter(
	'display_post_states',
	function ( $states ) {
		if ( isset( $states['private'] ) ) {
			$states['private'] = 'Members only';
		}
		return $states;
	}
);

/* ───────── Signing in ───────── */

/* A brother whose request has not been approved yet cannot sign in. */
add_filter(
	'authenticate',
	function ( $user ) {
		if ( $user instanceof WP_User && in_array( 'brother_pending', (array) $user->roles, true ) ) {
			return new WP_Error( 'kofc_pending', 'Your request for the members\' area is waiting for an officer to check the Council roster. You will get an email once it is approved.' );
		}
		return $user;
	},
	99
);

/*
 * WordPress.com login (Jetpack's single sign-on) is always on for our plan, and
 * it skips the `authenticate` check above. A brother still waiting for approval
 * who tries "Log in with WordPress.com" goes back to the Members page with the
 * same message, before he is signed in.
 */
add_action(
	'jetpack_sso_handle_login',
	function ( $user ) {
		if ( $user instanceof WP_User && in_array( 'brother_pending', (array) $user->roles, true ) ) {
			wp_safe_redirect( kofc_members_url( array( 'members-waiting' => 1 ) ) );
			exit;
		}
		/*
		 * Jetpack keeps the page the person was trying to open in a cookie while they
		 * are away at WordPress.com. Our emailed-code screen (Two Factor) comes next and
		 * reads that page from the request instead, so without this a brother would
		 * land on the Members page rather than the members-only page he wanted.
		 */
		if ( empty( $_REQUEST['redirect_to'] ) && isset( $_COOKIE['jetpack_sso_redirect_to'] ) && is_string( $_COOKIE['jetpack_sso_redirect_to'] ) ) {
			$to = wp_validate_redirect( esc_url_raw( wp_unslash( $_COOKIE['jetpack_sso_redirect_to'] ) ), '' );
			if ( $to ) {
				$_REQUEST['redirect_to'] = $to;
			}
		}
	}
);

/*
 * The Members page's "Continue with WordPress.com" button, shown when WordPress.com's
 * login is on. WordPress.com's sign-in page also offers Google and Apple. The button
 * opens WordPress's sign-in screen with kofc-wpcom=1, which tells Jetpack to note the
 * page the brother wanted and go straight on to WordPress.com, in one click.
 */
function kofc_members_wpcom_login_on() {
	$on = class_exists( '\Automattic\Jetpack\Modules' ) && ( new \Automattic\Jetpack\Modules() )->is_active( 'sso' );
	return (bool) apply_filters( 'kofc_members_wpcom_login', $on );
}
add_filter(
	'jetpack_sso_bypass_login_forward_wpcom',
	function ( $forward ) {
		return empty( $_GET['kofc-wpcom'] ) ? $forward : true; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only skips a click.
	}
);

/*
 * On WordPress.com, the sign-in screen opens on the "Log in with WordPress.com"
 * button and hides the password form, which also hides the box for our emailed
 * code. Brothers come from the Members page, so when the sign-in is headed back
 * to the site rather than the dashboard, open on the password form. Officers
 * going to /wp-admin keep the WordPress.com button first.
 */
add_filter(
	'jetpack_sso_default_to_sso_login',
	function ( $default ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- chooses which form to show, nothing else.
		$to = isset( $_REQUEST['redirect_to'] ) && is_string( $_REQUEST['redirect_to'] ) ? wp_unslash( $_REQUEST['redirect_to'] ) : '';
		return ( '' !== $to && false === strpos( $to, '/wp-admin' ) ) ? false : $default;
	}
);

/*
 * And if WordPress.com still shows its own form on the code screen (when two-step
 * sign-in is required for WordPress.com logins), keep the code box visible. This is
 * the fix from Two Factor's pull request #1009, not yet released (0.17.0 lacks it).
 * It is added to Two Factor's own stylesheet, which loads only on the code screen.
 */
add_action(
	'login_enqueue_scripts',
	function () {
		if ( wp_style_is( 'user-edit-2fa', 'enqueued' ) ) {
			wp_add_inline_style( 'user-edit-2fa', 'body.jetpack-sso-form-display #loginform > p, body.jetpack-sso-form-display #loginform > div { display: block; }' );
		}
	}
);

/* Brothers land on the Members page, or the page they were trying to open, never on the dashboard. */
add_filter(
	'login_redirect',
	function ( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && kofc_members_is_brother_account( $user ) ) {
			return ( $requested && false === strpos( $requested, '/wp-admin' ) ) ? $redirect_to : kofc_members_url();
		}
		return $redirect_to;
	},
	10,
	3
);
add_action(
	'admin_init',
	function () {
		if ( wp_doing_ajax() || ! kofc_members_is_brother_account( wp_get_current_user() ) ) {
			return;
		}
		global $pagenow;
		if ( 'profile.php' !== $pagenow && 'admin-post.php' !== $pagenow ) {
			wp_safe_redirect( kofc_members_url() );
			exit;
		}
	}
);
add_filter(
	'show_admin_bar',
	function ( $show ) {
		return kofc_members_is_brother_account( wp_get_current_user() ) ? false : $show;
	}
);

/* "Keep me signed in" lasts six months for brothers, so they are not asked again every two weeks. */
add_filter(
	'auth_cookie_expiration',
	function ( $expiration, $user_id, $remember ) {
		return ( $remember && kofc_members_is_brother_account( get_userdata( $user_id ) ) ) ? 180 * DAY_IN_SECONDS : $expiration;
	},
	10,
	3
);

/*
 * Second step at sign-in. The Two Factor plugin leaves it to each person to
 * turn on; here everyone who signs in with a password gets a code by email,
 * unless they have set up an authenticator app instead. Unticking every method
 * in the profile brings the emailed code back, so it cannot be switched off.
 */
add_filter(
	'two_factor_enabled_providers_for_user',
	function ( $providers ) {
		return $providers ? $providers : array( 'Two_Factor_Email' );
	}
);
add_filter(
	'two_factor_email_token_length',
	function () {
		return 6; // Easier to type than the plugin's 8; failed attempts are still rate-limited.
	}
);
add_filter(
	'two_factor_token_email_subject',
	function () {
		return 'Your Council 8600 sign-in code';
	}
);
add_filter(
	'two_factor_token_email_message',
	function ( $message, $token ) {
		return "Your sign-in code is: $token\n\n"
			. "Type it on the sign-in page to finish signing in. It works once and expires in 15 minutes.\n\n"
			. "If you did not just try to sign in, you can ignore this email: your password alone is not enough to get in. You may want to change your password, though.\n\n"
			. "Council 8600\n";
	},
	10,
	2
);

/* ───────── Asking for access ───────── */

$GLOBALS['kofc_members_form'] = array(
	'errors' => array(),
	'values' => array(),
);

add_action(
	'template_redirect',
	function () {
		if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || empty( $_POST['kofc_member_request'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- public form; spam traps below.
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification
		$values = array();
		foreach ( array( 'first', 'last', 'email', 'number', 'phone' ) as $key ) {
			$values[ $key ] = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
		}
		$values['email'] = sanitize_email( $values['email'] );
		$pass            = isset( $_POST['pass'] ) && is_string( $_POST['pass'] ) ? wp_unslash( $_POST['pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- passwords are not altered.
		$pass2           = isset( $_POST['pass2'] ) && is_string( $_POST['pass2'] ) ? wp_unslash( $_POST['pass2'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$started         = isset( $_POST['started'] ) ? (int) $_POST['started'] : 0;
		$trap            = ! empty( $_POST['website'] );
		// phpcs:enable

		$done = kofc_members_url( array( 'request' => 'sent' ) ) . '#request';

		// Spam traps: a hidden field people never fill in, and forms sent back within three seconds.
		if ( $trap || ( $started && time() - $started < 3 ) ) {
			wp_safe_redirect( $done );
			exit;
		}

		$errors = array();
		if ( '' === $values['first'] || '' === $values['last'] ) {
			$errors['first'] = 'Enter your first and last name.';
		}
		if ( ! is_email( $values['email'] ) ) {
			$errors['email'] = 'Enter an email address, like name@example.com.';
		}
		if ( strlen( $pass ) < 8 ) {
			$errors['pass'] = 'Choose a password of at least 8 characters.';
		} elseif ( $pass !== $pass2 ) {
			$errors['pass2'] = 'The two passwords are not the same. Type them again.';
		}
		$limit_key = 'kofc_member_requests_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' );
		$recent    = (int) get_transient( $limit_key );
		if ( ! $errors && $recent >= 5 ) {
			$errors['form'] = 'Too many requests from this connection. Please try again in an hour.';
		}
		if ( $errors ) {
			$GLOBALS['kofc_members_form'] = array(
				'errors' => $errors,
				'values' => $values,
			);
			return;
		}
		set_transient( $limit_key, $recent + 1, HOUR_IN_SECONDS );

		// The same thank-you whether or not the address already has an account, so the form cannot be used to find out who is registered.
		if ( ! email_exists( $values['email'] ) && ! username_exists( $values['email'] ) ) {
			$user_id = wp_insert_user(
				array(
					'user_login'   => strlen( $values['email'] ) <= 60 ? $values['email'] : 'brother-' . wp_generate_password( 10, false ),
					'user_email'   => $values['email'],
					'user_pass'    => $pass,
					'first_name'   => $values['first'],
					'last_name'    => $values['last'],
					'display_name' => $values['first'] . ' ' . $values['last'],
					'role'         => 'brother_pending',
				)
			);
			if ( ! is_wp_error( $user_id ) ) {
				update_user_meta( $user_id, 'kofc_member_number', $values['number'] );
				update_user_meta( $user_id, 'kofc_phone', $values['phone'] );
				update_user_meta( $user_id, 'kofc_requested', current_time( 'mysql' ) );
				kofc_members_tell_officers( get_userdata( $user_id ) );
			}
		}
		wp_safe_redirect( $done );
		exit;
	}
);

/* Email the officers about a new request. The address is the site's admin email (Settings, General). */
function kofc_members_tell_officers( $user ) {
	$number = get_user_meta( $user->ID, 'kofc_member_number', true );
	$phone  = get_user_meta( $user->ID, 'kofc_phone', true );
	wp_mail(
		apply_filters( 'kofc_members_notify', get_option( 'admin_email' ) ),
		'Members\' area request: ' . $user->display_name,
		"{$user->display_name} has asked for access to the members' area.\n\n"
		. "Email: {$user->user_email}\n"
		. 'Member number: ' . ( $number ? $number : 'not given' ) . "\n"
		. 'Phone: ' . ( $phone ? $phone : 'not given' ) . "\n\n"
		. "Check him against the Council roster, then approve or decline the request here:\n"
		. admin_url( 'admin.php?page=kofc-brothers' ) . "\n"
	);
}

/* ───────── The Members page: [council_members] ───────── */

add_shortcode(
	'council_members',
	function () {
		if ( current_user_can( 'read_private_pages' ) ) {
			return kofc_members_area();
		}
		if ( is_user_logged_in() ) {
			return '<div class="members-notice"><p><strong>Your account does not include the members\' area.</strong> Ask an officer to add it, or <a href="' . esc_url( wp_logout_url( kofc_members_url() ) ) . '">sign out</a> and sign in as a brother.</p></div>';
		}
		return kofc_members_signin();
	}
);

/* What a signed-in brother sees: the members-only pages. */
function kofc_members_area() {
	$user  = wp_get_current_user();
	$pages = get_pages(
		array(
			'post_status'  => 'private',
			'sort_column'  => 'menu_order,post_title',
			'hierarchical' => 0, // Otherwise pages under a public parent (the Members page) are left out.
		)
	);
	$html  = '<div class="members-welcome"><p class="members-hello">Welcome, ' . esc_html( $user->first_name ? 'Brother ' . $user->first_name : $user->display_name ) . '.</p>';
	$html .= '<p><a href="' . esc_url( wp_logout_url( kofc_members_url() ) ) . '">Sign out</a></p></div>';
	if ( current_user_can( 'kofc_review_members' ) ) {
		$waiting = count( kofc_members_waiting() );
		$html   .= '<div class="members-notice"><p><strong>' . esc_html( sprintf( 1 === $waiting ? '%d request is waiting.' : '%d requests are waiting.', $waiting ) ) . '</strong> <a href="' . esc_url( admin_url( 'admin.php?page=kofc-brothers' ) ) . '">Review requests</a></p></div>';
	}
	$html .= kofc_emails_latest_row();
	if ( ! $pages ) {
		return $html . '<p>No members-only pages yet.</p>';
	}
	$html .= '<div class="rows members-pages">';
	foreach ( $pages as $page ) {
		$html .= '<p class="row icon-lock"><a href="' . esc_url( get_permalink( $page ) ) . '"><strong>' . esc_html( get_the_title( $page ) ) . '</strong>'
			. ( $page->post_excerpt ? '<span>' . esc_html( $page->post_excerpt ) . '</span>' : '' ) . '</a></p>';
	}
	return $html . '</div>';
}

/* What a visitor sees: sign in, or ask for access. */
function kofc_members_signin() {
	// phpcs:disable WordPress.Security.NonceVerification -- display only.
	$redirect = isset( $_GET['redirect_to'] ) && is_string( $_GET['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ), kofc_members_url() ) : kofc_members_url();
	$sent     = isset( $_GET['request'] ) && 'sent' === $_GET['request'];
	$locked   = ! empty( $_GET['members-only'] );
	$waiting  = ! empty( $_GET['members-waiting'] );
	// phpcs:enable
	$form   = $GLOBALS['kofc_members_form'];
	$errors = $form['errors'];
	$val    = function ( $key ) use ( $form ) {
		return isset( $form['values'][ $key ] ) ? esc_attr( $form['values'][ $key ] ) : '';
	};
	$error  = function ( $key ) use ( $errors ) {
		return isset( $errors[ $key ] ) ? '<p class="field-error" id="r-' . esc_attr( $key ) . '-error">' . esc_html( $errors[ $key ] ) . '</p>' : '';
	};
	$aria   = function ( $key ) use ( $errors ) {
		return isset( $errors[ $key ] ) ? ' aria-invalid="true" aria-describedby="r-' . esc_attr( $key ) . '-error"' : '';
	};

	$html = '';
	if ( $waiting ) {
		$html .= '<div class="members-notice" role="status"><p><strong>Your request is waiting for an officer.</strong> An officer will check the Council roster, and you will get an email once you can sign in.</p></div>';
	} elseif ( $locked ) {
		$html .= '<div class="members-notice"><p><strong>That page is for brothers of Council 8600.</strong> Sign in to open it.</p></div>';
	}
	$html .= '<div class="members-grid">';

	// Sign in.
	$html .= '<section class="members-card" aria-labelledby="signin-title"><h2 id="signin-title" class="members-card-title">Sign in</h2>';
	$wpcom_note = '<p class="provider-note">Use your Google or Apple account, or a WordPress.com account. Its email must be the one you gave when you asked for access.</p>';
	if ( kofc_members_wpcom_login_on() ) {
		$html .= '<div class="signin-providers">'
			. '<a class="provider" href="' . esc_url( add_query_arg( 'kofc-wpcom', '1', wp_login_url( $redirect ) ) ) . '">Continue with WordPress.com</a>'
			. $wpcom_note . '</div>'
			. '<p class="or"><span>or with your email and password</span></p>';
	} elseif ( get_option( 'kofc_members_demo_providers' ) ) {
		$html .= '<div class="signin-providers">'
			. '<button type="button" class="provider" data-demo-provider="WordPress.com">Continue with WordPress.com</button>'
			. $wpcom_note
			. '<p class="provider-status" role="status"></p></div>'
			. '<p class="or"><span>or with your email and password</span></p>';
	}
	$html .= '<form class="council-form members-signin" method="post" action="' . esc_url( site_url( 'wp-login.php', 'login_post' ) ) . '">'
		. '<div class="field"><label for="m-email">Email address</label><input id="m-email" name="log" type="text" inputmode="email" autocomplete="username" autocapitalize="off" spellcheck="false" required></div>'
		. '<div class="field"><label for="m-pass">Password</label><input id="m-pass" name="pwd" type="password" autocomplete="current-password" required></div>'
		. '<label class="check"><input type="checkbox" name="rememberme" value="forever" checked> <span>Keep me signed in on this device</span></label>'
		. '<input type="hidden" name="redirect_to" value="' . esc_attr( $redirect ) . '">'
		. '<button type="submit">Sign in</button>'
		. ( class_exists( 'Two_Factor_Core' ) ? '<p class="hint">After your password, we email you a 6-digit code to finish signing in. With "Keep me signed in" ticked, this device will not ask again for six months.</p>' : '' )
		. '<p class="fine"><a href="' . esc_url( wp_lostpassword_url( $redirect ) ) . '">Forgot your password?</a></p>'
		. '</form></section>';

	// Ask for access.
	$html .= '<section class="members-card" id="request" aria-labelledby="request-title"><h2 id="request-title" class="members-card-title">First time? Ask for access</h2>';
	if ( $sent ) {
		return $html . '<div class="members-notice is-done" role="status"><p><strong>Thank you. Your request has been sent.</strong></p><p>An officer will check the Council roster and you will get an email when you can sign in, usually within a few days.</p></div></section></div>';
	}
	$html .= '<p>An officer checks every request against the Council roster before it is approved.</p>';
	if ( $errors ) {
		$html .= '<div class="form-errors" role="alert"><p><strong>Please check the form.</strong></p><ul><li>' . implode( '</li><li>', array_map( 'esc_html', $errors ) ) . '</li></ul></div>';
	}
	$html .= '<form class="council-form" method="post" action="' . esc_url( kofc_members_url() ) . '#request" novalidate>'
		. '<input type="hidden" name="kofc_member_request" value="1"><input type="hidden" name="started" value="' . esc_attr( time() ) . '">'
		. '<p class="hp" aria-hidden="true"><label>Leave this empty <input name="website" tabindex="-1" autocomplete="off"></label></p>'
		. '<p class="fine">Fields marked * are required.</p>'
		. '<fieldset><legend>Your name *</legend><div class="pair">'
		. '<span><label for="r-first">First</label><input id="r-first" name="first" autocomplete="given-name" required value="' . $val( 'first' ) . '"' . ( '' === $val( 'first' ) ? $aria( 'first' ) : '' ) . '></span>'
		. '<span><label for="r-last">Last</label><input id="r-last" name="last" autocomplete="family-name" required value="' . $val( 'last' ) . '"' . ( '' === $val( 'last' ) ? $aria( 'first' ) : '' ) . '></span>'
		. '</div>' . $error( 'first' ) . '</fieldset>'
		. '<div class="field"><label for="r-email">Email address *</label><input id="r-email" name="email" type="email" autocomplete="email" required value="' . $val( 'email' ) . '"' . $aria( 'email' ) . '>' . $error( 'email' ) . '</div>'
		. '<div class="field"><label for="r-number">Member number</label><p class="hint" id="r-number-hint">On your membership card. It helps the officer find you.</p><input id="r-number" name="number" inputmode="numeric" aria-describedby="r-number-hint" value="' . $val( 'number' ) . '"></div>'
		. '<div class="field"><label for="r-phone">Phone</label><input id="r-phone" name="phone" type="tel" autocomplete="tel" value="' . $val( 'phone' ) . '"></div>'
		. '<fieldset><legend>Choose a password *</legend><p class="hint">At least 8 characters.</p><div class="pair">'
		. '<span><label for="r-pass">Password</label><input id="r-pass" name="pass" type="password" autocomplete="new-password" required' . $aria( 'pass' ) . '></span>'
		. '<span><label for="r-pass2">Type it again</label><input id="r-pass2" name="pass2" type="password" autocomplete="new-password" required' . $aria( 'pass2' ) . '></span>'
		. '</div>' . $error( 'pass' ) . $error( 'pass2' ) . '</fieldset>'
		. '<button type="submit">Ask for access</button>'
		. '</form></section></div>';
	return $html;
}

/* ───────── Officers: Brothers screen ───────── */

add_action(
	'admin_menu',
	function () {
		$waiting = current_user_can( 'kofc_review_members' ) ? count( kofc_members_waiting() ) : 0;
		add_menu_page(
			'Brothers',
			'Brothers' . ( $waiting ? ' <span class="awaiting-mod">' . (int) $waiting . '</span>' : '' ),
			'kofc_review_members',
			'kofc-brothers',
			'kofc_members_screen',
			'dashicons-groups',
			71
		);
	}
);

/* On the dashboard, remind officers when requests are waiting. */
add_action(
	'admin_notices',
	function () {
		global $pagenow;
		if ( 'index.php' !== $pagenow || ! current_user_can( 'kofc_review_members' ) ) {
			return;
		}
		$waiting = count( kofc_members_waiting() );
		if ( $waiting ) {
			printf(
				'<div class="notice notice-warning"><p><strong>%s</strong> <a href="%s">Review requests</a></p></div>',
				esc_html( sprintf( 1 === $waiting ? '%d brother is waiting for access to the members\' area.' : '%d brothers are waiting for access to the members\' area.', $waiting ) ),
				esc_url( admin_url( 'admin.php?page=kofc-brothers' ) )
			);
		}
	}
);

function kofc_members_action_button( $user, $action, $label, $class, $confirm = '' ) {
	return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="kofc-inline"'
		. ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '>'
		. '<input type="hidden" name="action" value="kofc_brother"><input type="hidden" name="do" value="' . esc_attr( $action ) . '">'
		. '<input type="hidden" name="user" value="' . (int) $user->ID . '">'
		. wp_nonce_field( "kofc_brother_{$action}_{$user->ID}", '_wpnonce', true, false )
		. '<button type="submit" class="button ' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
}

function kofc_members_date( $mysql ) {
	return $mysql ? esc_html( mysql2date( 'M j, Y', $mysql ) ) : '—';
}

function kofc_members_screen() {
	if ( ! current_user_can( 'kofc_review_members' ) ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification -- display only.
	$done = isset( $_GET['done'] ) ? sanitize_key( $_GET['done'] ) : '';
	$who  = isset( $_GET['who'] ) ? sanitize_text_field( wp_unslash( $_GET['who'] ) ) : '';
	// phpcs:enable
	$messages = array(
		'approved'        => array( 'success', "$who can now sign in to the members' area. He has been emailed." ),
		'approved-nomail' => array( 'warning', "$who can now sign in to the members' area, but the email to tell him could not be sent. Please let him know yourself." ),
		'declined'        => array( 'success', "The request from $who was declined and deleted." ),
		'removed'         => array( 'success', "$who no longer has access. His account was deleted." ),
	);

	echo '<div class="wrap"><h1>Brothers</h1>';
	echo '<style>.kofc-inline{display:inline-block;margin:0 6px 4px 0}.kofc-brothers td{vertical-align:middle}</style>';
	if ( isset( $messages[ $done ] ) ) {
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $messages[ $done ][0] ), esc_html( $messages[ $done ][1] ) );
	}
	echo '<p>Brothers sign in to read the pages set to <strong>Members only</strong>. Before approving a request, check the name and member number against the Council roster.</p>';

	$waiting = kofc_members_waiting();
	echo '<h2>Waiting for approval (' . count( $waiting ) . ')</h2>';
	if ( ! $waiting ) {
		echo '<p>No requests are waiting.</p>';
	} else {
		echo '<table class="widefat striped kofc-brothers"><thead><tr><th>Name</th><th>Email</th><th>Member number</th><th>Phone</th><th>Asked on</th><th>Decision</th></tr></thead><tbody>';
		foreach ( $waiting as $user ) {
			echo '<tr><td><strong>' . esc_html( $user->display_name ) . '</strong></td>'
				. '<td><a href="mailto:' . esc_attr( $user->user_email ) . '">' . esc_html( $user->user_email ) . '</a></td>'
				. '<td>' . esc_html( get_user_meta( $user->ID, 'kofc_member_number', true ) ?: '—' ) . '</td>'
				. '<td>' . esc_html( get_user_meta( $user->ID, 'kofc_phone', true ) ?: '—' ) . '</td>'
				. '<td>' . kofc_members_date( get_user_meta( $user->ID, 'kofc_requested', true ) ) . '</td>'
				. '<td>' . kofc_members_action_button( $user, 'approve', 'Approve', 'button-primary' )
				. kofc_members_action_button( $user, 'decline', 'Decline', '', "Decline and delete the request from {$user->display_name}?" ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}

	$brothers = get_users(
		array(
			'role'    => 'brother',
			'orderby' => 'display_name',
		)
	);
	echo '<h2 style="margin-top:2em">Brothers with access (' . count( $brothers ) . ')</h2>';
	if ( ! $brothers ) {
		echo '<p>Nobody yet.</p>';
	} else {
		echo '<table class="widefat striped kofc-brothers"><thead><tr><th>Name</th><th>Email</th><th>Member number</th><th>Approved</th><th></th></tr></thead><tbody>';
		foreach ( $brothers as $user ) {
			$by_id = (int) get_user_meta( $user->ID, 'kofc_approved_by', true );
			$by    = $by_id ? get_userdata( $by_id ) : null;
			echo '<tr><td><strong>' . esc_html( $user->display_name ) . '</strong></td>'
				. '<td><a href="mailto:' . esc_attr( $user->user_email ) . '">' . esc_html( $user->user_email ) . '</a></td>'
				. '<td>' . esc_html( get_user_meta( $user->ID, 'kofc_member_number', true ) ?: '—' ) . '</td>'
				. '<td>' . kofc_members_date( get_user_meta( $user->ID, 'kofc_approved', true ) ) . ( $by ? ' by ' . esc_html( $by->display_name ) : '' ) . '</td>'
				. '<td>' . kofc_members_action_button( $user, 'remove', 'Remove access', '', "Remove {$user->display_name}'s access? His account will be deleted." ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

add_action(
	'admin_post_kofc_brother',
	function () {
		if ( ! current_user_can( 'kofc_review_members' ) ) {
			wp_die( 'You are not allowed to review members\' area requests.', 403 );
		}
		$user_id = isset( $_POST['user'] ) ? absint( $_POST['user'] ) : 0;
		$action  = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';
		check_admin_referer( "kofc_brother_{$action}_{$user_id}" );
		$user = get_userdata( $user_id );
		// Only ever change brothers' accounts, never an officer's.
		if ( ! kofc_members_is_brother_account( $user ) ) {
			wp_die( 'That is not a brother\'s account.', 400 );
		}
		$result = '';
		if ( 'approve' === $action && in_array( 'brother_pending', $user->roles, true ) ) {
			$user->set_role( 'brother' );
			update_user_meta( $user_id, 'kofc_approved', current_time( 'mysql' ) );
			update_user_meta( $user_id, 'kofc_approved_by', get_current_user_id() );
			$sent   = wp_mail(
				$user->user_email,
				'Welcome to the Council 8600 members\' area',
				'Dear ' . ( $user->first_name ? 'Brother ' . $user->first_name : $user->display_name ) . ",\n\n"
				. "An officer has approved your access to the members' area of the Council 8600 website. Sign in with your email address and the password you chose. We will then email you a short code to finish signing in.\n\n"
				. kofc_members_url() . "\n\n"
				. 'Forgot your password? Choose a new one here: ' . wp_lostpassword_url() . "\n\n"
				. "Vivat Jesus!\nCouncil 8600\n"
			);
			$result = $sent ? 'approved' : 'approved-nomail';
		} elseif ( in_array( $action, array( 'decline', 'remove' ), true ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );
			$result = 'decline' === $action ? 'declined' : 'removed';
		}
		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'kofc-brothers',
					'done' => $result,
					'who'  => rawurlencode( $user->display_name ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
);
