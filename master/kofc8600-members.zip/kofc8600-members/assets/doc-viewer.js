/*
 * Council 8600 members' documents: shows a PDF page by page with PDF.js (Mozilla,
 * Apache-2.0, in ./pdfjs/), so it looks the same on phones and computers. The
 * Download and "Open in a new tab" buttons sit above it, and are the way in if
 * the viewer can't load.
 *
 * Pages are drawn as they scroll into view, at up to twice the screen's
 * resolution, so a long budget doesn't run a phone out of memory.
 */
const box = document.querySelector('.doc-pages[data-src]');

if (box) {
	const viewer = box.closest('.doc-viewer');
	const base = new URL('./pdfjs/', import.meta.url);
	const ratio = Math.min(window.devicePixelRatio || 1, 2);

	const draw = async (slot) => {
		const page = slot.pdfPage;
		const width = slot.clientWidth || box.clientWidth;
		const viewport = page.getViewport({ scale: (width / page.getViewport({ scale: 1 }).width) * ratio });
		const canvas = document.createElement('canvas');
		canvas.width = Math.floor(viewport.width);
		canvas.height = Math.floor(viewport.height);
		slot.append(canvas);
		await page.render({ canvas, viewport }).promise;
		slot.classList.add('is-drawn');
	};

	(async () => {
		try {
			const pdfjs = await import(new URL('pdf.min.js', base).href);
			pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdf.worker.min.js', base).href;
			const pdf = await pdfjs.getDocument({
				url: box.dataset.src,
				isEvalSupported: false,
				wasmUrl: base.href,
				useSystemFonts: true,
			}).promise;

			box.textContent = '';
			const watch = 'IntersectionObserver' in window
				? new IntersectionObserver((entries) => entries.forEach((entry) => {
					if (entry.isIntersecting) {
						watch.unobserve(entry.target);
						draw(entry.target).catch(() => entry.target.classList.add('is-failed'));
					}
				}), { rootMargin: '800px 0px' })
				: null;

			for (let n = 1; n <= pdf.numPages; n++) {
				const page = await pdf.getPage(n);
				const size = page.getViewport({ scale: 1 });
				const slot = document.createElement('div');
				slot.className = 'doc-page';
				slot.style.aspectRatio = size.width + ' / ' + size.height;
				slot.setAttribute('role', 'img');
				slot.setAttribute('aria-label', 'Page ' + n + ' of ' + pdf.numPages);
				slot.pdfPage = page;
				box.append(slot);
				if (watch) {
					watch.observe(slot);
				} else {
					await draw(slot);
				}
			}
			box.setAttribute('aria-busy', 'false');
			viewer.classList.add('is-ready');
		} catch (error) {
			box.setAttribute('aria-busy', 'false');
			viewer.classList.add('is-failed');
		}
	})();
}
