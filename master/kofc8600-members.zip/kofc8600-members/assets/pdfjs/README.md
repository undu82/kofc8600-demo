# PDF.js 6.4.299 (Mozilla), for the members' document viewer

From the npm package `pdfjs-dist@6.4.299` (published 2026-10-03, sha1 4a46f5146ac6505564c1a5d472900be4df8bf628), unmodified:

- `pdf.min.js` and `pdf.worker.min.js`: `legacy/build/pdf.min.mjs` and `legacy/build/pdf.worker.min.mjs` (the legacy build works on older phones), renamed from `.mjs` to `.js` so every web server sends them as JavaScript.
- `jbig2.wasm` and `openjpeg.wasm` from `wasm/`, for scanned documents.

Licences: `LICENSE` (Apache-2.0, PDF.js), and the `LICENSE_*` files for the two decoders. Used by `../doc-viewer.js`. To update, replace these files from a newer `pdfjs-dist` release and change the version here.
