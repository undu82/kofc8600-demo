<?php
/**
 * Members' documents: PDFs only brothers and officers can open, such as minutes,
 * budgets and by-laws.
 *
 * A file in WordPress's Media Library opens for anyone who has its link, even when
 * the page it's on is members-only. These files are kept apart instead: in the
 * uploads folder WordPress.com's servers refuse to hand out directly
 * (woocommerce_uploads, blocked on every WordPress.com site so stores can sell
 * downloads), each under a random name. The only way to one is through this
 * plugin, which first checks that the person is signed in as a brother or officer.
 *
 * Officers add them under Members' documents in the dashboard. Brothers find them
 * on the members-only Documents page ([council_documents]) and open each in a
 * viewer that works the same on phones and computers (PDF.js), with Download
 * beside it.
 *
 * @package kofc8600-members
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KOFC_DOCS_MAX_MB = 20;

function kofc_docs_types() {
	return array(
		'minutes' => 'Meeting minutes',
		'budget'  => 'Budget and finances',
		'bylaws'  => 'By-laws and policies',
		'other'   => 'Other documents',
	);
}

/* Brothers and officers read them; officers (Editors and Administrators) add and remove them. */
function kofc_docs_can_read() {
	return current_user_can( 'read_private_pages' );
}
function kofc_docs_can_manage() {
	return current_user_can( 'edit_others_pages' );
}

add_action(
	'init',
	function () {
		register_post_type(
			'council_document',
			array(
				'labels'       => array(
					'name'          => 'Members\' documents',
					'singular_name' => 'Members\' document',
				),
				'public'       => false,
				'show_ui'      => false, // Officers use the Members' documents screen below.
				'show_in_rest' => false,
				'can_export'   => false, // The files can't travel in an export file anyway.
				'rewrite'      => false,
				'query_var'    => false,
				'supports'     => array( 'title' ),
			)
		);
	}
);

/* ───────── Where the files are kept ───────── */

function kofc_docs_dir() {
	return wp_upload_dir( null, false )['basedir'] . '/woocommerce_uploads/kofc8600-members';
}

/* The folder, created on first use. The two small files keep it closed on other hosts too (Apache). */
function kofc_docs_make_dir() {
	$dir = kofc_docs_dir();
	if ( ! wp_mkdir_p( $dir ) ) {
		return new WP_Error( 'kofc_docs_dir', 'The site could not create the folder for members\' documents.' );
	}
	$parent = dirname( $dir );
	foreach ( array( $parent, $dir ) as $folder ) {
		if ( ! file_exists( "$folder/index.php" ) ) {
			file_put_contents( "$folder/index.php", "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		if ( ! file_exists( "$folder/.htaccess" ) ) {
			file_put_contents( "$folder/.htaccess", "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}
	return $dir;
}

/* A document's file on disk, or '' if it has none. Only the file name is stored, so the path can't point anywhere else. */
function kofc_docs_path( $doc ) {
	$name = basename( (string) get_post_meta( $doc->ID, '_kofc_doc_file', true ) );
	return ( '' !== $name && '.' !== $name[0] ) ? kofc_docs_dir() . '/' . $name : '';
}

/* Check an uploaded file is a PDF of an allowed size. Returns '' or what to tell the officer. */
function kofc_docs_check_upload( $file ) {
	if ( ! is_array( $file ) || ! isset( $file['error'], $file['tmp_name'], $file['name'], $file['size'] ) || is_array( $file['error'] ) ) {
		return 'The upload didn\'t work. Please try again.';
	}
	if ( in_array( (int) $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) || (int) $file['size'] > kofc_docs_max_bytes() ) {
		return 'That file is too large. The limit is ' . size_format( kofc_docs_max_bytes() ) . '.';
	}
	if ( UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
		return 'The upload didn\'t work. Please try again.';
	}
	$type = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'pdf' => 'application/pdf' ) );
	$head = (string) file_get_contents( $file['tmp_name'], false, null, 0, 1024 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( 'pdf' !== $type['ext'] || false === strpos( $head, '%PDF-' ) ) {
		return 'Only PDF files can be added. In Word or Excel, use File, then Save As, and choose PDF.';
	}
	return '';
}

function kofc_docs_max_bytes() {
	return (int) min( wp_max_upload_size(), KOFC_DOCS_MAX_MB * MB_IN_BYTES );
}

/* Put a PDF in the folder under a random name. Returns the name, or a WP_Error. */
function kofc_docs_store_file( $source, $title, $uploaded ) {
	$dir = kofc_docs_make_dir();
	if ( is_wp_error( $dir ) ) {
		return $dir;
	}
	$slug = substr( sanitize_title( $title ), 0, 60 );
	$name = ( '' !== $slug ? $slug : 'document' ) . '-' . bin2hex( random_bytes( 16 ) ) . '.pdf';
	$done = $uploaded ? move_uploaded_file( $source, "$dir/$name" ) : copy( $source, "$dir/$name" );
	if ( ! $done ) {
		return new WP_Error( 'kofc_docs_move', 'The site could not save the file. Please try again.' );
	}
	chmod( "$dir/$name", 0644 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
	return $name;
}

/*
 * Add or update a document. $source is the PDF (a path), or '' to keep the current
 * file when updating. Used by the officers' screen, and by the demo's setup.
 */
function kofc_docs_save( $id, $title, $type, $date, $source = '', $uploaded = false ) {
	$types = kofc_docs_types();
	$type  = isset( $types[ $type ] ) ? $type : 'other';
	$when  = DateTime::createFromFormat( '!Y-m-d', (string) $date );
	$local = ( $when ? $when->format( 'Y-m-d' ) : current_time( 'Y-m-d' ) ) . ' 12:00:00';
	$post  = array(
		'post_type'     => 'council_document',
		'post_status'   => 'private',
		'post_title'    => $title,
		'post_date'     => $local,
		'post_date_gmt' => get_gmt_from_date( $local ),
		'edit_date'     => true,
	);
	$file = '';
	if ( '' !== $source ) {
		$file = kofc_docs_store_file( $source, $title, $uploaded );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
	}
	if ( $id ) {
		$old        = get_post( $id );
		$post['ID'] = $id;
		$id         = wp_update_post( wp_slash( $post ), true );
	} else {
		$post['post_author'] = get_current_user_id();
		$id                  = wp_insert_post( wp_slash( $post ), true );
	}
	if ( is_wp_error( $id ) ) {
		if ( $file ) {
			wp_delete_file( kofc_docs_dir() . '/' . $file );
		}
		return $id;
	}
	update_post_meta( $id, '_kofc_doc_type', $type );
	if ( $file ) {
		$previous = isset( $old ) && $old ? kofc_docs_path( $old ) : '';
		update_post_meta( $id, '_kofc_doc_file', $file );
		update_post_meta( $id, '_kofc_doc_size', (int) filesize( kofc_docs_dir() . '/' . $file ) );
		if ( $previous && is_file( $previous ) ) {
			wp_delete_file( $previous ); // Replaced: the old file goes.
		}
	}
	return $id;
}

/* However a document is deleted, its file goes with it. */
add_action(
	'before_delete_post',
	function ( $post_id ) {
		$doc = get_post( $post_id );
		if ( $doc && 'council_document' === $doc->post_type ) {
			$path = kofc_docs_path( $doc );
			if ( $path && is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}
	}
);

/*
 * Whether the web server refuses a direct link to one of the files: 'yes', 'no',
 * or '' when it couldn't tell. WordPress.com doesn't document the rule this relies
 * on, so the officers' screen checks it, at most twice a day.
 */
function kofc_docs_protection() {
	if ( ! apply_filters( 'kofc_docs_check_protection', true ) ) {
		return '';
	}
	$known = get_transient( 'kofc_docs_protected' );
	if ( false !== $known ) {
		return $known;
	}
	$docs = kofc_docs_all();
	$path = $docs ? kofc_docs_path( $docs[0] ) : '';
	if ( ! $path || ! is_file( $path ) ) {
		return '';
	}
	$response = wp_remote_head(
		wp_upload_dir( null, false )['baseurl'] . '/woocommerce_uploads/kofc8600-members/' . rawurlencode( basename( $path ) ),
		array(
			'timeout'     => 5,
			'redirection' => 0,
		)
	);
	$code   = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
	$result = in_array( $code, array( 401, 403, 404 ), true ) ? 'yes' : ( 200 === $code ? 'no' : '' );
	set_transient( 'kofc_docs_protected', $result, 12 * HOUR_IN_SECONDS );
	return $result;
}

function kofc_docs_all() {
	return get_posts(
		array(
			'post_type'   => 'council_document',
			'post_status' => 'private',
			'numberposts' => -1,
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);
}

/* ───────── Addresses ───────── */

function kofc_docs_page_url() {
	$page = get_page_by_path( 'members/documents' );
	// Its address as typed, not get_permalink(): WordPress gives visitors a plain ?page_id= link for members-only pages.
	return $page ? home_url( user_trailingslashit( get_page_uri( $page ) ) ) : kofc_members_url();
}
function kofc_docs_view_url( $id ) {
	return add_query_arg( 'doc', (int) $id, kofc_docs_page_url() );
}
function kofc_docs_file_url( $id, $download = false ) {
	$args = array( 'kofc-doc' => (int) $id );
	if ( $download ) {
		$args['download'] = 1;
	}
	return add_query_arg( $args, home_url( '/' ) );
}

function kofc_docs_meta_line( $doc ) {
	$size = (int) get_post_meta( $doc->ID, '_kofc_doc_size', true );
	return get_the_date( 'F j, Y', $doc ) . ( $size ? ' · PDF, ' . size_format( $size ) : '' );
}

/* ───────── Handing out a file, after checking who is asking ───────── */

add_action(
	'init',
	function () {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- reading a file, guarded by the capability check.
		if ( is_admin() || ! isset( $_GET['kofc-doc'] ) ) {
			return;
		}
		$id       = absint( $_GET['kofc-doc'] );
		$download = ! empty( $_GET['download'] );
		// phpcs:enable
		$doc = $id ? get_post( $id ) : null;
		if ( ! $doc || 'council_document' !== $doc->post_type ) {
			wp_die( 'This document is no longer on the site.', 'Document not found', array( 'response' => 404 ) );
		}
		if ( ! is_user_logged_in() ) {
			// A forwarded link: sign in first, then see the document.
			wp_safe_redirect(
				kofc_members_url(
					array(
						'members-only' => 1,
						'redirect_to'  => rawurlencode( kofc_docs_view_url( $id ) ),
					)
				)
			);
			exit;
		}
		if ( ! kofc_docs_can_read() ) {
			wp_die( 'This document is for brothers of Council 8600.', 'Members only', array( 'response' => 403 ) );
		}
		$path = kofc_docs_path( $doc );
		if ( ! $path || ! is_readable( $path ) ) {
			wp_die( 'The file for this document is missing. Please tell an officer.', 'File missing', array( 'response' => 404 ) );
		}
		$name = sanitize_file_name( $doc->post_title );
		$name = ( '' !== $name ? $name : 'document' ) . '.pdf';
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Cache-Control: private, no-store, max-age=0' );
		header( 'Content-Type: application/pdf' );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: ' . ( $download ? 'attachment' : 'inline' ) . '; filename="' . $name . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	},
	20
);

/* ───────── The Documents page: [council_documents] ───────── */

add_shortcode(
	'council_documents',
	function () {
		if ( ! kofc_docs_can_read() ) {
			return ''; // The page itself is members-only; this is only a safety net.
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$id = isset( $_GET['doc'] ) ? absint( $_GET['doc'] ) : 0;
		if ( $id ) {
			$doc = get_post( $id );
			if ( $doc && 'council_document' === $doc->post_type ) {
				return kofc_docs_viewer( $doc );
			}
		}
		$docs = kofc_docs_all();
		$html = ( $id ? '<div class="members-notice"><p><strong>That document is no longer on the site.</strong> Here is everything that is.</p></div>' : '' );
		if ( kofc_docs_can_manage() ) {
			$html .= '<p class="docs-add"><a href="' . esc_url( admin_url( 'admin.php?page=kofc-documents' ) ) . '">Add or remove documents</a> (officers)</p>';
		}
		if ( ! $docs ) {
			return $html . '<p class="docs-empty">No documents yet.</p>';
		}
		$by_type = array();
		foreach ( $docs as $doc ) {
			$by_type[ (string) get_post_meta( $doc->ID, '_kofc_doc_type', true ) ][] = $doc;
		}
		foreach ( kofc_docs_types() as $type => $label ) {
			if ( empty( $by_type[ $type ] ) ) {
				continue;
			}
			$html .= '<h2 class="wp-block-heading">' . esc_html( $label ) . '</h2><div class="rows docs-list">';
			foreach ( $by_type[ $type ] as $doc ) {
				$html .= '<p class="row icon-page"><a href="' . esc_url( kofc_docs_view_url( $doc->ID ) ) . '"><strong>' . esc_html( get_the_title( $doc ) ) . '</strong><span>' . esc_html( kofc_docs_meta_line( $doc ) ) . '</span></a></p>';
			}
			$html .= '</div>';
		}
		return $html;
	}
);

/* One document: Download and "Open in a new tab", then the pages, drawn by doc-viewer.js. */
function kofc_docs_viewer( $doc ) {
	wp_enqueue_script_module( 'kofc8600-doc-viewer', plugins_url( 'assets/doc-viewer.js', __FILE__ ), array(), '1.0.0' );
	$types = kofc_docs_types();
	$type  = (string) get_post_meta( $doc->ID, '_kofc_doc_type', true );
	return '<div class="doc-viewer">'
		. '<p class="doc-back"><a href="' . esc_url( kofc_docs_page_url() ) . '">&larr; All documents</a></p>'
		. '<h2 class="wp-block-heading doc-title">' . esc_html( get_the_title( $doc ) ) . '</h2>'
		. '<p class="doc-meta">' . esc_html( ( isset( $types[ $type ] ) ? $types[ $type ] . ' · ' : '' ) . kofc_docs_meta_line( $doc ) ) . '</p>'
		. '<div class="wp-block-buttons doc-actions">'
		. '<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( kofc_docs_file_url( $doc->ID, true ) ) . '">Download</a></div>'
		. '<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . esc_url( kofc_docs_file_url( $doc->ID ) ) . '" target="_blank" rel="noopener">Open in a new tab</a></div>'
		. '</div>'
		. '<p class="fine">For brothers of Council 8600 only. Please don\'t forward it outside the Council.</p>'
		. '<div class="doc-pages" data-src="' . esc_url( kofc_docs_file_url( $doc->ID ) ) . '" aria-busy="true" aria-label="' . esc_attr( 'Pages of ' . get_the_title( $doc ) ) . '"><p class="doc-loading">Loading the document&hellip;</p></div>'
		. '<p class="doc-failed members-notice">This document can\'t be shown here. Use <strong>Download</strong> or <strong>Open in a new tab</strong> above.</p>'
		. '</div>';
}

/* ───────── The officers' screen: Members' documents ───────── */

add_action(
	'admin_menu',
	function () {
		add_menu_page( 'Members\' documents', 'Members\' documents', 'edit_others_pages', 'kofc-documents', 'kofc_docs_screen', 'dashicons-media-document', 73 );
	}
);

function kofc_docs_notice( $type, $text, $old = array() ) {
	set_transient( 'kofc_docs_notice_' . get_current_user_id(), array( $type, $text, $old ), 120 );
}

function kofc_docs_screen() {
	if ( ! kofc_docs_can_manage() ) {
		return;
	}
	$notice = get_transient( 'kofc_docs_notice_' . get_current_user_id() );
	delete_transient( 'kofc_docs_notice_' . get_current_user_id() );
	$old = ( $notice && ! empty( $notice[2] ) ) ? $notice[2] : array();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- choosing which document to show in the form.
	$edit = isset( $_GET['edit'] ) ? get_post( absint( $_GET['edit'] ) ) : null;
	if ( $edit && 'council_document' !== $edit->post_type ) {
		$edit = null;
	}
	$title = isset( $old['title'] ) ? $old['title'] : ( $edit ? $edit->post_title : '' );
	$type  = isset( $old['type'] ) ? $old['type'] : ( $edit ? (string) get_post_meta( $edit->ID, '_kofc_doc_type', true ) : 'minutes' );
	$date  = isset( $old['date'] ) ? $old['date'] : ( $edit ? get_the_date( 'Y-m-d', $edit ) : current_time( 'Y-m-d' ) );

	echo '<div class="wrap"><h1>Members\' documents</h1>';
	echo '<p style="max-width:44rem">PDFs for brothers only, such as minutes, budgets and by-laws. They appear on the members-only <a href="' . esc_url( kofc_docs_page_url() ) . '">Documents</a> page. Unlike files in the Media Library, nobody can open them without signing in as a brother or officer, even with the file\'s link.</p>';
	if ( $notice ) {
		printf( '<div class="notice notice-%s"><p>%s</p></div>', 'error' === $notice[0] ? 'error' : 'success', esc_html( $notice[1] ) );
	}
	$protected = kofc_docs_protection();
	if ( 'no' === $protected ) {
		echo '<div class="notice notice-warning"><p><strong>This web host lets anyone who has a file\'s exact address open it.</strong> Each file has a long random name that nobody can guess, and the site never shows it, so they are still hard to reach. Tell the site\'s administrator.</p></div>';
	} elseif ( 'yes' === $protected ) {
		echo '<p class="description"><span class="dashicons dashicons-yes" style="color:#008a20"></span> Checked: the web server refuses direct links to these files.</p>';
	}

	echo '<h2>' . ( $edit ? 'Change &ldquo;' . esc_html( $edit->post_title ) . '&rdquo;' : 'Add a document' ) . '</h2>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
	echo '<input type="hidden" name="action" value="kofc_doc_save">';
	wp_nonce_field( 'kofc_doc_save' );
	if ( $edit ) {
		echo '<input type="hidden" name="doc_id" value="' . (int) $edit->ID . '">';
	}
	echo '<table class="form-table" role="presentation"><tbody>';
	echo '<tr><th scope="row"><label for="doc-title">Title</label></th><td><input id="doc-title" name="doc_title" type="text" class="regular-text" required value="' . esc_attr( $title ) . '"><p class="description">For example: Minutes, October 21, 2026</p></td></tr>';
	echo '<tr><th scope="row"><label for="doc-type">Kind</label></th><td><select id="doc-type" name="doc_type">';
	foreach ( kofc_docs_types() as $key => $label ) {
		printf( '<option value="%s"%s>%s</option>', esc_attr( $key ), selected( $type, $key, false ), esc_html( $label ) );
	}
	echo '</select></td></tr>';
	echo '<tr><th scope="row"><label for="doc-date">Date</label></th><td><input id="doc-date" name="doc_date" type="date" value="' . esc_attr( $date ) . '"><p class="description">The meeting or document date. Newest shows first.</p></td></tr>';
	echo '<tr><th scope="row"><label for="doc-file">PDF file</label></th><td><input id="doc-file" name="doc_file" type="file" accept="application/pdf,.pdf"' . ( $edit ? '' : ' required' ) . '>'
		. '<p class="description">' . esc_html( ( $edit ? 'Choose a file only to replace the current one. ' : '' ) . 'PDF only, up to ' . size_format( kofc_docs_max_bytes() ) . '. In Word or Excel, use File, then Save As, and choose PDF.' ) . '</p></td></tr>';
	echo '</tbody></table>';
	submit_button( $edit ? 'Save changes' : 'Add document', 'primary', 'submit', false );
	if ( $edit ) {
		echo ' <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kofc-documents' ) ) . '">Cancel</a>';
	}
	echo '</form>';

	$docs = kofc_docs_all();
	echo '<h2 style="margin-top:2em">On the Documents page (' . count( $docs ) . ')</h2>';
	if ( ! $docs ) {
		echo '<p>None yet.</p></div>';
		return;
	}
	$types = kofc_docs_types();
	echo '<table class="widefat striped"><thead><tr><th>Title</th><th>Kind</th><th>Date</th><th>Size</th><th></th></tr></thead><tbody>';
	foreach ( $docs as $doc ) {
		$kind = (string) get_post_meta( $doc->ID, '_kofc_doc_type', true );
		$size = (int) get_post_meta( $doc->ID, '_kofc_doc_size', true );
		echo '<tr><td><strong><a href="' . esc_url( kofc_docs_view_url( $doc->ID ) ) . '">' . esc_html( $doc->post_title ) . '</a></strong></td>'
			. '<td>' . esc_html( isset( $types[ $kind ] ) ? $types[ $kind ] : '' ) . '</td>'
			. '<td>' . esc_html( get_the_date( 'M j, Y', $doc ) ) . '</td>'
			. '<td>' . esc_html( $size ? size_format( $size ) : '' ) . '</td>'
			. '<td><a class="button" href="' . esc_url( admin_url( 'admin.php?page=kofc-documents&edit=' . $doc->ID ) ) . '">Change</a> '
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline" onsubmit="return confirm(' . esc_attr( wp_json_encode( 'Delete "' . $doc->post_title . '"? Brothers will no longer see it.' ) ) . ')">'
			. '<input type="hidden" name="action" value="kofc_doc_delete"><input type="hidden" name="doc_id" value="' . (int) $doc->ID . '">'
			. wp_nonce_field( 'kofc_doc_delete_' . $doc->ID, '_wpnonce', true, false )
			. '<button type="submit" class="button button-link-delete">Delete</button></form></td></tr>';
	}
	echo '</tbody></table></div>';
}

add_action(
	'admin_post_kofc_doc_save',
	function () {
		if ( ! kofc_docs_can_manage() ) {
			wp_die( 'Sorry, you are not allowed to do that.', 403 );
		}
		check_admin_referer( 'kofc_doc_save' );
		$back  = admin_url( 'admin.php?page=kofc-documents' );
		$id    = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		$title = isset( $_POST['doc_title'] ) && is_string( $_POST['doc_title'] ) ? sanitize_text_field( wp_unslash( $_POST['doc_title'] ) ) : '';
		$type  = isset( $_POST['doc_type'] ) && is_string( $_POST['doc_type'] ) ? sanitize_key( $_POST['doc_type'] ) : 'other';
		$date  = isset( $_POST['doc_date'] ) && is_string( $_POST['doc_date'] ) ? sanitize_text_field( wp_unslash( $_POST['doc_date'] ) ) : '';
		$file  = isset( $_FILES['doc_file'] ) ? $_FILES['doc_file'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- checked in kofc_docs_check_upload().
		$has   = is_array( $file ) && isset( $file['error'] ) && UPLOAD_ERR_NO_FILE !== (int) $file['error'];
		$old   = compact( 'title', 'type', 'date' );
		if ( $id ) {
			$doc = get_post( $id );
			if ( ! $doc || 'council_document' !== $doc->post_type ) {
				kofc_docs_notice( 'error', 'That document is no longer on the site.' );
				wp_safe_redirect( $back );
				exit;
			}
			$back = add_query_arg( 'edit', $id, $back );
		}
		$error = '' === $title ? 'Give the document a title.' : ( ! $id && ! $has ? 'Choose a PDF to upload.' : '' );
		if ( ! $error && $has ) {
			$error = kofc_docs_check_upload( $file );
		}
		$saved = $error ? null : kofc_docs_save( $id, $title, $type, $date, $has ? $file['tmp_name'] : '', true );
		if ( is_wp_error( $saved ) ) {
			$error = $saved->get_error_message();
		}
		if ( $error ) {
			kofc_docs_notice( 'error', $error, $old );
			wp_safe_redirect( $back );
			exit;
		}
		kofc_docs_notice( 'success', $id ? "Saved \"$title\"." : "Added \"$title\". Brothers can now open it on the Documents page." );
		wp_safe_redirect( admin_url( 'admin.php?page=kofc-documents' ) );
		exit;
	}
);

add_action(
	'admin_post_kofc_doc_delete',
	function () {
		$id = isset( $_POST['doc_id'] ) ? absint( $_POST['doc_id'] ) : 0;
		if ( ! kofc_docs_can_manage() ) {
			wp_die( 'Sorry, you are not allowed to do that.', 403 );
		}
		check_admin_referer( 'kofc_doc_delete_' . $id );
		$doc = get_post( $id );
		if ( $doc && 'council_document' === $doc->post_type ) {
			wp_delete_post( $id, true );
			kofc_docs_notice( 'success', "Deleted \"{$doc->post_title}\"." );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=kofc-documents' ) );
		exit;
	}
);
