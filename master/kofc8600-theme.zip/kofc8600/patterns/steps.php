<?php
/**
 * Title: Numbered steps
 * Slug: kofc8600/steps
 * Categories: kofc8600
 *
 * @package kofc8600
 */
?>
<!-- wp:list {"ordered":true,"className":"is-style-steps"} -->
<ol class="wp-block-list is-style-steps"><!-- wp:list-item -->
<li><strong>First step</strong>What happens, in one sentence.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Second step</strong>What happens next.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->
