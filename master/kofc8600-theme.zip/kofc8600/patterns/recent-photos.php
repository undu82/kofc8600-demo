<?php
/**
 * Title: Recent photos
 * Slug: kofc8600/recent-photos
 * Categories: kofc8600
 * Description: Three photos for the foot of the home page, with a link to all Council photos. Swap the photos; the layout stays.
 *
 * @package kofc8600
 */

$kofc_photo = esc_url( get_theme_file_uri( 'assets/images/photo-placeholder.png' ) );
?>
<!-- wp:group {"className":"recent-photos","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group recent-photos"><!-- wp:heading -->
<h2 class="wp-block-heading">Recent photos</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"mosaic","layout":{"type":"default"}} -->
<div class="wp-block-group mosaic"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"more-link"} -->
<p class="more-link"><a href="<?php echo esc_url( home_url( '/more/photos/' ) ); ?>">See all photos</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
