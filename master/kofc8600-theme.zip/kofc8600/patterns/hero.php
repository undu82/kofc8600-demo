<?php
/**
 * Title: Welcome banner
 * Slug: kofc8600/hero
 * Categories: kofc8600
 * Description: The home page banner: Council name, welcome line, two buttons and three photos. Change the words, links and photos; the layout stays.
 *
 * @package kofc8600
 */

$kofc_url   = function ( $path ) {
	return esc_url( home_url( $path ) );
};
$kofc_photo = esc_url( get_theme_file_uri( 'assets/images/photo-placeholder.png' ) );
?>
<!-- wp:group {"align":"full","className":"brand-welcome","templateLock":"contentOnly","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull brand-welcome"><!-- wp:group {"className":"hero-grid","layout":{"type":"default"}} -->
<div class="wp-block-group hero-grid"><!-- wp:group {"className":"brand-text","layout":{"type":"default"}} -->
<div class="wp-block-group brand-text"><!-- wp:paragraph {"className":"principles"} -->
<p class="principles">CHARITY · UNITY · FRATERNITY · PATRIOTISM</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Faith in action. Brothers in service.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"brand-name"} -->
<p class="brand-name">Knights of Columbus · St. Mary of Sorrows Council 8600</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-gold"} -->
<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo $kofc_url( '/get-involved/programs/' ); ?>">Our programs</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo $kofc_url( '/get-involved/join/' ); ?>">Join the Knights</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"mosaic","layout":{"type":"default"}} -->
<div class="wp-block-group mosaic"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo $kofc_photo; ?>" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
