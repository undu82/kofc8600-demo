<?php
/**
 * Title: Welcome banner
 * Slug: kofc8600/hero
 * Categories: kofc8600
 * Description: The short home page banner: the four principles, the welcome line and a link to the programs. Change the words and the link; the layout stays. The photos are in the Recent photos pattern at the foot of the page.
 *
 * @package kofc8600
 */

?>
<!-- wp:group {"align":"full","className":"brand-welcome","templateLock":"contentOnly","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull brand-welcome"><!-- wp:group {"className":"brand-text","layout":{"type":"default"}} -->
<div class="wp-block-group brand-text"><!-- wp:paragraph {"className":"principles"} -->
<p class="principles">CHARITY&nbsp;· UNITY&nbsp;· FRATERNITY&nbsp;· PATRIOTISM</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Faith in action. Brothers in service.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-link"} -->
<p class="hero-link"><a href="<?php echo esc_url( home_url( '/get-involved/programs/' ) ); ?>">See our programs</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
