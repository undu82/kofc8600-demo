<?php
/**
 * Title: Site header
 * Slug: kofc8600/header
 * Categories: header
 * Inserter: no
 *
 * The section menu is the "Sections" navigation menu when it exists
 * (Appearance > Editor > Navigation), so officers can rename or reorder tabs.
 *
 * @package kofc8600
 */

$kofc_nav  = kofc_sections_menu();
$kofc_logo = esc_url( get_theme_file_uri( 'assets/images/kofc_r_hz_rgb_rev.png' ) );
$kofc_home = esc_url( home_url( '/' ) );
?>
<!-- wp:html -->
<p class="proto-note">Design prototype, not the official Council 8600 website. Sample content. Real site: <a href="https://www.kofc8600.org">kofc8600.org</a></p>
<!-- /wp:html -->

<!-- wp:html -->
<div class="brandbar"><div class="brandbar-inner">
<a class="brand" href="<?php echo $kofc_home; ?>"><img src="<?php echo $kofc_logo; ?>" width="1160" height="540" alt="Knights of Columbus"><span class="brand-title"><b>St. Mary of Sorrows</b><span>Council 8600</span></span></a>
<?php echo ( is_search() || is_404() ) ? '' : kofc_search_form(); // The search and "Page not found" pages have their own, larger box. ?>
<div class="textsize" role="group" aria-label="Text size"><span class="lbl">Text size</span><button type="button" data-zoom="1" aria-pressed="true" aria-label="Normal text">A</button><button type="button" data-zoom="1.16" aria-pressed="false" aria-label="Larger text">A</button><button type="button" data-zoom="1.34" aria-pressed="false" aria-label="Largest text">A</button></div>
<a class="join-btn" href="<?php echo esc_url( home_url( '/get-involved/join/' ) ); ?>">Join</a>
</div></div>
<!-- /wp:html -->

<?php if ( $kofc_nav ) : ?>
<!-- wp:navigation {"ref":<?php echo (int) $kofc_nav->ID; ?>,"overlayMenu":"never","className":"tabbar","layout":{"type":"flex","justifyContent":"center","flexWrap":"nowrap"}} /-->
<?php else : ?>
<!-- wp:navigation {"overlayMenu":"never","className":"tabbar","layout":{"type":"flex","justifyContent":"center","flexWrap":"nowrap"}} -->
<!-- wp:navigation-link {"label":"Home","url":"<?php echo $kofc_home; ?>","kind":"custom","className":"tab-home"} /-->
<!-- /wp:navigation -->
<?php endif; ?>
