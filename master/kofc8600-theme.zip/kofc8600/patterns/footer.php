<?php
/**
 * Title: Site footer
 * Slug: kofc8600/footer
 * Categories: footer
 * Inserter: no
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:html -->
<div class="site-footer"><div class="site-footer-inner">
<div><b>Council 8600</b><p>St. Mary of Sorrows<br>Fairfax Station, Virginia</p><a href="tel:+15715550100">(571) 555-0100</a></div>
<div><b>Quick links</b><a href="<?php echo $kofc_url( '/give/pay/' ); ?>">Pay dues</a><a href="<?php echo $kofc_url( '/get-involved/join/' ); ?>">Join the Knights</a><a href="<?php echo $kofc_url( '/get-involved/prayer/' ); ?>">Prayer requests</a><a href="<?php echo $kofc_url( '/more/officers/' ); ?>">Officers and contacts</a></div>
<div><b>Elsewhere</b><a href="https://www.kofc.org">Knights of Columbus</a><a href="https://www.vakofc.org">Virginia State Council</a><a href="https://www.kovarva.org">KOVAR</a></div>
<div><b>About this site</b><p>Design prototype for the Council's web redesign team. Not the official Council 8600 website. Names, dates and phone numbers are placeholders.</p><a href="https://www.kofc8600.org">kofc8600.org</a></div>
</div></div>
<!-- /wp:html -->
