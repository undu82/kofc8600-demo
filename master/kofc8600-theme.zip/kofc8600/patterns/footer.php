<?php
/**
 * Title: Site footer
 * Slug: kofc8600/footer
 * Categories: footer
 * Inserter: no
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:html -->
<div class="site-footer"><div class="site-footer-inner">
<div><b>Council 8600</b><p>St. Mary of Sorrows<br>Fairfax Station, Virginia</p><a href="<?php echo $kofc_url( '/more/contact/' ); ?>">Contact us</a></div>
<div><b>Quick links</b><a href="<?php echo $kofc_url( '/give/pay/' ); ?>">Pay dues</a><a href="<?php echo $kofc_url( '/get-involved/join/' ); ?>">Join the Knights</a><a href="<?php echo $kofc_url( '/get-involved/prayer/' ); ?>">Prayer requests</a><a href="<?php echo $kofc_url( '/more/officers/' ); ?>">Officers and contacts</a></div>
<div><b>Elsewhere</b><a href="https://www.kofc.org">Knights of Columbus</a><a href="https://vakofc.org">Virginia State Council</a><a href="https://www.kovarva.org">KOVAR</a>
<b>Follow us</b><a href="https://www.facebook.com/groups/KofC8600">Facebook</a><a href="https://www.instagram.com/kofc8600/">Instagram</a><a href="https://x.com/KofC8600">X (Twitter)</a></div>
<div><b>Our parish</b><a href="https://www.stmaryofsorrows.org">St. Mary of Sorrows Catholic Church</a><a href="<?php echo $kofc_url( '/more/find-us/' ); ?>">Find us</a></div>
</div>
<p class="site-footer-legal">&copy; 2003&ndash;<?php echo esc_html( wp_date( 'Y' ) ); ?> Knights of Columbus&reg; Council 8600. All rights reserved. <a href="https://www.kofc.org/policies/privacy-notice/">Privacy policy</a></p>
</div>
<!-- /wp:html -->
