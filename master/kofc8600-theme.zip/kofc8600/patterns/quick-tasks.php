<?php
/**
 * Title: Quick tasks
 * Slug: kofc8600/quick-tasks
 * Categories: kofc8600
 * Description: Four large task buttons. Change the words or the link; the layout stays.
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"tiles","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group tiles"><!-- wp:paragraph {"className":"tile icon-calendar"} -->
<p class="tile icon-calendar"><a href="<?php echo $kofc_url( '/events/' ); ?>">What's on this week</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile is-gold icon-card"} -->
<p class="tile is-gold icon-card"><a href="<?php echo $kofc_url( '/give/pay/' ); ?>">Pay my dues</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile icon-hands"} -->
<p class="tile icon-hands"><a href="<?php echo $kofc_url( '/get-involved/' ); ?>">Volunteer / Signup Genius</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile icon-cross"} -->
<p class="tile icon-cross"><a href="<?php echo $kofc_url( '/get-involved/prayer/' ); ?>">Prayer request</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
