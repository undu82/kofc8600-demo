<?php
/**
 * Title: Quick tasks
 * Slug: kofc8600/quick-tasks
 * Categories: kofc8600
 * Description: Four large task buttons. Change the words or the link; the layout stays. Volunteer sign-ups go straight to the Council's SignUpGenius page, one click from home.
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"tiles","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group tiles"><!-- wp:paragraph {"className":"tile icon-calendar"} -->
<p class="tile icon-calendar"><a href="<?php echo $kofc_url( '/events/' ); ?>">What's on this week</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile is-gold icon-card"} -->
<p class="tile is-gold icon-card"><a href="<?php echo $kofc_url( '/give/pay/' ); ?>">Pay my dues</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile icon-hands"} -->
<p class="tile icon-hands"><a href="<?php echo esc_url( 'https://www.signupgenius.com/index.cfm?go=c.SignUpSearch&eid=0BC7C0D9FFC9F967&cs=09B1BAD88FCD8B6C7B79640E5BCF9BC9' ); ?>">Volunteer sign&#8209;ups</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tile icon-cross"} -->
<p class="tile icon-cross"><a href="<?php echo $kofc_url( '/get-involved/prayer/#ask' ); ?>">Prayer request</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
