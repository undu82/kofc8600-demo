<?php
/**
 * Title: Link rows
 * Slug: kofc8600/link-rows
 * Categories: kofc8600
 * Description: A list of large, tappable links, each with a short description.
 *
 * @package kofc8600
 */
?>
<!-- wp:group {"className":"rows","layout":{"type":"default"}} -->
<div class="wp-block-group rows"><!-- wp:paragraph {"className":"row"} -->
<p class="row"><a href="#"><strong>First link</strong><span>One line about where it goes</span></a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"row"} -->
<p class="row"><a href="#"><strong>Second link</strong><span>One line about where it goes</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
