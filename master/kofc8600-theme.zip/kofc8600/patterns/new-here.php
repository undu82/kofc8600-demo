<?php
/**
 * Title: New here (join card and contact strips)
 * Slug: kofc8600/new-here
 * Categories: kofc8600
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:heading -->
<h2 class="wp-block-heading">New here?</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"is-style-card-gold join-card","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card-gold join-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">All Catholic men 18 and older are welcome!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Join online at kofc.org. Your first year is free.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-gold"} -->
<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo $kofc_url( '/get-involved/join/' ); ?>">Ready to join now</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo $kofc_url( '/get-involved/join/learn-more/' ); ?>">Need more information</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"callstrip icon-mail"} -->
<p class="callstrip icon-mail"><a href="<?php echo $kofc_url( '/more/contact/' ); ?>"><strong>Contact us</strong><span>Send the Council a message</span></a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"callstrip icon-pin"} -->
<p class="callstrip icon-pin"><a href="<?php echo $kofc_url( '/more/find-us/' ); ?>"><strong>Find us</strong><span>St. Mary of Sorrows · directions and parking</span></a></p>
<!-- /wp:paragraph -->
