<?php
/**
 * Title: New here (join card and contact strips)
 * Slug: kofc8600/new-here
 * Categories: kofc8600
 *
 * @package kofc8600
 */

$kofc_url = function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:heading -->
<h2 class="wp-block-heading">New here?</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"is-style-card-gold","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card-gold"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Thinking about joining?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Catholic men 18 and older are welcome. It takes about ten minutes to start, and a member of the Council will call you.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-gold"} -->
<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo $kofc_url( '/get-involved/join/' ); ?>">How to join</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"callstrip icon-mail"} -->
<p class="callstrip icon-mail"><a href="<?php echo $kofc_url( '/more/contact/' ); ?>"><strong>Contact us</strong><span>Send the Council a message</span></a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"callstrip icon-pin"} -->
<p class="callstrip icon-pin"><a href="<?php echo $kofc_url( '/more/find-us/' ); ?>"><strong>Find us</strong><span>St. Mary of Sorrows · directions and parking</span></a></p>
<!-- /wp:paragraph -->
