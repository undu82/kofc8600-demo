<?php
/**
 * Title: Coming up (events list)
 * Slug: kofc8600/coming-up
 * Categories: kofc8600
 * Description: The next three events from Events, soonest first. Add events under Events in the dashboard; past events drop off on their own.
 *
 * @package kofc8600
 */
?>
<!-- wp:heading -->
<h2 class="wp-block-heading">Coming up</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[council_events count="3"]
<!-- /wp:shortcode -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/events/' ) ); ?>">See the full calendar</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
