<?php
/**
 * Title: Knight or Family of the Month
 * Slug: kofc8600/knight-of-the-month
 * Categories: kofc8600
 * Description: Photo, month, name and a short write-up. Click the photo and choose Replace to change it.
 *
 * @package kofc8600
 */

$kofc_photo = esc_url( get_theme_file_uri( 'assets/images/photo-placeholder.png' ) );
?>
<!-- wp:group {"className":"kotm","templateLock":"contentOnly","layout":{"type":"default"}} -->
<div class="wp-block-group kotm"><!-- wp:heading -->
<h2 class="wp-block-heading">Knight of the Month</h2>
<!-- /wp:heading -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"220px"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:220px"><!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo $kofc_photo; ?>" alt="Photo of the Knight of the Month"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"kotm-month"} -->
<p class="kotm-month">Month and year</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Name of the Knight</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Two or three sentences on why he was chosen.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
