<?php
/**
 * Title: Search results
 * Slug: kofc8600/search-results
 * Inserter: no
 *
 * Used by templates/search.html. Pages show where they sit on the site,
 * events show their date as in the events list, and each result quotes the
 * passage that matched. Matching and ranking are in inc/search.php.
 *
 * @package kofc8600
 */

global $wp_query;
$kofc_words   = get_search_query( false );
$kofc_terms   = (array) get_query_var( 'kofc_terms' );
$kofc_total   = (int) $wp_query->found_posts;
$kofc_today   = current_time( 'Y-m-d' );
$kofc_front   = (int) get_option( 'page_on_front' );
$kofc_has_evt = function_exists( 'kofc_event_line' );
?>
<!-- wp:group {"align":"full","className":"page-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull page-band"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Search</h1>
<!-- /wp:heading -->

<!-- wp:html -->
<?php echo kofc_search_form( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in kofc_search_form(). ?>
<!-- /wp:html --></div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="search-results">
<?php if ( $kofc_total ) : ?>
<p class="search-count">
	<?php
	if ( get_query_var( 'kofc_partial' ) ) {
		echo 'No page has every word you typed, so these have some of them.';
	} else {
		printf(
			'%1$s for <strong>“%2$s”</strong>',
			esc_html( sprintf( 1 === $kofc_total ? '%s result' : '%s results', number_format_i18n( $kofc_total ) ) ),
			esc_html( $kofc_words )
		);
	}
	?>
</p>
<ol class="results">
	<?php
	foreach ( $wp_query->posts as $kofc_post ) :
		$kofc_date = 'event' === $kofc_post->post_type ? get_post_meta( $kofc_post->ID, '_event_date', true ) : '';
		$kofc_meta = '';
		if ( $kofc_date ) {
			$kofc_stamp  = strtotime( $kofc_date . ' 12:00' );
			$kofc_kicker = $kofc_date < $kofc_today ? 'Past event' : 'Event';
			$kofc_meta   = $kofc_has_evt ? implode( ' · ', kofc_event_line( $kofc_post->ID, true ) ) : wp_date( 'l, F j', $kofc_stamp );
		} elseif ( 'page' === $kofc_post->post_type && $kofc_post->post_parent ) {
			$kofc_kicker = implode( ' › ', array_map( 'get_the_title', array_reverse( get_post_ancestors( $kofc_post ) ) ) );
		} elseif ( 'page' === $kofc_post->post_type ) {
			$kofc_kicker = $kofc_post->ID === $kofc_front ? 'Home page' : 'Page';
		} else {
			$kofc_kicker = get_post_type_object( $kofc_post->post_type )->labels->singular_name;
		}
		$kofc_snippet = kofc_search_snippet( $kofc_post, $kofc_terms, $kofc_date ? 140 : 180 );
		?>
	<li class="result">
		<?php if ( $kofc_date ) : ?>
		<span class="datechip<?php echo $kofc_date < $kofc_today ? ' is-past' : ''; ?>" aria-hidden="true"><span class="m"><?php echo esc_html( wp_date( 'M', $kofc_stamp ) ); ?></span><span class="d"><?php echo esc_html( wp_date( 'j', $kofc_stamp ) ); ?></span></span>
		<?php else : ?>
		<span class="result-icon" aria-hidden="true"></span>
		<?php endif; ?>
		<div class="result-b">
			<p class="result-kicker"><?php echo esc_html( $kofc_kicker ); ?></p>
			<h2 class="result-title"><a href="<?php echo esc_url( get_permalink( $kofc_post ) ); ?>"><?php echo esc_html( get_the_title( $kofc_post ) ); ?></a></h2>
			<?php if ( $kofc_meta ) : ?>
			<p class="result-meta"><?php echo esc_html( $kofc_meta ); ?></p>
			<?php endif; ?>
			<?php if ( $kofc_snippet ) : ?>
			<p class="result-snippet"><?php echo $kofc_snippet; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in kofc_search_snippet(). ?></p>
			<?php endif; ?>
		</div>
	</li>
	<?php endforeach; ?>
</ol>
	<?php
	echo get_the_posts_pagination( // phpcs:ignore WordPress.Security.EscapeOutput -- core markup.
		array(
			'mid_size'           => 1,
			'prev_text'          => 'Previous',
			'next_text'          => 'Next',
			'screen_reader_text' => 'More results',
		)
	);
	?>
<?php else : ?>
<p class="search-count"><strong>Nothing found for “<?php echo esc_html( $kofc_words ); ?>”.</strong></p>
<p>Check the spelling, or try one or two words, such as <em>dues</em>, <em>volunteer</em> or <em>Mass</em>.</p>
	<?php
	$kofc_nav  = get_posts(
		array(
			'post_type'   => 'wp_navigation',
			'name'        => 'council-sections',
			'numberposts' => 1,
			'post_status' => 'publish',
		)
	);
	$kofc_tabs = array();
	foreach ( $kofc_nav ? parse_blocks( $kofc_nav[0]->post_content ) : array() as $kofc_block ) {
		$kofc_id = isset( $kofc_block['attrs']['id'] ) ? (int) $kofc_block['attrs']['id'] : 0;
		if ( 'core/navigation-link' === $kofc_block['blockName'] && ! empty( $kofc_block['attrs']['label'] ) && $kofc_id !== $kofc_front ) {
			$kofc_tabs[] = $kofc_block['attrs'];
		}
	}
	if ( $kofc_tabs ) :
		?>
<h2 class="wp-block-heading">Or start from a section</h2>
<div class="rows">
		<?php foreach ( $kofc_tabs as $kofc_tab ) : ?>
	<p class="row"><a href="<?php echo esc_url( ! empty( $kofc_tab['id'] ) ? get_permalink( $kofc_tab['id'] ) : $kofc_tab['url'] ); ?>"><strong><?php echo esc_html( wp_strip_all_tags( $kofc_tab['label'] ) ); ?></strong></a></p>
		<?php endforeach; ?>
</div>
	<?php endif; ?>
<?php endif; ?>
</div>
<!-- /wp:html -->
