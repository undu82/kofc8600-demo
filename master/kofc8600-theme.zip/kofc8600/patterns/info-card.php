<?php
/**
 * Title: Information card with button
 * Slug: kofc8600/info-card
 * Categories: kofc8600
 *
 * @package kofc8600
 */
?>
<!-- wp:group {"className":"is-style-card-blue","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card-blue"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Card title</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A sentence or two of explanation.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Button text</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
