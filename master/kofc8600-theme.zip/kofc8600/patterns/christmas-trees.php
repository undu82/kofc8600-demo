<?php
/**
 * Title: Christmas tree sales (seasonal)
 * Slug: kofc8600/christmas-trees
 * Categories: kofc8600
 * Description: The home page's Christmas tree card: when and where to buy a tree, and how brothers take a shift. The picture comes with the theme. The card leaves the site by itself after the date in its "show-until" class (Block → Advanced → Additional CSS class). Next year, change the dates, the hours, the schedule link and that date.
 *
 * @package kofc8600
 */

$kofc_schedule = 'https://docs.google.com/spreadsheets/d/1oWNa5ZQhKK7T3H5_CZPN_o41VUndLDnd_te1UTJlOgg/edit?usp=sharing';
$kofc_map      = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( "Old St. Mary's Church, 5612 Ox Rd, Fairfax Station, VA 22039" );
$kofc_email    = antispambot( 'davelopez75@msn.com' );
?>
<!-- wp:group {"className":"spotlight art-trees show-until-2026-12-21","layout":{"type":"default"}} -->
<div class="wp-block-group spotlight art-trees show-until-2026-12-21"><!-- wp:group {"className":"spotlight-body","layout":{"type":"default"}} -->
<div class="wp-block-group spotlight-body"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Nov&nbsp;27 to Dec&nbsp;21 · Old St. Mary's</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Christmas tree sales</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"sub"} -->
<p class="sub">Fresh trees at Old St. Mary's, the historic church. Every tree sold helps fund the Council's charities.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"className":"spotlight-cols"} -->
<div class="wp-block-columns spotlight-cols"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Buy a tree</h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"hours"} -->
<ul class="wp-block-list hours"><!-- wp:list-item -->
<li><strong>Opening day, Nov&nbsp;27</strong> 9 am to 8 pm</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Monday to Friday</strong> 6 to 9 pm</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Saturdays</strong> 9 am to 9 pm</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Sundays</strong> 11 am to 7 pm</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $kofc_map ); ?>">Get directions</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"shift-col"} -->
<div class="wp-block-column shift-col"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Brothers: work a shift</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Shifts marked Vacant still need a brother. To take one, tell our tree scheduler, PGK Dave Lopez: <a href="mailto:<?php echo $kofc_email; ?>"><?php echo $kofc_email; ?></a> or <a href="tel:+17039280121">703-928-0121</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-gold"} -->
<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $kofc_schedule ); ?>">See the shift schedule</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
