<?php
/**
 * Title: Program card
 * Slug: kofc8600/program-card
 * Categories: kofc8600
 * Description: One program: its name and a sentence about it. Place it inside a program grid on the Our programs page.
 *
 * @package kofc8600
 */
?>
<!-- wp:group {"className":"is-style-card program","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card program"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Program name</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>One sentence on what it is and who it helps.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
