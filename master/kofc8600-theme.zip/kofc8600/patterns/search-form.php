<?php
/**
 * Title: Search box
 * Slug: kofc8600/search-form
 * Inserter: no
 *
 * The larger search box, as on the search page. Used on "Page not found".
 *
 * @package kofc8600
 */

?>
<!-- wp:html -->
<?php echo kofc_search_form( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in kofc_search_form(). ?>
<!-- /wp:html -->
