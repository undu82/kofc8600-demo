<?php
/**
 * Site search: the search box, and matching that looks only at what visitors can read.
 *
 * WordPress's own search also reads the page code, so "heart" finds every page
 * with a heart icon, and it needs every word typed, so "how do I pay my dues"
 * finds nothing. Here a page matches on its visible text (events also on their
 * time, place and note), pages with the words in their title come first, and
 * when no page has every word, pages with some of them are shown instead.
 *
 * Each search reads every published page and event. That is quick for a site
 * of a few hundred pages; a much bigger site would want a search index.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Common words that would match nearly every page. WordPress already drops "the", "how", "what" and similar. */
const KOFC_SEARCH_SKIP = array( 'and', 'are', 'but', 'can', 'did', 'does', 'get', 'has', 'have', 'not', 'our', 'their', 'there', 'they', 'you', 'your' );

/**
 * The search box. $where is "header" for the brand bar, or "page" for the
 * search and "Page not found" pages, where it is larger and keeps the words
 * that were searched for.
 */
function kofc_search_form( $where = 'header' ) {
	$header = 'header' === $where;
	return sprintf(
		'<form class="site-search is-%1$s" role="search" aria-label="%2$s" method="get" action="%3$s"><label class="screen-reader-text" for="site-search-%1$s">Search the site</label><input id="site-search-%1$s" type="search" name="s" value="%4$s" placeholder="Search the site" required enterkeyhint="search"><button type="submit">%5$s</button></form>',
		esc_attr( $where ),
		$header ? 'Site search' : 'Search the site',
		esc_url( home_url( '/' ) ),
		$header ? '' : esc_attr( get_search_query( false ) ),
		// In the header the button is a magnifier, so the box fits beside the text-size buttons.
		$header ? '<span class="screen-reader-text">Search</span>' : 'Search'
	);
}

/* Plain text with curly quotes and non-breaking spaces straightened, so "Mary's" finds "Mary’s". */
function kofc_search_clean( $text ) {
	$text = html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$text = str_replace( array( "\u{2018}", "\u{2019}", "\u{201C}", "\u{201D}", "\u{00A0}" ), array( "'", "'", '"', '"', ' ' ), $text );
	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/*
 * The words a visitor reads in a page's content: no markup, block settings,
 * shortcodes or form fields. Separate blocks (paragraphs, headings, the title
 * and subtitle of a link row) are joined with " · " so a quoted passage reads
 * clearly.
 */
function kofc_search_body( $post ) {
	$html = strip_shortcodes( $post->post_content );
	$html = preg_replace( '#<(form|select|script|style)\b.*?</\1>#is', ' ', $html );
	$html = preg_replace( '#</(p|h[1-6]|li|dt|dd|summary|figcaption|td|th|blockquote|div)>|<br\s*/?>|</strong>(?=<span)#i', "\$0\x1F", $html );
	$text = kofc_search_clean( wp_strip_all_tags( str_replace( '<', ' <', $html ) ) );
	$text = preg_replace( '/([.!?:;…])\s*\x1F[\s\x1F]*/u', '$1 ', $text );
	$text = preg_replace( '/\s*\x1F[\s\x1F]*/u', ' · ', $text );
	return preg_replace( '/^[\s·]+|[\s·]+$/u', '', $text );
}

/* Everything a search can match on, in lower case. */
function kofc_search_haystack( $post ) {
	$text = $post->post_title . ' ' . $post->post_excerpt . ' ' . kofc_search_body( $post );
	if ( 'event' === $post->post_type ) {
		foreach ( array( '_event_time', '_event_place', '_event_note' ) as $key ) {
			$text .= ' ' . get_post_meta( $post->ID, $key, true );
		}
	}
	return mb_strtolower( kofc_search_clean( $text ) );
}

/**
 * The words to look for and the words to leave out ("-word"), from what
 * WordPress parsed. Short and common words are dropped unless nothing else
 * is left.
 */
function kofc_search_terms( $query ) {
	$prefix = apply_filters( 'wp_query_search_exclusion_prefix', '-' );
	$want   = array();
	$skip   = array();
	foreach ( (array) $query->get( 'search_terms' ) as $term ) {
		$term = mb_strtolower( kofc_search_clean( $term ) );
		if ( $prefix && str_starts_with( $term, $prefix ) && mb_strlen( $term ) > mb_strlen( $prefix ) ) {
			$skip[] = mb_substr( $term, mb_strlen( $prefix ) );
		} elseif ( '' !== $term ) {
			$want[] = $term;
		}
	}
	$useful = array_filter(
		$want,
		function ( $term ) {
			return mb_strlen( $term ) >= 3 && ! in_array( $term, KOFC_SEARCH_SKIP, true );
		}
	);
	return array( array_values( $useful ? $useful : $want ), $skip );
}

/* Search pages and events (and posts, should the Council ever add news), never media files. */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( ! is_admin() && $query->is_main_query() && $query->is_search() ) {
			$query->set( 'post_type', array( 'page', 'event', 'post' ) );
			$query->set( 'posts_per_page', 10 );
		}
	}
);

/* Replace WordPress's matching with ours: the list of matching pages, best first. */
add_filter(
	'posts_search',
	function ( $search, $query ) {
		global $wpdb;
		if ( '' === $search || is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
			return $search;
		}
		list( $want, $skip ) = kofc_search_terms( $query );

		$found = array();
		$posts = get_posts(
			array(
				'post_type'      => $query->get( 'post_type' ),
				// Members-only (private) pages are searched only for brothers and officers who can read them.
				'post_status'    => current_user_can( 'read_private_pages' ) ? array( 'publish', 'private' ) : 'publish',
				'posts_per_page' => -1,
				// Like WordPress: password-protected pages are searched only for people who are logged in.
				'has_password'   => is_user_logged_in() ? null : false,
			)
		);
		foreach ( $posts as $post ) {
			$text = kofc_search_haystack( $post );
			foreach ( $skip as $term ) {
				if ( false !== mb_strpos( $text, $term ) ) {
					continue 2;
				}
			}
			$title = mb_strtolower( kofc_search_clean( $post->post_title ) );
			$words = 0;
			$score = 0;
			foreach ( $want as $term ) {
				$times = mb_substr_count( $text, $term );
				if ( $times ) {
					++$words;
					$score += min( $times, 5 ) + ( false !== mb_strpos( $title, $term ) ? 10 : 0 );
				}
			}
			if ( $words || ! $want ) {
				$found[ $post->ID ] = array( $words, $score );
			}
		}

		// Keep only pages with every word, unless there are none.
		$every   = array_filter(
			$found,
			function ( $hit ) use ( $want ) {
				return $hit[0] === count( $want );
			}
		);
		$partial = ! $every && $found;
		if ( $every ) {
			$found = $every;
		}
		uasort(
			$found,
			function ( $a, $b ) {
				return array( $b[0], $b[1] ) <=> array( $a[0], $a[1] );
			}
		);

		$ids = array_map( 'intval', array_keys( $found ) );
		$query->set( 'kofc_terms', $want );
		$query->set( 'kofc_partial', $partial );
		$query->set( 'kofc_order', $ids );
		return $ids ? " AND {$wpdb->posts}.ID IN (" . implode( ',', $ids ) . ')' : ' AND 1 = 0';
	},
	10,
	2
);

add_filter(
	'posts_search_orderby',
	function ( $orderby, $query ) {
		global $wpdb;
		$ids = $query->get( 'kofc_order' );
		return $ids ? "FIELD({$wpdb->posts}.ID, " . implode( ',', array_map( 'intval', $ids ) ) . ')' : $orderby;
	},
	10,
	2
);

/* A short passage from the page around the first word that matched, with the matches marked. Returns HTML. */
function kofc_search_snippet( $post, $terms, $length = 180 ) {
	$text = kofc_search_body( $post );
	if ( '' === $text ) {
		return '';
	}
	$lower = mb_strtolower( $text );
	$at    = false;
	foreach ( $terms as $term ) {
		$pos = mb_strpos( $lower, $term );
		if ( false !== $pos && ( false === $at || $pos < $at ) ) {
			$at = $pos;
		}
	}
	$start = ( false === $at || $at < 60 ) ? 0 : $at - 60;
	if ( $start ) {
		$space = mb_strpos( $text, ' ', $start );
		$start = ( false === $space || $space > $at ) ? $start : $space + 1;
	}
	$snippet = preg_replace( '/^[\s·]+/u', '', mb_substr( $text, $start, $length ) );
	if ( $start + $length < mb_strlen( $text ) ) {
		$snippet = preg_replace( '/[\s.,;:·]+$/u', '', preg_replace( '/\s+\S*$/u', '', $snippet ) ) . '…';
	}
	if ( $start ) {
		$snippet = '…' . $snippet;
	}
	if ( ! $terms ) {
		return esc_html( $snippet );
	}
	usort(
		$terms,
		function ( $a, $b ) {
			return mb_strlen( $b ) <=> mb_strlen( $a );
		}
	);
	$pattern = '/(' . implode( '|', array_map( 'preg_quote', $terms, array_fill( 0, count( $terms ), '/' ) ) ) . ')/iu';
	$html    = '';
	foreach ( preg_split( $pattern, $snippet, -1, PREG_SPLIT_DELIM_CAPTURE ) as $i => $piece ) {
		$html .= $i % 2 ? '<mark>' . esc_html( $piece ) . '</mark>' : esc_html( $piece );
	}
	return $html;
}
