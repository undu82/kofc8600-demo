<?php
/**
 * Phone "More" menu. On phones the More tab slides up a sheet showing the More page's
 * content (theme.js opens it), so officers change the menu by editing the More page.
 * Without JavaScript, and on wider screens, the More tab opens the page as usual.
 *
 * @package kofc8600
 */

add_action( 'wp_footer', 'kofc_more_menu' );

function kofc_more_menu() {
	$page = get_page_by_path( 'more' );
	// Only a public page: a members-only (private) or password-protected More page stays behind its lock.
	if ( ! $page || 'publish' !== $page->post_status || '' !== $page->post_password || is_page( $page->ID ) ) {
		return;
	}
	$close = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>';
	printf(
		'<dialog class="sheet" id="more-menu" aria-label="%1$s"><span class="sheet-grab" aria-hidden="true"></span><button type="button" class="sheet-close" aria-label="Close %1$s">%2$s</button><div class="sheet-body">%3$s</div></dialog>',
		esc_attr( get_the_title( $page ) ),
		$close, // Fixed markup above.
		wptexturize( do_blocks( $page->post_content ) ) // Rendered like the page itself, curly quotes included.
	);
}
