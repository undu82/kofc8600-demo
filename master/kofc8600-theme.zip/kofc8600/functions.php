<?php
/**
 * Council 8600 theme setup.
 *
 * Design lives here. Content features (events) live in the Council 8600 Events
 * plugin, so changing the theme later never loses data.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_theme_file_path( 'inc/search.php' );

add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'style.css' );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		$version = wp_get_theme()->get( 'Version' );
		wp_enqueue_style( 'kofc8600', get_stylesheet_uri(), array(), $version );
		wp_enqueue_script(
			'kofc8600',
			get_theme_file_uri( 'assets/js/theme.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer' )
		);
	}
);

/* Apply a saved text size before the page paints, so the page does not jump. */
add_action(
	'wp_head',
	function () {
		echo "<script>try{var s=localStorage.getItem('kofc8600-text-size');if(s)document.documentElement.style.setProperty('--ts',s);}catch(e){}</script>\n";
	},
	1
);

/*
 * Styles a volunteer can pick from the block sidebar. Each one maps to a class
 * in style.css, so they stay on-brand without any colour or size choices.
 */
add_action(
	'init',
	function () {
		$styles = array(
			'core/group'  => array(
				'card'      => __( 'Card', 'kofc8600' ),
				'card-gold' => __( 'Highlight card', 'kofc8600' ),
				'card-blue' => __( 'Information card', 'kofc8600' ),
			),
			'core/button' => array( 'gold' => __( 'Gold', 'kofc8600' ) ),
			'core/list'   => array( 'steps' => __( 'Numbered steps', 'kofc8600' ) ),
		);
		foreach ( $styles as $block => $variations ) {
			foreach ( $variations as $name => $label ) {
				register_block_style( $block, array( 'name' => $name, 'label' => $label ) );
			}
		}

		register_block_pattern_category( 'kofc8600', array( 'label' => __( 'Council 8600', 'kofc8600' ) ) );
	}
);

/*
 * Keep the right section tab highlighted on pages beneath it (for example,
 * Give stays highlighted on "Pay dues or donate") and on single events.
 */
add_filter(
	'render_block_core/navigation-link',
	function ( $html, $block ) {
		$id = isset( $block['attrs']['id'] ) ? (int) $block['attrs']['id'] : 0;
		if ( ! $id || is_admin() ) {
			return $html;
		}
		$is_parent = is_page() && in_array( $id, get_post_ancestors( get_queried_object_id() ), true );
		$events    = get_page_by_path( 'events' );
		$is_events = is_singular( 'event' ) && $events && $events->ID === $id;
		if ( ! $is_parent && ! $is_events ) {
			return $html;
		}
		$tags = new WP_HTML_Tag_Processor( $html );
		if ( $tags->next_tag( 'li' ) ) {
			$tags->add_class( 'current-menu-ancestor' );
		}
		if ( $tags->next_tag( 'a' ) ) {
			$tags->set_attribute( 'aria-current', 'true' );
		}
		return $tags->get_updated_html();
	},
	10,
	2
);

/*
 * Events are not pages, so the breadcrumb trail would skip straight from Home
 * to the event. Put the Events page in between.
 */
add_filter(
	'block_core_breadcrumbs_items',
	function ( $items ) {
		$events = get_page_by_path( 'events' );
		if ( ! is_singular( 'event' ) || ! $events ) {
			return $items;
		}
		array_splice(
			$items,
			count( $items ) - 1,
			0,
			array(
				array(
					'label' => get_the_title( $events ),
					'url'   => get_permalink( $events ),
				),
			)
		);
		return $items;
	}
);

/*
 * WordPress's own sign-in page (used for password resets and sign-in errors)
 * shows the Council emblem and colours instead of the WordPress logo.
 */
add_action(
	'login_enqueue_scripts',
	function () {
		$logo = esc_url( get_theme_file_uri( 'assets/images/kofc_r_hz_rgb_rev.png' ) );
		wp_add_inline_style(
			'login',
			"body.login{background:#f7f7f7;font-size:16px}"
			. "#login h1 a{background:#112866 url($logo) center/170px auto no-repeat;width:100%;height:110px;border-radius:12px;margin-bottom:20px}"
			. '.login form{border-radius:12px;border:0;box-shadow:.5rem .5rem 2.25rem rgba(0,0,0,.1)}'
			. '.login label{font-size:16px}'
			. '.wp-core-ui .button-primary{background:#112866;border-color:#112866;min-height:44px;padding:0 20px;font-size:16px}'
			. '.wp-core-ui .button-primary:hover{background:#0b1c49}'
			. '.login #nav a,.login #backtoblog a{color:#112866;font-size:15px}'
		);
	}
);
add_filter(
	'login_headerurl',
	function () {
		return home_url( '/' );
	}
);
add_filter(
	'login_headertext',
	function () {
		return 'Knights of Columbus Council 8600';
	}
);
