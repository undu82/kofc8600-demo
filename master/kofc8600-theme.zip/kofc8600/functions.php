<?php
/**
 * Council 8600 theme setup.
 *
 * Design lives here. Content features (events) live in the Council 8600 Events
 * plugin, so changing the theme later never loses data.
 *
 * @package kofc8600
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_theme_file_path( 'inc/search.php' );
require_once get_theme_file_path( 'inc/more-menu.php' );

add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'style.css' );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		$version = wp_get_theme()->get( 'Version' );
		wp_enqueue_style( 'kofc8600', get_stylesheet_uri(), array(), $version );
		wp_enqueue_script(
			'kofc8600',
			get_theme_file_uri( 'assets/js/theme.js' ),
			array(),
			$version,
			array( 'strategy' => 'defer' )
		);
	}
);

/* Apply a saved text size before the page paints, so the page does not jump. */
add_action(
	'wp_head',
	function () {
		echo "<script>try{var s=localStorage.getItem('kofc8600-text-size');if(s)document.documentElement.style.setProperty('--ts',s);}catch(e){}</script>\n";
	},
	1
);

/*
 * Show the Order's emblem in the browser tab, on the site, the sign-in page and
 * the dashboard. An icon chosen under Settings > General > Site Icon wins.
 */
function kofc_tab_icon() {
	if ( has_site_icon() ) {
		return; // WordPress prints the chosen icon itself.
	}
	$icon = esc_url( get_theme_file_uri( 'assets/images/kofc_r_emblem_rgb_pos.png' ) );
	echo "<link rel=\"icon\" href=\"$icon\" sizes=\"450x450\" type=\"image/png\">\n";
}
foreach ( array( 'wp_head', 'login_head', 'admin_head' ) as $kofc_hook ) {
	add_action( $kofc_hook, 'kofc_tab_icon' );
}

/*
 * The "Sections" navigation menu: the tab bar, and the sections offered when a
 * search finds nothing. The imported menu's address is council-sections; one
 * made by hand in Appearance > Editor > Navigation and named "Sections" gets
 * sections. Null until one exists.
 */
function kofc_sections_menu() {
	$menus = get_posts(
		array(
			'post_type'     => 'wp_navigation',
			'post_name__in' => array( 'council-sections', 'sections' ),
			'orderby'       => 'post_name__in',
			'numberposts'   => 1,
			'post_status'   => 'publish',
		)
	);
	return $menus ? $menus[0] : null;
}

/*
 * Menu links name their page by number. If the pages are imported again or the
 * site moves, the numbers change, and WordPress hides every link to a page that
 * no longer exists, which empties the tab bar. A link whose page is missing is
 * pointed at the page at its address instead (/events/, /give/; / is the front
 * page): when the menu is drawn, and in the stored menu after an import or when
 * an officer opens the dashboard.
 */
function kofc_nav_link_page_id( $attrs ) {
	$id   = isset( $attrs['id'] ) ? (int) $attrs['id'] : 0;
	$post = $id ? get_post( $id ) : null;
	// After an import the number may belong to something else entirely, so it must still be a page.
	if ( ( $post && 'page' === $post->post_type && 'trash' !== $post->post_status ) || empty( $attrs['url'] ) ) {
		return $id;
	}
	$path = trim( (string) wp_parse_url( $attrs['url'], PHP_URL_PATH ), '/' );
	$page = '' === $path ? get_post( (int) get_option( 'page_on_front' ) ) : get_page_by_path( $path );
	return ( $page && 'trash' !== $page->post_status ) ? (int) $page->ID : $id;
}
add_filter(
	'block_core_navigation_render_inner_blocks',
	function ( $inner_blocks ) {
		foreach ( $inner_blocks as $block ) {
			if ( 'core/navigation-link' !== $block->name || empty( $block->parsed_block['attrs']['id'] ) ) {
				continue;
			}
			$id = kofc_nav_link_page_id( $block->parsed_block['attrs'] );
			if ( (int) $block->parsed_block['attrs']['id'] !== $id ) {
				$block->parsed_block['attrs']['id'] = $id;
				if ( array_key_exists( 'attributes', get_object_vars( $block ) ) ) {
					$block->attributes['id'] = $id; // Already worked out from parsed_block before this filter.
				}
			}
		}
		return $inner_blocks;
	}
);
function kofc_repair_sections_menu() {
	$menu = kofc_sections_menu();
	if ( ! $menu ) {
		return;
	}
	$changed = false;
	$blocks  = parse_blocks( $menu->post_content );
	foreach ( $blocks as $i => $block ) {
		if ( 'core/navigation-link' === $block['blockName'] && ! empty( $block['attrs']['id'] ) ) {
			$id = kofc_nav_link_page_id( $block['attrs'] );
			if ( (int) $block['attrs']['id'] !== $id ) {
				$blocks[ $i ]['attrs']['id'] = $id;
				$changed                     = true;
			}
		}
	}
	if ( $changed ) {
		wp_update_post(
			wp_slash(
				array(
					'ID'           => $menu->ID,
					'post_content' => serialize_blocks( $blocks ),
				)
			)
		);
	}
}
add_action(
	'admin_init',
	function () {
		if ( current_user_can( 'edit_theme_options' ) && ! wp_doing_ajax() ) {
			kofc_repair_sections_menu();
		}
	}
);

/*
 * After importing the Council's pages (Tools > Import > WordPress), show the
 * Home page as the front page, as Settings > Reading would. The front page
 * template shows that page's content, so without this it would be empty.
 */
function kofc_set_front_page( $after_import ) {
	$home  = get_page_by_path( 'home' );
	$front = get_post( (int) get_option( 'page_on_front' ) );
	$lost  = 'page' === get_option( 'show_on_front' ) && ( ! $front || 'publish' !== $front->post_status );
	if ( $home && 'publish' === $home->post_status && ( $lost || ( $after_import && 'posts' === get_option( 'show_on_front' ) ) ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home->ID );
	}
}
add_action(
	'import_end',
	function () {
		kofc_set_front_page( true );
		kofc_point_links_at_imported_files();
		kofc_repair_sections_menu();
		kofc_repair_block_refs();
	}
);

/*
 * Pages place a synced pattern (the join card, "What Council 8600 supports") by its number. If an
 * import gives a pattern a new number, the pages still point at the old one and show nothing. The
 * import file notes each pattern's original number (_kofc_block_key, see tools/export-pages.php), so
 * the pages are re-pointed after an import, and again when an officer opens the dashboard, in case
 * the import ran in pieces. Pages re-imported after deleting the old ones also need the front page
 * set again, which happens at the same times.
 */
function kofc_repair_block_refs() {
	global $wpdb;
	$map = array();
	foreach ( get_posts( array( 'post_type' => 'wp_block', 'post_status' => 'any', 'numberposts' => -1, 'meta_key' => '_kofc_block_key' ) ) as $block ) { // phpcs:ignore WordPress.DB.SlowDBQuery -- a handful of patterns.
		$old = (int) get_post_meta( $block->ID, '_kofc_block_key', true );
		$was = $old ? get_post( $old ) : null;
		// Only when the old number now points at nothing, or at something that isn't a pattern.
		if ( $old && $old !== $block->ID && ( ! $was || 'wp_block' !== $was->post_type ) ) {
			$map[ $old ] = $block->ID;
		}
	}
	$ids = array();
	foreach ( array_keys( $map ) as $old ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- finds the few pages that need a text replacement.
		$ids = array_merge( $ids, $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ('page','wp_block') AND post_content LIKE %s", '%' . $wpdb->esc_like( '<!-- wp:block {"ref":' . $old . '}' ) . '%' ) ) );
	}
	foreach ( array_unique( $ids ) as $post_id ) {
		// One pass per page, so two patterns that swapped numbers can't be re-pointed twice.
		$content = preg_replace_callback(
			'/<!-- wp:block \{"ref":(\d+)\}/',
			function ( $m ) use ( $map ) {
				return isset( $map[ (int) $m[1] ] ) ? '<!-- wp:block {"ref":' . $map[ (int) $m[1] ] . '}' : $m[0];
			},
			get_post_field( 'post_content', $post_id, 'raw' )
		);
		$wpdb->update( $wpdb->posts, array( 'post_content' => $content ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		clean_post_cache( $post_id );
	}
}
add_action(
	'admin_init',
	function () {
		if ( current_user_can( 'edit_theme_options' ) && ! wp_doing_ajax() ) {
			kofc_repair_block_refs();
			kofc_set_front_page( false );
		}
	}
);

/*
 * The import file notes where each photo and PDF was downloaded from
 * (_kofc_source_url, see tools/export-pages.php). Any link still pointing there
 * now points at the copy in the Media Library, so nothing depends on the old
 * address. The WordPress Importer does this itself for photos, but with
 * "Change all imported URLs" ticked it misses PDFs.
 */
function kofc_point_links_at_imported_files() {
	global $wpdb;
	$files = get_posts(
		array(
			'post_type'   => 'attachment',
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
			'meta_key'    => '_kofc_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery -- once, after an import.
		)
	);
	foreach ( $files as $file_id ) {
		$from = (string) get_post_meta( $file_id, '_kofc_source_url', true );
		$to   = (string) wp_get_attachment_url( $file_id );
		if ( '' !== $from && '' !== $to && $from !== $to ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a one-off text replacement across pages, menus and patterns.
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type <> 'revision' AND post_content LIKE %s", '%' . $wpdb->esc_like( $from ) . '%' ) );
			foreach ( $ids as $post_id ) {
				$content = str_replace( $from, $to, get_post_field( 'post_content', $post_id, 'raw' ) );
				$wpdb->update( $wpdb->posts, array( 'post_content' => $content ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				clean_post_cache( $post_id );
			}
		}
		delete_post_meta( $file_id, '_kofc_source_url' );
	}
}

/*
 * Styles a volunteer can pick from the block sidebar. Each one maps to a class
 * in style.css, so they stay on-brand without any colour or size choices.
 */
add_action(
	'init',
	function () {
		$styles = array(
			'core/group'  => array(
				'card'      => __( 'Card', 'kofc8600' ),
				'card-gold' => __( 'Highlight card', 'kofc8600' ),
				'card-blue' => __( 'Information card', 'kofc8600' ),
			),
			'core/button' => array(
					'gold'         => __( 'Gold', 'kofc8600' ),
					'signupgenius' => __( 'SignUpGenius badge', 'kofc8600' ),
				),
			'core/list'   => array( 'steps' => __( 'Numbered steps', 'kofc8600' ) ),
		);
		foreach ( $styles as $block => $variations ) {
			foreach ( $variations as $name => $label ) {
				register_block_style( $block, array( 'name' => $name, 'label' => $label ) );
			}
		}

		register_block_pattern_category( 'kofc8600', array( 'label' => __( 'Council 8600', 'kofc8600' ) ) );
	}
);

/*
 * Keep the right section tab highlighted on pages beneath it (for example,
 * Give stays highlighted on "Pay dues or donate").
 */
add_filter(
	'render_block_core/navigation-link',
	function ( $html, $block ) {
		$id = isset( $block['attrs']['id'] ) ? (int) $block['attrs']['id'] : 0;
		if ( ! $id || is_admin() ) {
			return $html;
		}
		$is_parent = is_page() && in_array( $id, get_post_ancestors( get_queried_object_id() ), true );
		if ( ! $is_parent ) {
			return $html;
		}
		$tags = new WP_HTML_Tag_Processor( $html );
		if ( $tags->next_tag( 'li' ) ) {
			$tags->add_class( 'current-menu-ancestor' );
		}
		if ( $tags->next_tag( 'a' ) ) {
			$tags->set_attribute( 'aria-current', 'true' );
		}
		return $tags->get_updated_html();
	},
	10,
	2
);

/*
 * Seasonal blocks leave the site on their own: a block whose Additional CSS class
 * includes show-until-YYYY-MM-DD is not shown after that day (the site's time
 * zone). It stays in the editor, so next year an editor updates it and the date.
 */
add_filter(
	'render_block',
	function ( $html, $block ) {
		$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
		if ( false === strpos( $class, 'show-until-' ) || ! preg_match( '/\bshow-until-(\d{4}-\d{2}-\d{2})\b/', $class, $m ) ) {
			return $html;
		}
		return wp_date( 'Y-m-d' ) > $m[1] ? '' : $html;
	},
	10,
	2
);

/*
 * WordPress's own sign-in page (used for password resets and sign-in errors)
 * shows the Council emblem and colours instead of the WordPress logo.
 */
add_action(
	'login_enqueue_scripts',
	function () {
		$logo = esc_url( get_theme_file_uri( 'assets/images/kofc_r_hz_rgb_rev.png' ) );
		wp_add_inline_style(
			'login',
			"body.login{background:#f7f7f7;font-size:16px}"
			. "#login h1 a{background:#112866 url($logo) center/170px auto no-repeat;width:100%;height:110px;border-radius:12px;margin-bottom:20px}"
			. '.login form{border-radius:12px;border:0;box-shadow:.5rem .5rem 2.25rem rgba(0,0,0,.1)}'
			. '.login label{font-size:16px}'
			. '.wp-core-ui .button-primary{background:#112866;border-color:#112866;min-height:44px;padding:0 20px;font-size:16px}'
			. '.wp-core-ui .button-primary:hover{background:#0b1c49}'
			. '.login #nav a,.login #backtoblog a{color:#112866;font-size:15px}'
		);
	}
);
add_filter(
	'login_headerurl',
	function () {
		return home_url( '/' );
	}
);
add_filter(
	'login_headertext',
	function () {
		return 'Knights of Columbus Council 8600';
	}
);
