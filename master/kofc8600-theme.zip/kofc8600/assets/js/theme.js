/* Council 8600 theme: text-size control and prototype form handling. No dependencies. */
(function () {
	var KEY = 'kofc8600-text-size';
	var root = document.documentElement;

	function remember(value) {
		try { localStorage.setItem(KEY, value); } catch (e) { /* storage blocked: size still applies for this page */ }
	}
	function recall() {
		try { return localStorage.getItem(KEY); } catch (e) { return null; }
	}
	function apply(value, buttons) {
		root.style.setProperty('--ts', value);
		buttons.forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.zoom === value)); });
	}

	var buttons = Array.prototype.slice.call(document.querySelectorAll('.textsize button[data-zoom]'));
	if (buttons.length) {
		var saved = recall();
		if (saved && buttons.some(function (b) { return b.dataset.zoom === saved; })) { apply(saved, buttons); }
		buttons.forEach(function (b) {
			b.addEventListener('click', function () { apply(b.dataset.zoom, buttons); remember(b.dataset.zoom); });
		});
	}

	/* Prototype forms never send. On the live site these become real forms. */
	document.querySelectorAll('form[data-demo]').forEach(function (form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault();
			var status = form.querySelector('[role="status"]');
			if (status) { status.textContent = 'Prototype only. Nothing was sent.'; }
		});
	});
})();
