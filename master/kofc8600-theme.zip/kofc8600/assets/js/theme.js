/* Council 8600 theme: text-size control and prototype form handling. No dependencies. */
(function () {
	var KEY = 'kofc8600-text-size';
	var root = document.documentElement;

	function remember(value) {
		try { localStorage.setItem(KEY, value); } catch (e) { /* storage blocked: size still applies for this page */ }
	}
	function recall() {
		try { return localStorage.getItem(KEY); } catch (e) { return null; }
	}
	function apply(value, buttons) {
		root.style.setProperty('--ts', value);
		buttons.forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.zoom === value)); });
	}

	var buttons = Array.prototype.slice.call(document.querySelectorAll('.textsize button[data-zoom]'));
	if (buttons.length) {
		var saved = recall();
		if (saved && buttons.some(function (b) { return b.dataset.zoom === saved; })) { apply(saved, buttons); }
		buttons.forEach(function (b) {
			b.addEventListener('click', function () { apply(b.dataset.zoom, buttons); remember(b.dataset.zoom); });
		});
	}

	/* Prototype: WordPress.com's sign-in (which offers Google and Apple) works only on the live site, so the demo explains instead. */
	document.querySelectorAll('[data-demo-provider]').forEach(function (button) {
		button.addEventListener('click', function () {
			var status = button.parentNode.querySelector('[role="status"]');
			if (status) {
				status.textContent = 'Prototype only. On the live site this opens ' + button.dataset.demoProvider + '\u2019s own sign-in page. In this demo, sign in with an email and password below.';
			}
		});
	});

	/*
	 * Google Calendar embeds: on phones, show the list view instead of the month grid, which is
	 * too cramped to read. The address waits in data-src so the calendar loads once, in the right
	 * view (a <noscript> copy covers browsers without JavaScript). A pasted embed with a plain src
	 * is switched too, at the cost of loading twice.
	 */
	var phone = window.matchMedia('(max-width: 600px)').matches;
	document.querySelectorAll('.calendar-embed iframe[data-src], .calendar-embed iframe[src*="calendar.google.com"]').forEach(function (frame) {
		var url = new URL(frame.dataset.src || frame.src);
		if (phone) { url.searchParams.set('mode', 'AGENDA'); }
		if (frame.dataset.src || phone) { frame.src = url.toString(); }
	});

	/*
	 * Phone "More" menu: on phones the More tab slides up a sheet with the More page's links
	 * instead of loading the page. It closes with the ×, a tap outside, Esc, a swipe down or
	 * the phone's Back button. Without JavaScript, or on wider screens, the tab opens the page.
	 */
	var sheet = document.getElementById('more-menu');
	var moreTab = document.querySelector('.tabbar .tab-more a');
	if (sheet && moreTab && typeof sheet.showModal === 'function') {
		var onPhone = window.matchMedia('(max-width: 781px)');
		var calm = window.matchMedia('(prefers-reduced-motion: reduce)');
		var sheetBody = sheet.querySelector('.sheet-body');
		var leaving = false;
		var plainClick = function (e) { return !e.button && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey; };

		moreTab.setAttribute('aria-haspopup', 'dialog');
		moreTab.setAttribute('aria-controls', 'more-menu');
		moreTab.setAttribute('aria-expanded', 'false');

		var openSheet = function () {
			leaving = false;
			sheet.classList.remove('is-closing');
			sheet.style.transform = '';
			sheet.showModal();
			sheetBody.scrollTop = 0;
			moreTab.setAttribute('aria-expanded', 'true');
			history.pushState({ kofcSheet: true }, ''); // so Back closes the menu instead of leaving the page
		};
		var closeSheet = function () {
			if (!sheet.open || sheet.classList.contains('is-closing')) { return; }
			if (calm.matches) { sheet.close(); return; }
			sheet.classList.add('is-closing');
			window.setTimeout(function () { sheet.close(); }, 220);
		};

		moreTab.addEventListener('click', function (e) {
			if (onPhone.matches && plainClick(e)) { e.preventDefault(); openSheet(); }
		});
		sheet.querySelector('.sheet-close').addEventListener('click', closeSheet);
		sheet.addEventListener('cancel', function (e) { e.preventDefault(); closeSheet(); }); // Esc, and Back on Android
		sheet.addEventListener('click', function (e) {
			if (e.target === sheet) { closeSheet(); return; } // the dim area outside the sheet
			var link = e.target.closest('a[href]');
			if (link && !link.target && plainClick(e)) {
				// Swap the menu's history step for the new page, so Back returns to where the menu was opened.
				e.preventDefault();
				leaving = true;
				sheet.close();
				window.location.replace(link.href);
			}
		});
		sheet.addEventListener('close', function () {
			sheet.classList.remove('is-closing', 'is-dragging');
			sheet.style.transform = '';
			moreTab.setAttribute('aria-expanded', 'false');
			if (!leaving && history.state && history.state.kofcSheet) { history.back(); }
		});
		window.addEventListener('popstate', closeSheet);
		onPhone.addEventListener('change', function () { if (!onPhone.matches && sheet.open) { sheet.close(); } });

		// Swipe down to close: from the top strip, or anywhere once the list is scrolled to the top.
		var startY = null, dragY = 0;
		sheet.addEventListener('touchstart', function (e) {
			var fromTop = e.touches[0].clientY - sheet.getBoundingClientRect().top < 28;
			startY = e.touches.length === 1 && (fromTop || sheetBody.scrollTop <= 0) ? e.touches[0].clientY : null;
			dragY = 0;
		}, { passive: true });
		sheet.addEventListener('touchmove', function (e) {
			if (startY === null) { return; }
			var dy = e.touches[0].clientY - startY;
			if (dy <= 0 && !dragY) { startY = null; return; } // moving up: an ordinary scroll
			e.preventDefault();
			dragY = Math.max(0, dy);
			sheet.classList.add('is-dragging');
			sheet.style.transform = 'translateY(' + dragY + 'px)';
		}, { passive: false });
		var endDrag = function () {
			if (startY === null) { return; }
			startY = null;
			sheet.classList.remove('is-dragging');
			if (dragY > 80) { closeSheet(); } else { sheet.style.transform = ''; }
			dragY = 0;
		};
		sheet.addEventListener('touchend', endDrag);
		sheet.addEventListener('touchcancel', endDrag);
	}

	/*
	 * Join page. A Knight can share a personal link, /get-involved/join/?by=1234567: his member number
	 * then shows in the list and goes into the kofc.org application as the Member Referral Number,
	 * so he is credited as the recruiter. Without it, the Membership Director's number is used.
	 */
	var by = new URLSearchParams(window.location.search).get('by');
	if (by && /^\d{1,8}$/.test(by)) {
		document.querySelectorAll('a[href*="displayejoinSpaForm"]').forEach(function (a) {
			var url = new URL(a.href);
			url.searchParams.set('dataForm.proposerMemberNumber', by);
			a.href = url.toString();
		});
		document.querySelectorAll('.code-row.referral').forEach(function (row) {
			var code = row.querySelector('code') || row.appendChild(document.createElement('code'));
			code.textContent = by;
			var hint = row.querySelector('.row-sub');
			if (hint) { hint.textContent = 'The member number of the Knight who invited you.'; }
		});
	}

	/* A Copy button beside each answer to type into the kofc.org application. */
	var codes = document.querySelectorAll('.code-row code');
	if (codes.length && navigator.clipboard) {
		var said = document.createElement('p');
		said.className = 'screen-reader-text';
		said.setAttribute('role', 'status');
		codes[0].closest('.codes').after(said);
		codes.forEach(function (code) {
			var text = code.textContent.trim();
			var button = document.createElement('button');
			var label = document.createElement('span');
			var what = document.createElement('span');
			button.type = 'button';
			button.className = 'copy-btn';
			label.textContent = 'Copy';
			what.className = 'screen-reader-text';
			what.textContent = ' ' + code.parentNode.querySelector('strong').textContent; // "Copy Promo code"
			button.append(label, what);
			button.addEventListener('click', function () {
				navigator.clipboard.writeText(text).then(function () {
					label.textContent = 'Copied';
					said.textContent = 'Copied ' + text;
					window.setTimeout(function () { label.textContent = 'Copy'; }, 2000);
				});
			});
			code.after(button);
		});
	}

	/* Prototype forms never send. On the live site these become real forms. */
	document.querySelectorAll('form[data-demo]').forEach(function (form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault();
			var status = form.querySelector('[role="status"]');
			if (status) { status.textContent = 'Prototype only. Nothing was sent.'; }
		});
	});
})();
