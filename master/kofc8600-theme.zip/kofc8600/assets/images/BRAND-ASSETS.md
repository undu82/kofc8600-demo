# Official Knights of Columbus assets
Downloaded 2026-09-28 from https://www.kofc.org/resources/brand-assets/
Digital RGB package: https://files.kofc.org/download/assets/KofC+Brand+Assets+RGB+EN.zip/21b94718a22611f187ecca8d47fd6be3
PNG files are unmodified. In use: kofc_r_hz_rgb_rev.png (header and sign-in page, on navy) and kofc_r_emblem_rgb_pos.png (browser tab icon; transparent background). Use positive artwork on white/gold and reverse artwork on navy. Preserve proportions, registration marks and clearspace. Council name, number and location accompany the logo. Arial is the approved body font.
Palette uses the published HEX specifications: Knight Navy #112866, Knight Red #CB0E0E, Knight Gold #F7B718.
These marks belong to Knights of Columbus; see the source page for usage policy.
