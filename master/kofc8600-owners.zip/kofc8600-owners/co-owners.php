<?php
/**
 * Co-owners: program owners who help the page's main owner.
 *
 * The main owner is the page's Author, as before. An officer can tick other
 * program owners under "Co-owners" in the page settings. A co-owner can then
 * do on that page exactly what the main owner can, and nothing more: the same
 * Program owner limits apply (no new pages, no moving or unpublishing).
 *
 * Stored as one `_kofc_co_owner` row per co-owner (a user ID) on the page.
 *
 * @package kofc8600-owners
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KOFC_CO_OWNER_META = '_kofc_co_owner';

/** The user IDs of a page's co-owners. */
function kofc_co_owners( $page_id ) {
	return array_values( array_unique( array_map( 'intval', (array) get_post_meta( $page_id, KOFC_CO_OWNER_META ) ) ) );
}

/** Whether a user is a program owner listed as co-owner of a page. */
function kofc_is_co_owner( $user_id, $page_id ) {
	$user = get_userdata( $user_id );
	return $user && in_array( KOFC_OWNER_ROLE, (array) $user->roles, true ) && in_array( (int) $user_id, kofc_co_owners( $page_id ), true );
}

/** The pages a user looks after, as main owner or co-owner. */
function kofc_owner_page_ids( $user_id ) {
	$args = array(
		'post_type'      => 'page',
		'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
		'fields'         => 'ids',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
	);
	$main = get_posts( $args + array( 'author' => $user_id ) );
	$co   = get_posts(
		$args + array(
			'meta_key'   => KOFC_CO_OWNER_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a handful of pages.
			'meta_value' => (string) $user_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
	return array_values( array_unique( array_map( 'intval', array_merge( $main, $co ) ) ) );
}

/*
 * A co-owner gets the permissions the main owner has on that page: editing it,
 * and seeing it (and its revisions) if it is private. WordPress's own checks are
 * kept; only the "someone else's page" ones are swapped for the main owner's,
 * so anything else WordPress or another plugin requires still applies.
 */
add_filter(
	'map_meta_cap',
	function ( $caps, $cap, $user_id, $args ) {
		if ( ! in_array( $cap, array( 'edit_post', 'edit_page', 'read_post', 'read_page' ), true ) || empty( $args[0] ) ) {
			return $caps;
		}
		$post = get_post( $args[0] );
		if ( $post && 'revision' === $post->post_type ) {
			$post = get_post( $post->post_parent );
		}
		if ( ! $post || 'page' !== $post->post_type || (int) $post->post_author === (int) $user_id || 'trash' === $post->post_status ) {
			return $caps;
		}
		if ( ! kofc_is_co_owner( $user_id, $post->ID ) ) {
			return $caps;
		}
		$swap = array(
			'edit_others_pages'  => 'edit_pages',
			'edit_private_pages' => 'edit_pages',
			'read_private_pages' => 'read',
		);
		$out  = array();
		foreach ( $caps as $c ) {
			$out[] = isset( $swap[ $c ] ) ? $swap[ $c ] : $c;
		}
		return array_values( array_unique( $out ) );
	},
	10,
	4
);

/* When a page gets a new Author, he is no longer also its co-owner. */
add_action(
	'post_updated',
	function ( $post_id, $after, $before ) {
		if ( 'page' === $after->post_type && (int) $after->post_author !== (int) $before->post_author ) {
			delete_post_meta( $post_id, KOFC_CO_OWNER_META, (string) $after->post_author );
		}
	},
	10,
	3
);

/* Someone who leaves, or stops being a program owner, stops co-owning pages. */
add_action(
	'delete_user',
	function ( $user_id ) {
		delete_metadata( 'post', 0, KOFC_CO_OWNER_META, (string) $user_id, true );
	}
);
add_action(
	'set_user_role',
	function ( $user_id, $role ) {
		if ( KOFC_OWNER_ROLE !== $role ) {
			delete_metadata( 'post', 0, KOFC_CO_OWNER_META, (string) $user_id, true );
		}
	},
	10,
	2
);

/*
 * Some editor forms (a plugin's settings box, bulk edit) send the page's Author
 * back with every save. WordPress refuses that from a co-owner, since the Author
 * is someone else. Owners can't change the Author anyway (see wp_insert_post_data
 * in kofc8600-owners.php), so drop it from their saves.
 */
add_action(
	'admin_init',
	function () {
		if ( ! kofc_is_owner() ) {
			return;
		}
		foreach ( array( 'post_author', 'post_author_override' ) as $field ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- only removes a field; WordPress checks the nonce for the save itself.
			if ( isset( $_POST[ $field ] ) && (int) $_POST[ $field ] !== get_current_user_id() ) {
				unset( $_POST[ $field ], $_REQUEST[ $field ] );
			}
		}
	}
);

/* The "Co-owners" box in the page settings, for officers only. */
add_action(
	'add_meta_boxes_page',
	function () {
		if ( current_user_can( 'edit_others_pages' ) ) {
			add_meta_box( 'kofc-co-owners', 'Co-owners', 'kofc_co_owners_box', 'page', 'side', 'default' );
		}
	}
);

function kofc_co_owners_box( $post ) {
	$owners = get_users(
		array(
			'role'    => KOFC_OWNER_ROLE,
			'orderby' => 'display_name',
		)
	);
	$main   = get_userdata( $post->post_author );
	$chosen = kofc_co_owners( $post->ID );
	wp_nonce_field( 'kofc_co_owners_' . $post->ID, 'kofc_co_owners_nonce' );
	echo '<input type="hidden" name="kofc_co_owners_sent" value="1">';
	echo '<p>' . esc_html( 'Program owners who can also update this page, to help ' . ( $main ? $main->display_name : 'its owner' ) . '. The main owner is the Author.' ) . '</p>';
	if ( ! $owners ) {
		echo '<p><em>No one has the Program owner role yet. Add them under Users first.</em></p>';
		return;
	}
	echo '<fieldset><legend class="screen-reader-text">Co-owners</legend>';
	foreach ( $owners as $user ) {
		if ( (int) $user->ID === (int) $post->post_author ) {
			continue;
		}
		printf(
			'<label style="display:block;margin:.3em 0"><input type="checkbox" name="kofc_co_owners[]" value="%d"%s> %s</label>',
			(int) $user->ID,
			checked( in_array( (int) $user->ID, $chosen, true ), true, false ),
			esc_html( $user->display_name )
		);
	}
	echo '</fieldset>';
}

/* Save the box. It is sent after the page itself, and only an officer can change it. */
add_action(
	'save_post_page',
	function ( $post_id ) {
		if ( empty( $_POST['kofc_co_owners_sent'] ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST['kofc_co_owners_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['kofc_co_owners_nonce'] ) ), 'kofc_co_owners_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_others_pages' ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$wanted = isset( $_POST['kofc_co_owners'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['kofc_co_owners'] ) ) : array();
		$author = (int) get_post_field( 'post_author', $post_id );
		$valid  = array();
		foreach ( array_unique( $wanted ) as $user_id ) {
			$user = get_userdata( $user_id );
			if ( $user && $user_id !== $author && in_array( KOFC_OWNER_ROLE, (array) $user->roles, true ) ) {
				$valid[] = $user_id;
			}
		}
		delete_post_meta( $post_id, KOFC_CO_OWNER_META );
		foreach ( $valid as $user_id ) {
			add_post_meta( $post_id, KOFC_CO_OWNER_META, $user_id );
		}
	}
);
