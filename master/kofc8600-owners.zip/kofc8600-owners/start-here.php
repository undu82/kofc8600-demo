<?php
/**
 * "Start here" on the dashboard.
 *
 * The jobs volunteers do most, each with a button and two or three steps, every
 * page by section, and where the things that are not in WordPress get updated.
 *
 * Everyone gets this simple dashboard, administrators included, so the main
 * editor sees it whatever his role. An administrator who wants WordPress.com's
 * own boxes back turns them on for himself with the link at the bottom.
 *
 * @package kofc8600-owners
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Whoever volunteers should ask when they are stuck. Change it with the filter. */
function kofc_help_contact() {
	return (string) apply_filters( 'kofc_help_contact', 'Sebastian or David' );
}

/** True unless an administrator has chosen the full WordPress.com dashboard. */
function kofc_simple_dashboard() {
	return ! ( current_user_can( 'manage_options' ) && get_user_meta( get_current_user_id(), 'kofc_full_dashboard', true ) );
}

/** Where the things that are not in WordPress get updated. */
function kofc_elsewhere() {
	return array(
		array( 'Events', 'Add or change them in the Council\'s Google Calendar. The site shows them within the hour.', 'https://calendar.google.com/', 'Google Calendar' ),
		array( 'Volunteer sign-ups', 'Made in SignUpGenius. Each event on the site shows its open shifts.', 'https://www.signupgenius.com/', 'SignUpGenius' ),
		array( 'Dues and donations', 'Taken through Zeffy, run by the Financial Secretary.', 'https://www.zeffy.com/', 'Zeffy' ),
		array( 'Emails to brothers', 'Sent through Flocknote by the Grand Knight.', 'https://stmaryofsorrowsromancath.flocknote.com/', 'Flocknote' ),
	);
}

/** Every page this person can edit, keyed by parent ID, from one query. */
function kofc_pages_by_parent() {
	$pages = get_pages(
		array(
			'post_status' => 'publish,private',
			'sort_column' => 'menu_order,post_title',
		)
	);
	$ids = wp_list_pluck( $pages, 'ID' );
	$by  = array();
	foreach ( $pages as $page ) {
		if ( ! current_user_can( 'edit_post', $page->ID ) ) {
			continue;
		}
		// A page whose parent is missing from the list goes at the top level.
		$parent          = in_array( (int) $page->post_parent, $ids, true ) ? (int) $page->post_parent : 0;
		$by[ $parent ][] = $page;
	}
	return $by;
}

/** The pages under one parent as nested lists, each linking straight to its editor. */
function kofc_page_tree( $by, $parent = 0 ) {
	if ( empty( $by[ $parent ] ) ) {
		return '';
	}
	$items = '';
	foreach ( $by[ $parent ] as $page ) {
		$names = array();
		foreach ( array_merge( array( (int) $page->post_author ), function_exists( 'kofc_co_owners' ) ? kofc_co_owners( $page->ID ) : array() ) as $user_id ) {
			$user = get_userdata( $user_id );
			if ( $user && in_array( 'program_owner', (array) $user->roles, true ) ) {
				$names[] = $user->display_name;
			}
		}
		$note   = $names ? ' <span class="kofc-owner-name">' . esc_html( implode( ', ', array_unique( $names ) ) ) . '</span>' : '';
		$title  = get_the_title( $page );
		$items .= '<li><a href="' . esc_url( get_edit_post_link( $page->ID ) ) . '">' . esc_html( '' !== $title ? $title : '(no title)' ) . '</a>' . $note
			. kofc_page_tree( $by, $page->ID ) . '</li>';
	}
	return '<ul>' . $items . '</ul>';
}

/** The page buttons for this person, as array( title, steps, url, button ). */
function kofc_page_tasks() {
	$steps = 'Click any text and type over it. Click a photo, then Replace. Press Save at the top right: changes go live straight away.';
	$tasks = array();
	if ( current_user_can( 'edit_others_pages' ) ) {
		$home = (int) get_option( 'page_on_front' );
		if ( $home && current_user_can( 'edit_post', $home ) ) {
			$tasks[] = array( 'The home page', $steps, get_edit_post_link( $home ), 'Edit the home page' );
		}
		$recognition = get_posts(
			array(
				'post_type'   => 'page',
				'name'        => 'recognition',
				'numberposts' => 1,
				'fields'      => 'ids',
			)
		);
		if ( $recognition && current_user_can( 'edit_post', $recognition[0] ) ) {
			$tasks[] = array( 'Knight and Family of the Month', 'Click the photo, then Replace, and type the new name. Press Save.', get_edit_post_link( $recognition[0] ), 'Open Recognition' );
		}
		return $tasks;
	}
	// Program owners: one button per page they look after, as main owner or co-owner.
	$ids  = function_exists( 'kofc_owner_page_ids' ) ? kofc_owner_page_ids( get_current_user_id() ) : array();
	$mine = $ids ? get_posts(
		array(
			'post_type'   => 'page',
			'post__in'    => $ids,
			'post_status' => array( 'publish', 'private' ),
			'numberposts' => 20,
			'orderby'     => 'title',
			'order'       => 'ASC',
		)
	) : array();
	foreach ( $mine as $page ) {
		if ( current_user_can( 'edit_post', $page->ID ) ) {
			$tasks[] = array( get_the_title( $page ), $steps, get_edit_post_link( $page->ID ), 'Edit this page' );
		}
	}
	return $tasks;
}

/** The other jobs this person can do. */
function kofc_other_tasks() {
	$tasks = array();
	if ( current_user_can( 'upload_files' ) ) {
		$tasks[] = array( 'Photos', 'Upload new photos here, or straight from a page with Replace.', admin_url( 'upload.php' ), 'Open the photo library' );
	}
	$email = get_post_type_object( 'council_email' );
	if ( $email && current_user_can( $email->cap->create_posts ) ) {
		$tasks[] = array( 'Council emails', 'Paste an email the Grand Knight sent, so brothers can find it later.', admin_url( 'post-new.php?post_type=council_email' ), 'Add a Council email' );
	}
	if ( function_exists( 'kofc_members_waiting' ) && current_user_can( 'kofc_review_members' ) ) {
		$tasks[] = array( 'Brothers', 'Approve brothers who ask for the members\' area, or remove one who has left.', admin_url( 'admin.php?page=kofc-brothers' ), 'Open Brothers' );
	}
	return $tasks;
}

function kofc_start_here_box() {
	$pages = kofc_page_tasks();
	$tasks = array_merge( $pages, kofc_other_tasks() );
	echo '<div class="kofc-start">';

	if ( ! $pages && ! current_user_can( 'edit_others_pages' ) ) {
		echo '<p class="kofc-help">' . esc_html( 'You have no pages to update yet. Ask ' . kofc_help_contact() . ' to give you yours.' ) . '</p>';
	}
	echo '<ul class="kofc-tasks">';
	foreach ( $tasks as $t ) {
		list( $title, $steps, $url, $button ) = $t;
		printf(
			'<li><h3>%s</h3><p>%s</p><a class="button button-primary" href="%s">%s</a></li>',
			esc_html( $title ),
			esc_html( $steps ),
			esc_url( $url ),
			esc_html( $button )
		);
	}
	echo '</ul>';

	if ( current_user_can( 'edit_others_pages' ) ) {
		$tree = kofc_page_tree( kofc_pages_by_parent() );
		if ( $tree ) {
			echo '<h3 class="kofc-subhead">Every page, by section</h3><p class="kofc-hint">Click a page to change it. Names in grey are the people who look after that page.</p>';
			echo '<div class="kofc-pages">' . $tree . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts in kofc_page_tree().
		}
	}

	echo '<h3 class="kofc-subhead">Not updated here</h3><ul class="kofc-elsewhere">';
	foreach ( kofc_elsewhere() as $e ) {
		list( $title, $text, $url, $name ) = $e;
		printf(
			'<li><strong>%s:</strong> %s <a href="%s" target="_blank" rel="noopener">%s<span class="screen-reader-text"> (opens in a new tab)</span></a></li>',
			esc_html( $title ),
			esc_html( $text ),
			esc_url( $url ),
			esc_html( $name )
		);
	}
	echo '</ul>';

	$undo = current_user_can( 'edit_others_pages' )
		? 'WordPress keeps the earlier versions of every page. In the panel on the right (the square icon at the top right opens it), choose Page, click Revisions, pick an earlier version and press Restore.'
		: 'WordPress keeps the earlier versions of every page, and an officer can bring one back.';
	echo '<p class="kofc-help"><strong>Made a mistake?</strong> ' . esc_html( $undo ) . ' <strong>Stuck?</strong> ' . esc_html( 'Ask ' . kofc_help_contact() . '.' ) . '</p>';

	if ( current_user_can( 'manage_options' ) ) {
		$full = ! kofc_simple_dashboard();
		printf(
			'<p class="kofc-mode"><a href="%s">%s</a></p>',
			esc_url( wp_nonce_url( admin_url( 'index.php?kofc_full_dashboard=' . ( $full ? '0' : '1' ) ), 'kofc_dashboard_mode' ) ),
			esc_html( $full ? 'Go back to the simple dashboard' : 'Show WordPress.com\'s own boxes too (only for you)' )
		);
	}
	echo '</div>';
}

/* The link at the bottom of the box: an administrator switches the full dashboard on or off for himself. */
add_action(
	'load-index.php',
	function () {
		if ( ! isset( $_GET['kofc_full_dashboard'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'kofc_dashboard_mode' );
		if ( '1' === $_GET['kofc_full_dashboard'] ) {
			update_user_meta( get_current_user_id(), 'kofc_full_dashboard', 1 );
		} else {
			delete_user_meta( get_current_user_id(), 'kofc_full_dashboard' );
		}
		wp_safe_redirect( admin_url( 'index.php' ) );
		exit;
	}
);

add_action(
	'wp_dashboard_setup',
	function () {
		wp_add_dashboard_widget( 'kofc_start_here', 'Start here', 'kofc_start_here_box', null, null, 'normal', 'high' );

		global $wp_meta_boxes;
		if ( empty( $wp_meta_boxes['dashboard'] ) ) {
			return;
		}
		if ( kofc_simple_dashboard() ) {
			// Only this box, plus WordPress's warnings about an outdated browser or PHP.
			$keep = array( 'kofc_start_here', 'dashboard_browser_nag', 'dashboard_php_nag' );
		} else {
			// The full dashboard, without the boxes for blog posts and WordPress news, which this site doesn't use.
			$drop = array( 'dashboard_activity', 'dashboard_quick_press', 'dashboard_primary' );
		}
		foreach ( $wp_meta_boxes['dashboard'] as $context => $priorities ) {
			foreach ( $priorities as $priority => $boxes ) {
				foreach ( array_keys( (array) $boxes ) as $id ) {
					if ( isset( $keep ) ? ! in_array( $id, $keep, true ) : in_array( $id, $drop, true ) ) {
						unset( $wp_meta_boxes['dashboard'][ $context ][ $priority ][ $id ] );
					}
				}
			}
		}
	},
	PHP_INT_MAX
);

/* The box can't be hidden or folded away, and on the simple dashboard it can't be dragged into a hidden column. */
add_filter(
	'hidden_meta_boxes',
	function ( $hidden, $screen ) {
		return ( $screen && 'dashboard' === $screen->id ) ? array_values( array_diff( (array) $hidden, array( 'kofc_start_here' ) ) ) : $hidden;
	},
	10,
	2
);
add_filter(
	'get_user_option_closedpostboxes_dashboard',
	function ( $closed ) {
		return is_array( $closed ) ? array_values( array_diff( $closed, array( 'kofc_start_here' ) ) ) : $closed;
	}
);
add_filter(
	'get_user_option_meta-box-order_dashboard',
	function ( $order ) {
		return kofc_simple_dashboard() ? false : $order;
	}
);

add_action(
	'admin_head-index.php',
	function () {
		?>
<style>
#kofc_start_here .kofc-tasks{display:grid;grid-template-columns:repeat(auto-fill,minmax(15rem,1fr));gap:.75rem;margin:0 0 1rem;padding:0;list-style:none}
#kofc_start_here .kofc-tasks li{margin:0;padding:1rem;border:1px solid #dcdcde;border-radius:6px;background:#fff;display:flex;flex-direction:column;align-items:flex-start}
#kofc_start_here h3{margin:0 0 .35rem;font-size:1.05rem}
#kofc_start_here .kofc-tasks p{margin:0 0 .85rem;font-size:.95rem;flex:1}
#kofc_start_here .kofc-subhead{margin-top:.5rem}
#kofc_start_here .kofc-hint{margin:0 0 .5rem;color:#50575e}
#kofc_start_here .kofc-pages>ul{columns:15rem;column-gap:1.5rem;margin:0 0 1rem;padding:0;list-style:none}
#kofc_start_here .kofc-pages>ul>li{break-inside:avoid;margin:0 0 .75rem;font-weight:600}
#kofc_start_here .kofc-pages ul ul{margin:.25rem 0 0 .9rem;padding:0;list-style:none;font-weight:400}
#kofc_start_here .kofc-pages li li{margin:.2rem 0}
#kofc_start_here .kofc-pages a{text-decoration:none}
#kofc_start_here .kofc-pages a:hover,#kofc_start_here .kofc-pages a:focus{text-decoration:underline}
#kofc_start_here .kofc-owner-name{color:#646970;font-weight:400;font-size:.85em}
#kofc_start_here .kofc-elsewhere{margin:.25rem 0 1rem;padding-left:1.1rem;list-style:disc}
#kofc_start_here .kofc-elsewhere li{margin-bottom:.35rem;font-size:.95rem}
#kofc_start_here .kofc-help{margin:0 0 .75rem;padding:.75rem 1rem;background:#f6f7f7;border-radius:6px;font-size:.95rem}
#kofc_start_here .kofc-mode{margin:0;font-size:.85rem}
		<?php if ( kofc_simple_dashboard() ) : ?>
#dashboard-widgets .postbox-container{width:100%!important;float:none}
#postbox-container-2,#postbox-container-3,#postbox-container-4{display:none}
#kofc_start_here .handle-actions{display:none}
		<?php endif; ?>
</style>
		<?php
	}
);

/* Officers and owners don't need the Date or Comments columns in the Pages list. */
add_filter(
	'default_hidden_columns',
	function ( $hidden, $screen ) {
		if ( $screen && 'edit-page' === $screen->id && ! current_user_can( 'manage_options' ) ) {
			$hidden = array_merge( (array) $hidden, array( 'date', 'comments' ) );
		}
		return $hidden;
	},
	10,
	2
);
