<?php
/**
 * Plugin Name: Council 8600 Program Owners
 * Description: Adds a "Program owner" role. A program owner can update only the pages they are the author of (for example, the Faith Director and the Faith page) and upload photos. Officers can add co-owners, who get the same rights on that page. Only officers (Editors and Administrators) can create pages or assign their owners. Also gives everyone a simple dashboard: a "Start here" box with the common jobs and every page by section.
 * Version: 0.2.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 *
 * How ownership works: WordPress lets a user edit someone else's page only with
 * the "edit_others_pages" capability. This role does not have it, so an owner
 * can edit exactly the pages where they are set as Author (Page settings,
 * Author). To hand a page to a new owner, an Editor changes its Author.
 *
 * Creating pages needs the custom "create_pages" capability, which only
 * Editors and Administrators get, so owners cannot add pages of their own.
 *
 * @package kofc8600-owners
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/co-owners.php';
require_once __DIR__ . '/start-here.php';

function kofc_owner_capabilities() {
	return array(
		'read'                   => true,
		// The block editor lists only users with a user level as possible page authors, so without this an officer couldn't hand an owner a page.
		'level_1'                => true,
		'upload_files'           => true,
		// Pages: update their own live page directly. They cannot create or delete pages.
		'edit_pages'             => true,
		'edit_published_pages'   => true,
		'publish_pages'          => true,
	);
}

function kofc_owner_setup_roles() {
	remove_role( 'program_owner' );
	add_role( 'program_owner', 'Program owner', kofc_owner_capabilities() );
	foreach ( get_users( array( 'role' => 'program_owner' ) ) as $owner ) {
		$owner->update_user_level_from_caps();
	}
	foreach ( array( 'administrator', 'editor' ) as $officer ) {
		$role = get_role( $officer );
		if ( $role ) {
			$role->add_cap( 'create_pages' );
		}
	}
}
register_activation_hook( __FILE__, 'kofc_owner_setup_roles' );

add_action(
	'init',
	function () {
		$editor = get_role( 'editor' );
		$owner  = get_role( 'program_owner' );
		// Owners could add events (posts) until events moved to the Council's Google Calendar; rebuild the role without that.
		// Also rebuild a role saved before level_1 was added (owners need it to appear in the editor's Author list).
		if ( ! $owner || $owner->has_cap( 'edit_posts' ) || ! $owner->has_cap( 'level_1' ) || ( $editor && ! $editor->has_cap( 'create_pages' ) ) ) {
			kofc_owner_setup_roles();
		}
	}
);

/* Creating a page requires "create_pages" instead of "edit_pages". */
add_filter(
	'register_post_type_args',
	function ( $args, $post_type ) {
		if ( 'page' === $post_type ) {
			$args['capabilities'] = array_merge( isset( $args['capabilities'] ) ? (array) $args['capabilities'] : array(), array( 'create_posts' => 'create_pages' ) );
		}
		return $args;
	},
	10,
	2
);

function kofc_is_owner() {
	return in_array( 'program_owner', (array) wp_get_current_user()->roles, true );
}

/*
 * Owners change what is on their page, not where it lives. When an owner saves
 * a page, its address, parent, order, status, date and template stay as they
 * were, whatever the editor sends. Officers can still change all of these.
 */
add_filter(
	'wp_insert_post_data',
	function ( $data, $postarr, $unsanitized, $update ) {
		if ( ! $update || 'page' !== $data['post_type'] || ! kofc_is_owner() || empty( $postarr['ID'] ) ) {
			return $data;
		}
		$old = get_post( $postarr['ID'] );
		if ( $old ) {
			foreach ( array( 'post_author', 'post_name', 'post_parent', 'menu_order', 'post_status', 'post_date', 'post_date_gmt', 'post_password', 'comment_status', 'ping_status' ) as $field ) {
				$data[ $field ] = $old->$field;
			}
		}
		return $data;
	},
	10,
	4
);
add_filter(
	'update_post_metadata',
	function ( $check, $object_id, $meta_key ) {
		return ( '_wp_page_template' === $meta_key && kofc_is_owner() ) ? false : $check;
	},
	10,
	3
);

/* In the editor, owners see the page and the Save button, without settings they cannot change. */
add_filter(
	'admin_body_class',
	function ( $classes ) {
		return kofc_is_owner() ? $classes . ' kofc-owner' : $classes;
	}
);
add_action(
	'enqueue_block_editor_assets',
	function () {
		if ( kofc_is_owner() ) {
			wp_add_inline_style( 'wp-edit-post', '.kofc-owner .editor-post-panel__row{display:none}' );
			wp_add_inline_script(
				'wp-edit-post',
				"wp.domReady(function(){var e=wp.data.dispatch('core/editor');['page-attributes','post-link','discussion-panel'].forEach(function(p){e.removeEditorPanel(p);});});"
			);
		}
	}
);

/* Keep the menu short for officers and owners: the site has no blog or comments. */
add_action(
	'admin_menu',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			remove_menu_page( 'edit.php' );
			remove_menu_page( 'edit-comments.php' );
			remove_menu_page( 'tools.php' );
		}
	},
	99
);

/*
 * Let owners open the Pages list. Owners can't add pages, so WordPress folds
 * the Pages menu down to one item, loses track of it, and then judges the list
 * (edit.php?post_type=page) by the blog's All Posts entry (edit.php), which
 * owners may not open. 'custom_menu_order' is the last hook before that check
 * (wp-admin/includes/menu.php), so clear the All Posts refusal there, only for
 * an owner opening the Pages list. The Posts list still checks its own permission.
 */
add_filter(
	'custom_menu_order',
	function ( $custom ) {
		global $pagenow, $typenow, $_wp_submenu_nopriv;
		if ( 'edit.php' === $pagenow && 'page' === $typenow && kofc_is_owner() && current_user_can( 'edit_pages' ) ) {
			unset( $_wp_submenu_nopriv['edit.php']['edit.php'] );
		}
		return $custom;
	}
);

/* Owners see only the pages they look after in Pages (as main owner or co-owner), so the list is not a wall of pages they cannot open. */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() && $query->is_main_query() && 'page' === $query->get( 'post_type' ) && kofc_is_owner() ) {
			$ids = kofc_owner_page_ids( get_current_user_id() );
			$query->set( 'post__in', $ids ? $ids : array( 0 ) );
			// WordPress narrows this list to pages they wrote, both as "Mine" and for private pages, which would hide co-owned pages. post__in already limits it to their pages.
			$query->set( 'author', '' );
			$query->set( 'perm', '' );
			if ( ! $query->get( 'post_status' ) || 'all' === $query->get( 'post_status' ) ) {
				$query->set( 'post_status', array( 'publish', 'private', 'draft', 'pending', 'future' ) );
			}
		}
	}
);
