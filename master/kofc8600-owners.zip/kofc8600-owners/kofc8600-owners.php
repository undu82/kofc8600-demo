<?php
/**
 * Plugin Name: Council 8600 Program Owners
 * Description: Program owners: a program owner can update only the pages they are the author of (for example, the Faith Director and the Faith page) and upload photos. Officers can add co-owners, who get the same rights on that page. Only officers (Editors and Administrators) can create pages or assign their owners. Also gives everyone a simple dashboard: a "Start here" box with the common jobs and every page by section.
 * Version: 0.3.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 *
 * Who is a program owner: someone with WordPress's standard Contributor role,
 * which this plugin calls "Program owner" in the dashboard and gives the page
 * rules below. A standard role, so an officer can add a program owner with the
 * "Invite user" box ticked: WordPress.com sends a Contributor invite, and
 * accepting it keeps the role. (A role of our own would go out as a plain
 * subscriber invite.) On WordPress.com's own People screen he reads
 * "Contributor". Switching the plugin off gives the role back WordPress's own
 * Contributor rights.
 *
 * How ownership works: WordPress lets a user edit someone else's page only with
 * the "edit_others_pages" capability. Program owners don't have it, so an owner
 * can edit exactly the pages where they are set as Author (Page settings,
 * Author), or are ticked as a co-owner. To hand a page to a new owner, an
 * officer changes its Author.
 *
 * Creating pages needs the custom "create_pages" capability, which only
 * Editors and Administrators get, so owners cannot add pages of their own.
 *
 * @package kofc8600-owners
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KOFC_OWNER_ROLE = 'contributor';

require_once __DIR__ . '/co-owners.php';
require_once __DIR__ . '/start-here.php';

/* What a program owner can do. */
function kofc_owner_capabilities() {
	return array(
		'read',
		// The block editor lists only users with a user level as possible page authors (Contributors have level 1).
		'level_0',
		'level_1',
		'upload_files',
		// Pages: update their own live page directly. They cannot create or delete pages.
		'edit_pages',
		'edit_published_pages',
		'publish_pages',
	);
}
/* What WordPress's Contributor can do that a program owner can't: blog posts (the site has none). */
function kofc_owner_removed_capabilities() {
	return array( 'edit_posts', 'delete_posts' );
}

function kofc_owner_setup_roles() {
	$role = get_role( KOFC_OWNER_ROLE );
	if ( $role ) {
		foreach ( kofc_owner_capabilities() as $cap ) {
			$role->add_cap( $cap );
		}
		foreach ( kofc_owner_removed_capabilities() as $cap ) {
			$role->remove_cap( $cap );
		}
	}
	// Owners saved under this plugin's own role (used until 2026-11-07) move to the standard one.
	if ( get_role( 'program_owner' ) ) {
		foreach ( get_users( array( 'role' => 'program_owner' ) ) as $owner ) {
			$owner->set_role( KOFC_OWNER_ROLE );
		}
		remove_role( 'program_owner' );
	}
	foreach ( array( 'administrator', 'editor' ) as $officer ) {
		$officer_role = get_role( $officer );
		if ( $officer_role ) {
			$officer_role->add_cap( 'create_pages' );
		}
	}
}
register_activation_hook( __FILE__, 'kofc_owner_setup_roles' );

/* Switched off: Contributor goes back to WordPress's own rights, so nobody keeps page rights without the rules below. */
register_deactivation_hook(
	__FILE__,
	function () {
		$role = get_role( KOFC_OWNER_ROLE );
		if ( $role ) {
			foreach ( array( 'upload_files', 'edit_pages', 'edit_published_pages', 'publish_pages' ) as $cap ) {
				$role->remove_cap( $cap );
			}
			foreach ( kofc_owner_removed_capabilities() as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
);

add_action(
	'init',
	function () {
		$owner  = get_role( KOFC_OWNER_ROLE );
		$editor = get_role( 'editor' );
		// Set the rights again if anything has reset them, or if owners still have the old role.
		if ( ( $owner && ( ! $owner->has_cap( 'edit_pages' ) || $owner->has_cap( 'edit_posts' ) ) ) || get_role( 'program_owner' ) || ( $editor && ! $editor->has_cap( 'create_pages' ) ) ) {
			kofc_owner_setup_roles();
		}
		// In this dashboard, the role is called what it is for.
		$roles = wp_roles();
		if ( isset( $roles->roles[ KOFC_OWNER_ROLE ] ) ) {
			$roles->roles[ KOFC_OWNER_ROLE ]['name'] = 'Program owner';
			$roles->role_names[ KOFC_OWNER_ROLE ]    = 'Program owner';
		}
	}
);

/* Creating a page requires "create_pages" instead of "edit_pages". */
add_filter(
	'register_post_type_args',
	function ( $args, $post_type ) {
		if ( 'page' === $post_type ) {
			$args['capabilities'] = array_merge( isset( $args['capabilities'] ) ? (array) $args['capabilities'] : array(), array( 'create_posts' => 'create_pages' ) );
		}
		return $args;
	},
	10,
	2
);

/*
 * After signing in, WordPress (and Jetpack's WordPress.com login) sends anyone who
 * can't write blog posts to their profile. Program owners can't, by design, but
 * belong on the Start here dashboard. WordPress's own sign-in screen overrides a
 * plain admin_url() afterwards, so point at index.php instead.
 */
add_filter(
	'login_redirect',
	function ( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && in_array( KOFC_OWNER_ROLE, (array) $user->roles, true )
			&& ( '' === (string) $redirect_to || admin_url() === $redirect_to || 'wp-admin/' === $redirect_to || false !== strpos( (string) $redirect_to, 'profile.php' ) ) ) {
			return admin_url( 'index.php' );
		}
		return $redirect_to;
	},
	20,
	3
);

function kofc_is_owner() {
	return in_array( KOFC_OWNER_ROLE, (array) wp_get_current_user()->roles, true );
}

/*
 * Owners change what is on their page, not where it lives. When an owner saves
 * a page, its address, parent, order, status, date and template stay as they
 * were, whatever the editor sends. Officers can still change all of these.
 */
add_filter(
	'wp_insert_post_data',
	function ( $data, $postarr, $unsanitized, $update ) {
		if ( ! $update || 'page' !== $data['post_type'] || ! kofc_is_owner() || empty( $postarr['ID'] ) ) {
			return $data;
		}
		$old = get_post( $postarr['ID'] );
		if ( $old ) {
			foreach ( array( 'post_author', 'post_name', 'post_parent', 'menu_order', 'post_status', 'post_date', 'post_date_gmt', 'post_password', 'comment_status', 'ping_status' ) as $field ) {
				$data[ $field ] = $old->$field;
			}
		}
		return $data;
	},
	10,
	4
);
add_filter(
	'update_post_metadata',
	function ( $check, $object_id, $meta_key ) {
		return ( '_wp_page_template' === $meta_key && kofc_is_owner() ) ? false : $check;
	},
	10,
	3
);

/* In the editor, owners see the page and the Save button, without settings they cannot change. */
add_filter(
	'admin_body_class',
	function ( $classes ) {
		return kofc_is_owner() ? $classes . ' kofc-owner' : $classes;
	}
);
add_action(
	'enqueue_block_editor_assets',
	function () {
		if ( kofc_is_owner() ) {
			wp_add_inline_style( 'wp-edit-post', '.kofc-owner .editor-post-panel__row{display:none}' );
			wp_add_inline_script(
				'wp-edit-post',
				"wp.domReady(function(){var e=wp.data.dispatch('core/editor');['page-attributes','post-link','discussion-panel'].forEach(function(p){e.removeEditorPanel(p);});});"
			);
		}
	}
);

/* Keep the menu short for officers and owners: the site has no blog or comments. */
add_action(
	'admin_menu',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			remove_menu_page( 'edit.php' );
			remove_menu_page( 'edit-comments.php' );
			remove_menu_page( 'tools.php' );
		}
	},
	99
);

/*
 * Let owners open the Pages list. Owners can't add pages, so WordPress folds
 * the Pages menu down to one item, loses track of it, and then judges the list
 * (edit.php?post_type=page) by the blog's All Posts entry (edit.php), which
 * owners may not open. 'custom_menu_order' is the last hook before that check
 * (wp-admin/includes/menu.php), so clear the All Posts refusal there, only for
 * an owner opening the Pages list. The Posts list still checks its own permission.
 */
add_filter(
	'custom_menu_order',
	function ( $custom ) {
		global $pagenow, $typenow, $_wp_submenu_nopriv;
		if ( 'edit.php' === $pagenow && 'page' === $typenow && kofc_is_owner() && current_user_can( 'edit_pages' ) ) {
			unset( $_wp_submenu_nopriv['edit.php']['edit.php'] );
		}
		return $custom;
	}
);

/* Owners see only the pages they look after in Pages (as main owner or co-owner), so the list is not a wall of pages they cannot open. */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() && $query->is_main_query() && 'page' === $query->get( 'post_type' ) && kofc_is_owner() ) {
			$ids = kofc_owner_page_ids( get_current_user_id() );
			$query->set( 'post__in', $ids ? $ids : array( 0 ) );
			// WordPress narrows this list to pages they wrote, both as "Mine" and for private pages, which would hide co-owned pages. post__in already limits it to their pages.
			$query->set( 'author', '' );
			$query->set( 'perm', '' );
			if ( ! $query->get( 'post_status' ) || 'all' === $query->get( 'post_status' ) ) {
				$query->set( 'post_status', array( 'publish', 'private', 'draft', 'pending', 'future' ) );
			}
		}
	}
);
