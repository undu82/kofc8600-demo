/*
 * Council calendar ([council_calendar]): filters, the List/Month switch, paging through months,
 * a day's events under the month grid, "Show more", and opening an event linked from elsewhere
 * (/events/#e-…). Without JavaScript the page shows the list, every event in it. No dependencies.
 */
(function () {
	var KEY = 'kofc8600-cal-view';
	function remember(v) { try { localStorage.setItem(KEY, v); } catch (e) { /* storage blocked */ } }
	function recall() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }

	document.querySelectorAll('.cal').forEach(function (cal) {
		var sw = cal.querySelector('.cal-switch');
		var months = Array.prototype.slice.call(cal.querySelectorAll('.cal-month'));
		var dayPanel = cal.querySelector('.cal-day');
		var empty = cal.querySelector('.cal-empty');
		var filter = 'all';

		/* List or month: the visitor's last choice, otherwise the list on phones and the month on wider screens. */
		function setView(v) {
			cal.dataset.view = v;
			sw.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.view === v)); });
		}
		if (sw && months.length) {
			sw.hidden = false;
			setView(recall() || (window.matchMedia('(min-width: 782px)').matches ? 'month' : 'list'));
			sw.addEventListener('click', function (e) {
				var b = e.target.closest('button[data-view]');
				if (b) { setView(b.dataset.view); remember(b.dataset.view); }
			});
		}

		/* Filters: one at a time. Filtering shows every week of the list, not only the first two. */
		function matches(el) { return filter === 'all' || (filter === 'need' ? el.dataset.need === '1' : el.dataset.cat === filter); }
		function applyFilter() {
			var any = false;
			cal.querySelectorAll('.cal-list .ev-entry').forEach(function (el) { var ok = matches(el); el.hidden = !ok; any = any || ok; });
			cal.querySelectorAll('.ev-group').forEach(function (g) { g.hidden = !g.querySelector('.ev-entry:not([hidden])'); });
			cal.querySelectorAll('.mday li[data-cat]').forEach(function (li) { li.classList.toggle('is-dim', !matches(li)); });
			empty.hidden = any;
			cal.classList.toggle('is-filtered', filter !== 'all');
		}
		cal.querySelector('.cal-filters').addEventListener('click', function (e) {
			var b = e.target.closest('.chip');
			if (!b) { return; }
			filter = b.dataset.filter;
			cal.querySelectorAll('.chip').forEach(function (c) { c.setAttribute('aria-pressed', String(c === b)); });
			applyFilter();
		});

		var more = cal.querySelector('.cal-show-more');
		if (more) {
			more.addEventListener('click', function () { cal.classList.add('is-expanded'); more.parentNode.hidden = true; });
		}

		/* Months: one at a time, with previous and next. */
		var prev = cal.querySelector('.mprev');
		var next = cal.querySelector('.mnext');
		var current = 0;
		function showMonth(i) {
			current = Math.max(0, Math.min(months.length - 1, i));
			months.forEach(function (m, j) { m.hidden = j !== current; });
			prev.disabled = current === 0;
			next.disabled = current === months.length - 1;
			dayPanel.innerHTML = '';
		}
		if (prev && months.length) {
			prev.addEventListener('click', function () { showMonth(current - 1); });
			next.addEventListener('click', function () { showMonth(current + 1); });
			showMonth(0);
		}

		/* A day's events, under the grid: copies of the list's entries, with their notes and shifts. */
		cal.querySelectorAll('.mday[data-has]').forEach(function (d) { d.tabIndex = 0; d.setAttribute('role', 'button'); });
		function openDay(d) {
			cal.querySelectorAll('.mday.is-selected').forEach(function (x) { x.classList.remove('is-selected'); });
			d.classList.add('is-selected');
			var title = document.createElement('h2');
			title.className = 'cal-group';
			title.textContent = d.getAttribute('aria-label').split(':')[0];
			var listEl = document.createElement('div');
			listEl.className = 'ev-list';
			cal.querySelectorAll('.cal-list .ev-entry[data-day="' + d.dataset.day + '"]').forEach(function (el) {
				var copy = el.cloneNode(true);
				copy.removeAttribute('id');
				copy.hidden = false;
				var chip = copy.querySelector('.datechip');
				if (chip) { chip.classList.remove('is-same'); }
				listEl.appendChild(copy);
			});
			dayPanel.replaceChildren(title, listEl);
			if (!window.matchMedia('(min-width: 782px)').matches) { title.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
		}
		cal.addEventListener('click', function (e) {
			var d = e.target.closest('.mday[data-has]');
			if (d) { openDay(d); }
		});
		cal.addEventListener('keydown', function (e) {
			if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.mday[data-has]')) { e.preventDefault(); openDay(e.target); }
		});

		/* An event linked from the home page: show the list and open it. */
		function fromHash() {
			var id = window.location.hash.slice(1);
			var el = /^e-[0-9a-f]+$/.test(id) && document.getElementById(id);
			if (!el || !cal.contains(el)) { return; }
			if (sw) { setView('list'); }
			cal.classList.add('is-expanded');
			var details = el.querySelector('details');
			if (details) { details.open = true; }
			el.scrollIntoView({ block: 'start' });
		}
		fromHash();
		window.addEventListener('hashchange', fromHash);
	});
})();
