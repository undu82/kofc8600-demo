/* Council 8600 Events: "When and where" fields in the editor sidebar. Plain JavaScript, no build step. */
( function ( wp ) {
	var el = wp.element.createElement;
	/*
	 * The fields sit in the sidebar's Summary area, which is always shown, so the date can never be
	 * hidden. (A separate collapsible panel started closed for new users: WordPress loads saved
	 * preferences after the editor starts and replaces any panel opened before that.)
	 */
	var StatusInfo = ( wp.editor && wp.editor.PluginPostStatusInfo ) || wp.editPost.PluginPostStatusInfo;
	var LOCK = 'kofc-event-date';

	function EventFields() {
		var postType = wp.data.useSelect( function ( select ) { return select( 'core/editor' ).getCurrentPostType(); }, [] );
		var meta = wp.data.useSelect( function ( select ) { return select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {}; }, [] );
		var editor = wp.data.useDispatch( 'core/editor' );
		var date = meta._event_date || '';

		/* Publishing stays locked until there is a date. */
		wp.element.useEffect( function () {
			if ( postType !== 'event' ) { return; }
			if ( date ) { editor.unlockPostSaving( LOCK ); } else { editor.lockPostSaving( LOCK ); }
		}, [ date, postType ] );

		if ( postType !== 'event' ) { return null; }

		function field( key, label, extra ) {
			return el( wp.components.TextControl, Object.assign( {
				label: label,
				value: meta[ key ] || '',
				onChange: function ( value ) { var m = {}; m[ key ] = value; editor.editPost( { meta: m } ); },
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true
			}, extra || {} ) );
		}

		return el( StatusInfo, { className: 'kofc-event-fields' },
			el( 'div', { style: { display: 'grid', gap: '16px', width: '100%', paddingTop: '8px' } },
				el( 'h2', { style: { margin: 0, fontSize: '13px', fontWeight: 600 } }, 'When and where' ),
				field( '_event_date', 'Date (required)', { type: 'date', help: date ? '' : 'Add the date to publish this event.' } ),
				field( '_event_time', 'Time', { placeholder: '7:30 pm', help: 'Write it the way you would say it.' } ),
				field( '_event_place', 'Place', { placeholder: 'Parish Hall' } ),
				field( '_event_note', 'Note (optional)', { placeholder: '3 volunteers still needed', help: 'Shown as a gold badge. Clear it when it no longer applies.' } ),
				field( '_event_signup', 'Sign-up link (optional)', { type: 'url', placeholder: 'https://www.signupgenius.com/…', help: 'Paste the SignUpGenius link. A "Sign up to help" button then appears with the event.' } )
			)
		);
	}

	wp.plugins.registerPlugin( 'kofc8600-event-fields', { render: EventFields, icon: 'calendar-alt' } );
} )( window.wp );
