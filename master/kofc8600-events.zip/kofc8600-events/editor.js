/* Council 8600 Events: "When and where" panel in the editor sidebar. Plain JavaScript, no build step. */
( function ( wp ) {
	var el = wp.element.createElement;
	var Panel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || wp.editPost.PluginDocumentSettingPanel;
	var LOCK = 'kofc-event-date';
	var PANEL = 'kofc8600-event-fields/kofc-event-details';

	function EventFields() {
		var postType = wp.data.useSelect( function ( select ) { return select( 'core/editor' ).getCurrentPostType(); }, [] );
		var meta = wp.data.useSelect( function ( select ) { return select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {}; }, [] );
		var editor = wp.data.useDispatch( 'core/editor' );
		var date = meta._event_date || '';

		/* WordPress remembers panel state per user; start this one open so the date is never missed. */
		var panelOpen = wp.data.useSelect( function ( select ) { return select( 'core/editor' ).isEditorPanelOpened( PANEL ); }, [] );
		wp.element.useEffect( function () {
			if ( postType === 'event' && ! panelOpen ) { editor.toggleEditorPanelOpened( PANEL ); }
		}, [ postType ] );

		wp.element.useEffect( function () {
			if ( postType !== 'event' ) { return; }
			if ( date ) { editor.unlockPostSaving( LOCK ); } else { editor.lockPostSaving( LOCK ); }
		}, [ date, postType ] );

		if ( postType !== 'event' ) { return null; }

		function field( key, label, extra ) {
			return el( wp.components.TextControl, Object.assign( {
				label: label,
				value: meta[ key ] || '',
				onChange: function ( value ) { var m = {}; m[ key ] = value; editor.editPost( { meta: m } ); },
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true
			}, extra || {} ) );
		}

		return el( Panel, { name: 'kofc-event-details', title: 'When and where', initialOpen: true },
			el( 'div', { style: { display: 'grid', gap: '16px' } },
				field( '_event_date', 'Date (required)', { type: 'date', help: date ? '' : 'Add the date to publish this event.' } ),
				field( '_event_time', 'Time', { placeholder: '7:30 pm', help: 'Write it the way you would say it.' } ),
				field( '_event_place', 'Place', { placeholder: 'Parish Hall' } ),
				field( '_event_note', 'Note (optional)', { placeholder: '3 volunteers still needed', help: 'Shown as a gold badge. Clear it when it no longer applies.' } )
			)
		);
	}

	wp.plugins.registerPlugin( 'kofc8600-event-fields', { render: EventFields, icon: 'calendar-alt' } );
} )( window.wp );
