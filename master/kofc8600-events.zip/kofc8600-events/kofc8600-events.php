<?php
/**
 * Plugin Name: Council 8600 Events
 * Description: The Council's events, read from its Google Calendar, with the open volunteer spots from SignUpGenius. Officers keep entering events in the Google Calendar and sign-ups in SignUpGenius; the site shows them within the hour. [council_events] lists what's coming up, [council_calendar] shows the full calendar (list and month), and [council_help_needed] lists the events that need volunteers.
 * Version: 0.2.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 * Text Domain: kofc8600-events
 *
 * @package kofc8600-events
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * The feed is built every hour from the Council's Google Calendar and SignUpGenius
 * (tools/build-feed.py in the site's repository) and published here. It holds only
 * public details: no volunteer names or emails. Define KOFC8600_FEED_URL in
 * wp-config.php to read it from somewhere else.
 */
const KOFC_FEED_URL     = 'https://undu82.github.io/kofc8600-demo/data/feed.json';
const KOFC_CALENDAR_ICS = 'https://calendar.google.com/calendar/ical/council8600%40gmail.com/public/basic.ics';
const KOFC_CATEGORIES   = array(
	'council'   => 'Council',
	'faith'     => 'Faith',
	'family'    => 'Family',
	'community' => 'Community',
	'life'      => 'Life',
);

/* The feed, fetched at most every 15 minutes. If it can't be fetched, the last good copy is used. */
function kofc_feed() {
	static $feed = null;
	if ( null !== $feed ) {
		return $feed;
	}
	$file = apply_filters( 'kofc8600_feed_file', '' ); // A local copy, for testing.
	if ( $file && is_readable( $file ) ) {
		$feed = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return $feed = is_array( $feed ) ? $feed : array();
	}
	$cached = get_transient( 'kofc8600_feed' );
	if ( is_array( $cached ) ) {
		return $feed = $cached;
	}
	$url      = defined( 'KOFC8600_FEED_URL' ) ? KOFC8600_FEED_URL : KOFC_FEED_URL;
	$response = wp_safe_remote_get( $url, array( 'timeout' => 8 ) );
	$data     = ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) ? json_decode( wp_remote_retrieve_body( $response ), true ) : null;
	if ( is_array( $data ) && isset( $data['events'] ) ) {
		set_transient( 'kofc8600_feed', $data, 15 * MINUTE_IN_SECONDS );
		update_option( 'kofc8600_feed_last_good', $data, false );
		return $feed = $data;
	}
	$last = get_option( 'kofc8600_feed_last_good' );
	$feed = is_array( $last ) ? $last : array();
	set_transient( 'kofc8600_feed', $feed, 5 * MINUTE_IN_SECONDS ); // try again soon
	return $feed;
}

function kofc_time( $iso ) {
	return ( new DateTimeImmutable( $iso ) )->setTimezone( wp_timezone() );
}

/* "7 pm", "7:30 pm" */
function kofc_clock( DateTimeImmutable $d ) {
	return str_replace( ':00', '', $d->format( 'g:i a' ) );
}

/*
 * Upcoming events, soonest first. A sign-up that matches no calendar event still
 * appears, on its own date, so no request for help is missed.
 */
function kofc_upcoming( $only_help = false ) {
	$feed = kofc_feed();
	$now  = new DateTimeImmutable( 'now', wp_timezone() );
	$list = isset( $feed['events'] ) ? $feed['events'] : array();
	foreach ( isset( $feed['signups'] ) ? $feed['signups'] : array() as $s ) {
		if ( empty( $s['events'] ) && $s['open'] > 0 ) {
			$list[] = array(
				'id'       => 'signup-' . $s['id'],
				'title'    => $s['title'],
				'start'    => $s['start'],
				'end'      => $s['end'],
				'allDay'   => false,
				'place'    => '',
				'notes'    => '',
				'links'    => array(),
				'category' => 'other',
				'signup'   => $s,
			);
		}
	}
	$out = array();
	foreach ( $list as $e ) {
		$end = kofc_time( $e['end'] );
		if ( $e['allDay'] ) {
			$end = $end->setTime( 23, 59 );
		}
		if ( $end < $now || ( $only_help && ( empty( $e['signup'] ) || ! $e['signup']['open'] ) ) ) {
			continue;
		}
		$out[] = $e;
	}
	usort(
		$out,
		function ( $a, $b ) {
			return strcmp( $a['start'], $b['start'] );
		}
	);
	return $out;
}

function kofc_place_short( $place ) {
	return trim( strtok( $place, ',' ), " \"" );
}

/* "Friday · 7 pm · Church" */
function kofc_event_meta( $e, $long = false ) {
	$start = kofc_time( $e['start'] );
	$parts = array( $long ? $start->format( 'l, F j' ) : $start->format( 'l' ) );
	if ( ! $e['allDay'] ) {
		$parts[] = kofc_clock( $start );
	} else {
		$parts[] = 'All day';
	}
	if ( $e['place'] ) {
		$parts[] = $long ? $e['place'] : kofc_place_short( $e['place'] );
	}
	return implode( ' · ', $parts );
}

function kofc_datechip( DateTimeImmutable $d, $class = '' ) {
	return sprintf( '<span class="datechip%s" aria-hidden="true"><span class="m">%s</span><span class="d">%s</span></span>', $class ? ' ' . $class : '', esc_html( $d->format( 'M' ) ), esc_html( $d->format( 'j' ) ) );
}

/* The sign-up button's words, as HTML. Brothers know the sheets by the site's name; screen readers hear "Sign up on SignUpGenius". */
function kofc_signup_verb() {
	return '<span class="screen-reader-text">Sign up on </span>SignUpGenius';
}

function kofc_signup_label( $s ) {
	return 'places' === $s['kind'] ? $s['open'] . ' places left' : $s['open'] . ( 1 === $s['open'] ? ' spot open' : ' spots open' );
}

/* The open shifts of an event's sign-up, and its button. */
function kofc_shifts( $s ) {
	$rows = '';
	foreach ( $s['slots'] as $slot ) {
		$a    = kofc_time( $slot['start'] );
		$b    = kofc_time( $slot['end'] );
		$when = ( $b->getTimestamp() - $a->getTimestamp() ) <= 1800 ? kofc_clock( $a ) : kofc_clock( $a ) . '–' . kofc_clock( $b );
		$what = in_array( strtolower( $slot['item'] ), array( 'church', 'i will attend' ), true ) ? '' : $slot['item'];
		$left = 'places' === $s['kind'] ? $slot['open'] . ' left' : $slot['open'] . ' open';
		$rows .= sprintf( '<li><b>%s</b><span class="what">%s</span><span class="left%s">%s</span></li>', esc_html( $when ), esc_html( $what ), $slot['open'] ? '' : ' is-full', esc_html( $left ) );
	}
	$title = 'places' === $s['kind'] ? kofc_signup_label( $s ) : 'Volunteers needed · ' . kofc_signup_label( $s );
	return sprintf( '<div class="ev-shifts"><p class="sh-title">%s</p><ul>%s</ul><a class="sh-btn" href="%s">%s</a></div>', esc_html( $title ), $rows, esc_url( $s['url'] ), kofc_signup_verb() );
}

/* A link that adds one event to the visitor's Google Calendar. */
function kofc_add_to_calendar( $e ) {
	$utc   = new DateTimeZone( 'UTC' );
	$start = kofc_time( $e['start'] );
	$end   = kofc_time( $e['end'] );
	$dates = $e['allDay']
		? $start->format( 'Ymd' ) . '/' . $end->modify( '+1 day' )->format( 'Ymd' )
		: $start->setTimezone( $utc )->format( 'Ymd\THis\Z' ) . '/' . max( $end, $start )->setTimezone( $utc )->format( 'Ymd\THis\Z' );
	return add_query_arg(
		array(
			'action'   => 'TEMPLATE',
			'text'     => rawurlencode( $e['title'] ),
			'dates'    => $dates,
			'location' => rawurlencode( $e['place'] ),
			'details'  => rawurlencode( $e['notes'] ),
		),
		'https://calendar.google.com/calendar/render'
	);
}

/* One event in the full calendar: the row opens to its notes, place and links; open shifts show below it. */
function kofc_calendar_entry( $e, $show_chip ) {
	$start = kofc_time( $e['start'] );
	$cat   = array_key_exists( $e['category'], KOFC_CATEGORIES ) || 'holiday' === $e['category'] ? $e['category'] : 'other';
	$s     = isset( $e['signup'] ) ? $e['signup'] : null;
	$need  = $s && $s['open'] > 0;
	$id    = 'e-' . substr( md5( $e['id'] ), 0, 10 );
	$attrs = sprintf( ' id="%s" data-day="%s" data-cat="%s"%s', esc_attr( $id ), esc_attr( $start->format( 'Y-m-d' ) ), esc_attr( $cat ), $need ? ' data-need="1"' : '' );
	$chip  = kofc_datechip( $start, $show_chip ? '' : 'is-same' );
	if ( 'holiday' === $cat ) {
		return sprintf( '<div class="ev-entry is-holiday"%s><div class="ev">%s<span class="ev-b"><b>%s</b></span></div></div>', $attrs, kofc_datechip( $start, 'is-quiet' . ( $show_chip ? '' : ' is-same' ) ), esc_html( $e['title'] ) );
	}
	$label = array_key_exists( $cat, KOFC_CATEGORIES ) ? KOFC_CATEGORIES[ $cat ] : '';
	$more  = '';
	if ( $e['notes'] ) {
		$more .= '<p class="ev-notes">' . nl2br( esc_html( $e['notes'] ) ) . '</p>';
	}
	foreach ( $e['links'] as $link ) {
		$more .= sprintf( '<p class="more-link"><a href="%s">%s</a></p>', esc_url( $link['url'] ), esc_html( $link['text'] ) );
	}
	$actions = '';
	if ( $e['place'] ) {
		$actions .= sprintf( '<a href="%s">Directions</a>', esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $e['place'] ) ) );
	}
	$actions .= sprintf( '<a href="%s">Add to my calendar</a>', esc_url( kofc_add_to_calendar( $e ) ) );
	$more    .= '<p class="ev-actions">' . $actions . '</p>';
	return sprintf(
		'<div class="ev-entry"%1$s><details><summary class="ev">%2$s<span class="ev-b"><b>%3$s</b><span class="meta"><span class="screen-reader-text">%4$s, </span>%5$s%6$s</span></span></summary><div class="ev-more"><p class="ev-when">%7$s</p>%8$s</div></details>%9$s</div>',
		$attrs,
		$chip,
		esc_html( $e['title'] ),
		esc_html( $start->format( 'F j' ) ),
		$label ? '<span class="cat cat-' . esc_attr( $cat ) . '">' . esc_html( $label ) . '</span> · ' : '',
		esc_html( kofc_event_meta( $e ) ),
		esc_html( kofc_event_meta( $e, true ) ),
		$more,
		$need ? kofc_shifts( $s ) : ''
	);
}

function kofc_week_start( DateTimeImmutable $d ) {
	return $d->setTime( 0, 0 )->modify( '-' . ( (int) $d->format( 'w' ) ) . ' days' ); // weeks run Sunday to Saturday
}

/* The list view: this week, next week, then each month. The first two weeks show; "Show more" opens the rest. */
function kofc_calendar_list( $events ) {
	$today  = new DateTimeImmutable( 'today', wp_timezone() );
	$week   = kofc_week_start( $today );
	$groups = array();
	foreach ( $events as $e ) {
		$d = kofc_time( $e['start'] );
		if ( $d < $week->modify( '+7 days' ) ) {
			$key = array( 'This week', $today->format( 'M j' ) . ' – ' . $week->modify( '+6 days' )->format( 'j' ), false );
		} elseif ( $d < $week->modify( '+14 days' ) ) {
			$key = array( 'Next week', $week->modify( '+7 days' )->format( 'M j' ) . ' – ' . $week->modify( '+13 days' )->format( 'j' ), false );
		} else {
			$key = array( ( $d->format( 'n' ) === $today->format( 'n' ) ? 'Later in ' : '' ) . $d->format( 'F' ), '', true );
		}
		$groups[ implode( '|', $key ) ]['key']    = $key;
		$groups[ implode( '|', $key ) ]['list'][] = $e;
	}
	$html  = '';
	$later = false;
	foreach ( $groups as $g ) {
		list( $title, $sub, $is_later ) = $g['key'];
		$rows                           = '';
		$last                           = '';
		foreach ( $g['list'] as $e ) {
			$day   = kofc_time( $e['start'] )->format( 'Y-m-d' );
			$rows .= kofc_calendar_entry( $e, $day !== $last );
			$last  = $day;
		}
		$later = $later || $is_later;
		$html .= sprintf( '<section class="ev-group%s"><h2 class="cal-group">%s%s</h2><div class="ev-list">%s</div></section>', $is_later ? ' is-later' : '', esc_html( $title ), $sub ? ' <span>' . esc_html( $sub ) . '</span>' : '', $rows );
	}
	if ( $later ) {
		$html .= '<p class="cal-more"><button type="button" class="cal-show-more">Show more events</button></p>';
	}
	return '<div class="cal-list">' . $html . '</div>';
}

/* The month view: one grid per month. Events needing volunteers always show in a day; the rest fill it in time order. */
function kofc_calendar_months( $events ) {
	$by_day = array();
	foreach ( $events as $e ) {
		$by_day[ kofc_time( $e['start'] )->format( 'Y-m-d' ) ][] = $e;
	}
	if ( ! $by_day ) {
		return '';
	}
	$today = new DateTimeImmutable( 'today', wp_timezone() );
	$first = $today->modify( 'first day of this month' );
	$last  = kofc_time( end( $events )['start'] )->modify( 'first day of this month' );
	$head  = '';
	foreach ( array( 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ) as $n ) {
		$head .= '<span>' . $n . '</span>';
	}
	$html = '';
	for ( $m = $first; $m <= $last; $m = $m->modify( 'first day of next month' ) ) {
		$cells = '';
		$start = kofc_week_start( $m );
		$weeks = (int) ceil( ( (int) $m->format( 'w' ) + (int) $m->format( 't' ) ) / 7 );
		for ( $i = 0; $i < $weeks * 7; $i++ ) {
			$d     = $start->modify( "+$i days" );
			$key   = $d->format( 'Y-m-d' );
			$items = isset( $by_day[ $key ] ) ? $by_day[ $key ] : array();
			$need  = false;
			$shown = $items;
			usort(
				$shown,
				function ( $a, $b ) {
					$na = ! empty( $a['signup']['open'] );
					$nb = ! empty( $b['signup']['open'] );
					return $na === $nb ? strcmp( $a['start'], $b['start'] ) : ( $na ? -1 : 1 );
				}
			);
			$shown = array_slice( $shown, 0, 3 );
			usort(
				$shown,
				function ( $a, $b ) {
					return strcmp( $a['start'], $b['start'] );
				}
			);
			$lines = '';
			foreach ( $shown as $e ) {
				$has   = ! empty( $e['signup']['open'] );
				$need  = $need || $has;
				$cat   = array_key_exists( $e['category'], KOFC_CATEGORIES ) || 'holiday' === $e['category'] ? $e['category'] : 'other';
				$t     = ( $e['allDay'] || 'holiday' === $cat ) ? '' : kofc_clock( kofc_time( $e['start'] ) ) . ' ';
				$lines .= sprintf( '<li class="cat-%s%s" data-cat="%s"%s><span class="t">%s</span>%s</li>', esc_attr( $cat ), $has ? ' has-need' : '', esc_attr( $cat ), $has ? ' data-need="1"' : '', esc_html( $t ), esc_html( $e['title'] ) );
			}
			foreach ( $items as $e ) {
				$need = $need || ! empty( $e['signup']['open'] );
			}
			$extra  = count( $items ) - count( $shown );
			$lines .= $extra > 0 ? '<li class="more">+' . $extra . ' more</li>' : '';
			$class  = ( $d->format( 'n' ) !== $m->format( 'n' ) ? ' is-other' : '' ) . ( $key === $today->format( 'Y-m-d' ) ? ' is-today' : '' ) . ( $need ? ' has-need' : '' ) . ( $d < $today ? ' is-past' : '' );
			$label  = $d->format( 'l, F j' ) . ( $items ? ': ' . count( $items ) . ( 1 === count( $items ) ? ' event' : ' events' ) : ': no events' ) . ( $need ? ', volunteers needed' : '' );
			$cells .= sprintf( '<div class="mday%s" data-day="%s"%s aria-label="%s"><span class="num">%s</span>%s</div>', $class, esc_attr( $key ), $items ? ' data-has="1"' : '', esc_attr( $label ), esc_html( $d->format( 'j' ) ), $lines ? '<ul>' . $lines . '</ul>' : '' );
		}
		$html .= sprintf( '<div class="cal-month" data-month="%s"%s><h2 class="cal-month-title">%s</h2><div class="mgrid"><div class="mhead" aria-hidden="true">%s</div>%s</div></div>', esc_attr( $m->format( 'Y-m' ) ), $m > $first ? ' hidden' : '', esc_html( $m->format( 'F Y' ) ), $head, $cells );
	}
	$legend = '';
	foreach ( KOFC_CATEGORIES as $k => $v ) {
		$legend .= '<span class="cat-' . $k . '"><i></i>' . $v . '</span>';
	}
	return '<div class="cal-months">'
		. '<div class="mnav"><button type="button" class="mprev" aria-label="Previous month">‹</button><button type="button" class="mnext" aria-label="Next month">›</button></div>'
		. $html
		. '<p class="mlegend">' . $legend . '<span class="leg-need"><i></i>Volunteers needed</span></p>'
		. '<div class="cal-day" aria-live="polite"></div></div>';
}

function kofc_feed_updated() {
	$feed = kofc_feed();
	if ( empty( $feed['generated'] ) ) {
		return '';
	}
	$ago = human_time_diff( kofc_time( $feed['generated'] )->getTimestamp(), time() );
	return 'From the Council\'s Google Calendar' . ( ! empty( $feed['source']['signups'] ) ? ' and SignUpGenius' : '' ) . ', updated ' . $ago . ' ago.';
}

/* [council_calendar]: the full calendar, with filters and a List/Month switch. */
add_shortcode(
	'council_calendar',
	function () {
		$events = kofc_upcoming();
		if ( ! $events ) {
			return '<p class="ev-empty">The calendar couldn\'t be loaded just now. <a href="' . esc_url( 'https://calendar.google.com/calendar/embed?src=council8600%40gmail.com&ctz=America%2FNew_York' ) . '">Open the Council\'s Google Calendar</a>.</p>';
		}
		wp_enqueue_script( 'kofc8600-calendar', plugins_url( 'calendar.js', __FILE__ ), array(), '0.2.0', array( 'strategy' => 'defer' ) );
		$need  = count(
			array_filter(
				$events,
				function ( $e ) {
					return ! empty( $e['signup']['open'] );
				}
			)
		);
		$chips = '<button type="button" class="chip" data-filter="all" aria-pressed="true">All</button>';
		if ( $need ) {
			$chips .= '<button type="button" class="chip chip-need" data-filter="need" aria-pressed="false">Volunteers needed <span class="n">' . $need . '</span></button>';
		}
		foreach ( KOFC_CATEGORIES as $k => $v ) {
			$chips .= '<button type="button" class="chip cat-' . $k . '" data-filter="' . $k . '" aria-pressed="false">' . $v . '</button>';
		}
		return '<div class="cal" data-view="list">'
			. '<div class="cal-tools"><div class="cal-filters" role="group" aria-label="Show">' . $chips . '</div>'
			. '<div class="cal-switch" role="group" aria-label="View" hidden><button type="button" data-view="list" aria-pressed="true">List</button><button type="button" data-view="month" aria-pressed="false">Month</button></div></div>'
			. kofc_calendar_list( $events )
			. kofc_calendar_months( $events )
			. '<p class="cal-empty" hidden>Nothing of that kind coming up.</p>'
			. '<p class="cal-source">' . esc_html( kofc_feed_updated() ) . '</p>'
			. '</div>';
	}
);

/*
 * [council_events count="3"]: the next few events, for the home page. Holidays are left out.
 * match="COR Mass" keeps only events whose title contains those words, for a page about one activity.
 * category="faith" keeps only one program's events (faith, family, community, life or council), for a
 * program page. An event that still needs volunteers shows how many spots are open; its row opens it on
 * the Events page, which lists the shifts and the SignUpGenius button.
 */
add_shortcode(
	'council_events',
	function ( $atts ) {
		$atts   = shortcode_atts(
			array(
				'count'    => 3,
				'empty'    => 'No upcoming events yet.',
				'match'    => '',
				'category' => '',
			),
			$atts
		);
		$match  = trim( (string) $atts['match'] );
		$cat    = strtolower( trim( (string) $atts['category'] ) );
		$events = array_slice(
			array_values(
				array_filter(
					kofc_upcoming(),
					function ( $e ) use ( $match, $cat ) {
						return 'holiday' !== $e['category'] && ( '' === $match || false !== stripos( (string) $e['title'], $match ) ) && ( '' === $cat || $cat === $e['category'] );
					}
				)
			),
			0,
			max( 1, (int) $atts['count'] )
		);
		if ( ! $events ) {
			return '<p class="ev-empty">' . esc_html( $atts['empty'] ) . '</p>';
		}
		$page = get_page_by_path( 'events' );
		$base = $page ? get_permalink( $page ) : home_url( '/events/' );
		$html = '<div class="ev-list">';
		foreach ( $events as $e ) {
			$start = kofc_time( $e['start'] );
			$s     = isset( $e['signup'] ) ? $e['signup'] : null;
			$html .= sprintf(
				'<a class="ev" href="%1$s">%2$s<span class="ev-b"><b>%3$s</b><span class="meta"><span class="screen-reader-text">%4$s, </span>%5$s</span>%6$s</span></a>',
				esc_url( $base . '#e-' . substr( md5( $e['id'] ), 0, 10 ) ),
				kofc_datechip( $start ),
				esc_html( $e['title'] ),
				esc_html( $start->format( 'F j' ) ),
				esc_html( kofc_event_meta( $e ) ),
				$s && $s['open'] ? '<span class="need">' . esc_html( kofc_signup_label( $s ) ) . '</span>' : ''
			);
		}
		return $html . '</div>';
	}
);

/*
 * [council_help_needed count="3"]: the next events that still need volunteers, as rows like the home
 * page's "Coming up", each with how many spots are open. A row opens the event on the Events page,
 * which lists its shifts and its SignUpGenius button.
 */
add_shortcode(
	'council_help_needed',
	function ( $atts ) {
		$atts   = shortcode_atts( array( 'count' => 3 ), $atts );
		$events = array_slice( kofc_upcoming( true ), 0, max( 1, (int) $atts['count'] ) );
		if ( ! $events ) {
			return '<p class="ev-empty">No sign-ups need volunteers right now.</p>';
		}
		$page = get_page_by_path( 'events' );
		$base = $page ? get_permalink( $page ) : home_url( '/events/' );
		$html = '<div class="ev-list help-list">';
		foreach ( $events as $e ) {
			$start = kofc_time( $e['start'] );
			$html .= sprintf(
				'<a class="ev" href="%1$s">%2$s<span class="ev-b"><b>%3$s</b><span class="meta"><span class="screen-reader-text">%4$s, </span>%5$s</span><span class="need">%6$s</span></span></a>',
				esc_url( $base . '#e-' . substr( md5( $e['id'] ), 0, 10 ) ),
				kofc_datechip( $start ),
				esc_html( $e['title'] ),
				esc_html( $start->format( 'F j' ) ),
				esc_html( kofc_event_meta( $e ) ),
				esc_html( kofc_signup_label( $e['signup'] ) )
			);
		}
		return $html . '</div>';
	}
);
