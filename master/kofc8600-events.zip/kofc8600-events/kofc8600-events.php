<?php
/**
 * Plugin Name: Council 8600 Events
 * Description: Simple Council events: title, date, time, place and an optional note. Upcoming events appear wherever the [council_events] shortcode is placed; past events drop off automatically.
 * Version: 0.1.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Sebastian Undurraga
 * License: GPL-2.0-or-later
 * Text Domain: kofc8600-events
 *
 * @package kofc8600-events
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KOFC_EVENT_FIELDS = array(
	'_event_date'   => 'Date',
	'_event_time'   => 'Time',
	'_event_place'  => 'Place',
	'_event_note'   => 'Note',
	'_event_signup' => 'Sign-up link',
);

add_action(
	'init',
	function () {
		register_post_type(
			'event',
			array(
				'labels'        => array(
					'name'          => 'Events',
					'singular_name' => 'Event',
					'add_new'       => 'Add event',
					'add_new_item'  => 'Add an event',
					'edit_item'     => 'Edit event',
					'new_item'      => 'New event',
					'view_item'     => 'View event',
					'search_items'  => 'Search events',
					'not_found'     => 'No events yet',
					'all_items'     => 'All events',
					'item_published' => 'Event published.',
					'item_updated'  => 'Event updated.',
					'item_scheduled' => 'Event scheduled.',
				),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => false,
				'menu_position' => 5,
				'menu_icon'     => 'dashicons-calendar-alt',
				'rewrite'       => array( 'slug' => 'event' ),
				'supports'      => array( 'title', 'editor', 'custom-fields' ),
				'template'      => array(
					array( 'core/paragraph', array( 'placeholder' => 'What is happening, who it is for, and what to bring.' ) ),
				),
			)
		);
		foreach ( array_keys( KOFC_EVENT_FIELDS ) as $key ) {
			register_post_meta(
				'event',
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => '_event_signup' === $key ? 'esc_url_raw' : 'sanitize_text_field',
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
);

/*
 * "When and where" fields live in the editor sidebar (editor.js), next to the
 * Publish button, and publishing stays locked until a date is entered.
 */
add_action(
	'enqueue_block_editor_assets',
	function () {
		$screen = get_current_screen();
		if ( ! $screen || 'event' !== $screen->post_type ) {
			return;
		}
		wp_enqueue_script(
			'kofc8600-event-fields',
			plugins_url( 'editor.js', __FILE__ ),
			array( 'wp-plugins', 'wp-editor', 'wp-components', 'wp-data', 'wp-element' ),
			'0.1.0',
			true
		);
	}
);

/* Show the event date in the admin list, soonest first. */
add_filter(
	'manage_event_posts_columns',
	function ( $columns ) {
		return array_slice( $columns, 0, 2, true ) + array( 'event_date' => 'Event date' ) + array_slice( $columns, 2, null, true );
	}
);
add_action(
	'manage_event_posts_custom_column',
	function ( $column, $post_id ) {
		if ( 'event_date' === $column ) {
			$date = get_post_meta( $post_id, '_event_date', true );
			echo $date ? esc_html( wp_date( 'D j M Y', strtotime( $date . ' 12:00' ) ) ) : '<em>No date</em>';
			if ( $date && $date < current_time( 'Y-m-d' ) ) {
				echo ' <span style="color:#50575e">(past)</span>';
			}
		}
	},
	10,
	2
);
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() && $query->is_main_query() && 'event' === $query->get( 'post_type' ) && ! $query->get( 'orderby' ) ) {
			$query->set( 'meta_key', '_event_date' );
			$query->set( 'orderby', 'meta_value' );
			$query->set( 'order', 'DESC' );
		}
	}
);

function kofc_event_line( $post_id, $long = false ) {
	$date  = get_post_meta( $post_id, '_event_date', true );
	$stamp = strtotime( $date . ' 12:00' );
	$parts = array( wp_date( $long ? 'l, F j' : 'l', $stamp ) );
	foreach ( array( '_event_time', '_event_place' ) as $key ) {
		$value = get_post_meta( $post_id, $key, true );
		if ( $value ) {
			$parts[] = $value;
		}
	}
	return $parts;
}

/* [council_events count="3"]: upcoming events with date chips, soonest first. */
add_shortcode(
	'council_events',
	function ( $atts ) {
		$atts   = shortcode_atts(
			array(
				'count' => 3,
				'empty' => 'No upcoming events yet.',
			),
			$atts
		);
		$events = get_posts(
			array(
				'post_type'      => 'event',
				'posts_per_page' => max( 1, (int) $atts['count'] ),
				'meta_key'       => '_event_date',
				'orderby'        => 'meta_value',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'     => '_event_date',
						'value'   => current_time( 'Y-m-d' ),
						'compare' => '>=',
						'type'    => 'DATE',
					),
				),
			)
		);
		if ( ! $events ) {
			return '<p class="ev-empty">' . esc_html( $atts['empty'] ) . '</p>';
		}
		$html = '<div class="ev-list">';
		foreach ( $events as $event ) {
			$stamp = strtotime( get_post_meta( $event->ID, '_event_date', true ) . ' 12:00' );
			$note  = get_post_meta( $event->ID, '_event_note', true );
			$html .= sprintf(
				'<a class="ev" href="%1$s"><span class="datechip" aria-hidden="true"><span class="m">%2$s</span><span class="d">%3$s</span></span><span class="ev-b"><b>%4$s</b><span class="meta"><span class="screen-reader-text">%5$s, </span>%6$s</span>%7$s</span></a>',
				esc_url( get_permalink( $event ) ),
				esc_html( wp_date( 'M', $stamp ) ),
				esc_html( wp_date( 'j', $stamp ) ),
				esc_html( get_the_title( $event ) ),
				esc_html( wp_date( 'F j', $stamp ) ),
				esc_html( implode( ' · ', kofc_event_line( $event->ID ) ) ),
				$note ? '<span class="need">' . esc_html( $note ) . '</span>' : ''
			);
			// A link cannot sit inside the event's own link, so the sign-up gets its own row just below.
			$signup = get_post_meta( $event->ID, '_event_signup', true );
			if ( $signup ) {
				$html .= sprintf(
					'<a class="ev ev-signup" href="%1$s">Sign up to help<span class="screen-reader-text">: %2$s</span></a>',
					esc_url( $signup ),
					esc_html( get_the_title( $event ) )
				);
			}
		}
		return $html . '</div>';
	}
);

/* [council_event_details]: date, time, place and note on a single event page. */
add_shortcode(
	'council_event_details',
	function () {
		$post_id = get_the_ID();
		if ( ! $post_id || 'event' !== get_post_type( $post_id ) || ! get_post_meta( $post_id, '_event_date', true ) ) {
			return '';
		}
		$note   = get_post_meta( $post_id, '_event_note', true );
		$signup = get_post_meta( $post_id, '_event_signup', true );
		return '<div class="event-facts-wrap"><div class="event-facts"><p><strong>' . esc_html( implode( ' · ', kofc_event_line( $post_id, true ) ) ) . '</strong></p>'
			. ( $note ? '<p><span class="need">' . esc_html( $note ) . '</span></p>' : '' )
			. ( $signup ? '<div class="wp-block-buttons"><div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $signup ) . '">Sign up to help</a></div></div>' : '' )
			. '</div></div>';
	}
);
